"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Play, Truck, PackageCheck, MapPin, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-28 pb-16 sm:pt-32 lg:pt-36 lg:pb-24">
      {/* Background layers */}
      <div className="absolute inset-0 -z-10 hero-grid opacity-70" />
      <div className="absolute inset-0 -z-10 glow-radial" />
      <div className="pointer-events-none absolute -top-24 -right-24 -z-10 h-96 w-96 rounded-full bg-primary/20 blur-3xl" />
      <div className="pointer-events-none absolute top-40 -left-24 -z-10 h-80 w-80 rounded-full bg-emerald-400/10 blur-3xl" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          {/* Left: copy */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center lg:text-left"
          >
            <Badge
              variant="secondary"
              className="mb-5 gap-1.5 rounded-full border-primary/20 bg-primary/10 px-3 py-1 text-primary"
            >
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
              </span>
              Logistics-tech for eCommerce &amp; D2C
            </Badge>

            <h1 className="text-balance text-4xl font-extrabold leading-[1.08] tracking-tight text-foreground sm:text-5xl lg:text-6xl">
              Ship smarter across{" "}
              <span className="bg-gradient-to-r from-primary to-emerald-500 bg-clip-text text-transparent">
                every channel
              </span>{" "}
              from one platform
            </h1>

            <p className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground lg:mx-0">
              Growve brings orders, couriers, returns and analytics together for
              brands, startups and logistics companies — so you launch, scale and
              deliver faster without stitching tools together.
            </p>

            <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row lg:justify-start">
              <Button size="lg" asChild className="w-full gap-2 rounded-full sm:w-auto">
                <Link href="#contact">
                  Book a Demo
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                className="w-full gap-2 rounded-full sm:w-auto"
              >
                <Link href="#features">
                  <Play className="h-4 w-4" />
                  See how it works
                </Link>
              </Button>
            </div>

            <dl className="mt-10 grid max-w-md grid-cols-3 gap-4 text-center lg:text-left">
              <div>
                <dt className="text-2xl font-bold text-foreground">13+</dt>
                <dd className="text-xs text-muted-foreground">Courier partners</dd>
              </div>
              <div>
                <dt className="text-2xl font-bold text-foreground">99%</dt>
                <dd className="text-xs text-muted-foreground">Platform uptime</dd>
              </div>
              <div>
                <dt className="text-2xl font-bold text-foreground">24/7</dt>
                <dd className="text-xs text-muted-foreground">Support</dd>
              </div>
            </dl>
          </motion.div>

          {/* Right: dashboard mock */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="relative"
          >
            <DashboardMock />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function DashboardMock() {
  return (
    <div className="relative mx-auto w-full max-w-lg">
      {/* floating cards */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.5, duration: 0.5 }}
        className="absolute -left-4 -top-5 z-30 hidden animate-float-slow lg:block"
      >
        <div className="flex items-center gap-2 rounded-xl border border-border bg-card/95 p-3 shadow-lg backdrop-blur">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <PackageCheck className="h-5 w-5" />
          </span>
          <div>
            <p className="text-xs text-muted-foreground">Orders shipped</p>
            <p className="text-sm font-semibold text-foreground">12,480 today</p>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.65, duration: 0.5 }}
        className="absolute -right-4 -bottom-5 z-30 hidden animate-float-slow lg:block"
        style={{ animationDelay: "1.5s" }}
      >
        <div className="flex items-center gap-2 rounded-xl border border-border bg-card/95 p-3 shadow-lg backdrop-blur">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-600">
            <TrendingUp className="h-5 w-5" />
          </span>
          <div>
            <p className="text-xs text-muted-foreground">Delivery success</p>
            <p className="text-sm font-semibold text-foreground">96.4% this week</p>
          </div>
        </div>
      </motion.div>

      {/* main panel */}
      <div className="relative z-10 overflow-hidden rounded-2xl border border-border bg-card shadow-2xl shadow-primary/10">
        <div className="flex items-center gap-1.5 border-b border-border bg-muted/40 px-4 py-3">
          <span className="h-2.5 w-2.5 rounded-full bg-red-400/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-amber-400/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-emerald-400/70" />
          <span className="ml-3 text-xs font-medium text-muted-foreground">
            growve — shipping dashboard
          </span>
        </div>
        <div className="space-y-4 p-5 pb-14">
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: "In Transit", value: "1,204", icon: Truck, tone: "text-primary" },
              { label: "Delivered", value: "9,820", icon: PackageCheck, tone: "text-emerald-600" },
              { label: "RTO", value: "126", icon: MapPin, tone: "text-amber-600" },
            ].map((s) => (
              <div key={s.label} className="rounded-lg border border-border bg-background p-3">
                <s.icon className={`mb-2 h-4 w-4 ${s.tone}`} />
                <p className="text-lg font-bold text-foreground">{s.value}</p>
                <p className="text-[10px] text-muted-foreground">{s.label}</p>
              </div>
            ))}
          </div>

          {/* faux bar chart */}
          <div className="rounded-lg border border-border bg-background p-4">
            <div className="mb-3 flex items-center justify-between">
              <p className="text-xs font-medium text-foreground">Shipments this week</p>
              <span className="text-[10px] text-emerald-600">▲ 12.4%</span>
            </div>
            <div className="flex h-28 items-end gap-2 rounded-md bg-muted/40 p-2">
              {[40, 65, 52, 80, 70, 95, 60].map((h, i) => (
                <div key={i} className="flex flex-1 items-end">
                  <div
                    className="w-full rounded-t-md bg-gradient-to-t from-primary/60 to-primary"
                    style={{ height: `${h}%` }}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* faux courier row */}
          <div className="space-y-2">
            {[
              { c: "Bluedart", r: "₹48", t: "1-2 days" },
              { c: "Delhivery", r: "₹42", t: "2-3 days" },
              { c: "Ekart", r: "₹39", t: "2-4 days" },
            ].map((row) => (
              <div
                key={row.c}
                className="flex items-center justify-between rounded-lg border border-border bg-background px-3 py-2 text-xs"
              >
                <span className="font-medium text-foreground">{row.c}</span>
                <span className="text-muted-foreground">{row.t}</span>
                <span className="font-semibold text-primary">{row.r}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
