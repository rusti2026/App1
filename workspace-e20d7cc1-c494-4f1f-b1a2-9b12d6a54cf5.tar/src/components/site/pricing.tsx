"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Check, Sparkles, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SectionHeading } from "./section-heading";

type Plan = {
  name: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  cta: string;
  featured?: boolean;
};

const PLANS: Plan[] = [
  {
    name: "Starter",
    price: "₹0",
    period: "/mo",
    description: "For new sellers finding their feet.",
    features: [
      "Up to 100 shipments / month",
      "1 sales channel",
      "2 courier integrations",
      "Basic tracking & alerts",
      "Email support",
    ],
    cta: "Start free",
  },
  {
    name: "Growth",
    price: "₹1,499",
    period: "/mo",
    description: "For brands scaling across channels.",
    features: [
      "Up to 5,000 shipments / month",
      "Unlimited sales channels",
      "13+ courier integrations",
      "Smart courier recommendations",
      "Returns & COD reconciliation",
      "Priority support",
    ],
    cta: "Book a Demo",
    featured: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    description: "For high-volume & D2C enterprises.",
    features: [
      "Unlimited shipments",
      "Dedicated integrations & SLAs",
      "Custom workflows & automation",
      "Advanced analytics & exports",
      "Dedicated account manager",
      "24/7 phone support",
    ],
    cta: "Contact sales",
  },
];

export function Pricing() {
  return (
    <section id="pricing" className="scroll-mt-20 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Pricing"
          title="Simple, transparent pricing for every business"
          subtitle="Choose a plan that fits your e-commerce needs. Flexible pricing with no hidden fees — helping you scale smarter and save on logistics."
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {PLANS.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.4, delay: i * 0.1 }}
              className="relative"
            >
              <Card
                className={`relative h-full transition-all duration-300 hover:-translate-y-1 ${
                  plan.featured
                    ? "border-primary shadow-xl shadow-primary/10 ring-1 ring-primary/30"
                    : "border-border/70 hover:shadow-lg"
                }`}
              >
                {plan.featured && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 gap-1 rounded-full bg-primary px-3 text-primary-foreground">
                    <Sparkles className="h-3 w-3" />
                    Most popular
                  </Badge>
                )}
                <CardHeader>
                  <p className="text-sm font-semibold text-primary">{plan.name}</p>
                  <div className="mt-2 flex items-baseline gap-1">
                    <span className="text-4xl font-extrabold text-foreground">
                      {plan.price}
                    </span>
                    <span className="text-sm text-muted-foreground">{plan.period}</span>
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">{plan.description}</p>
                </CardHeader>
                <CardContent>
                  <Button
                    asChild
                    variant={plan.featured ? "default" : "outline"}
                    className="w-full gap-1.5 rounded-full"
                  >
                    <Link href="#contact">
                      {plan.cta}
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </Button>
                  <ul className="mt-6 space-y-3">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-sm">
                        <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                          <Check className="h-3 w-3" />
                        </span>
                        <span className="text-foreground/80">{f}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <p className="mt-10 text-center text-sm text-muted-foreground">
          All plans include real-time tracking, automated alerts and secure API
          access. Need something custom?{" "}
          <Link href="#contact" className="font-medium text-primary hover:underline">
            Talk to our team
          </Link>
          .
        </p>
      </div>
    </section>
  );
}
