"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Check, RefreshCw, Boxes, Plug } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CHANNELS } from "./data";

const benefits = [
  "Unified API connections to marketplaces, ERPs and courier partners",
  "Real-time sync of orders, inventory, tracking and customer data",
  "No manual intervention — fewer errors, smoother end-to-end operations",
];

export function MultiChannel() {
  return (
    <section id="multi-channel" className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          {/* Visual */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.5 }}
            className="relative order-2 lg:order-1"
          >
            <HubDiagram />
          </motion.div>

          {/* Copy */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.5, delay: 0.05 }}
            className="order-1 lg:order-2"
          >
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              <Plug className="h-3.5 w-3.5" />
              Multi-Channel Integration
            </span>
            <h2 className="mt-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              One hub for every channel you sell on
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              Connect your systems effortlessly with seamless API integrations
              across all major eCommerce platforms, marketplaces, ERPs and courier
              partners. One unified interface keeps orders, inventory and tracking
              in sync in real time — without the manual grind.
            </p>

            <ul className="mt-6 space-y-3">
              {benefits.map((b) => (
                <li key={b} className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <Check className="h-3.5 w-3.5" />
                  </span>
                  <span className="text-sm text-foreground/80">{b}</span>
                </li>
              ))}
            </ul>

            <div className="mt-8">
              <Button asChild variant="outline" className="gap-1.5 rounded-full">
                <Link href="#contact">
                  Learn more
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function HubDiagram() {
  return (
    <div className="relative mx-auto aspect-square w-full max-w-md">
      {/* center hub */}
      <div className="absolute left-1/2 top-1/2 z-20 -translate-x-1/2 -translate-y-1/2">
        <div className="flex h-24 w-24 flex-col items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-xl shadow-primary/30">
          <Boxes className="h-7 w-7" />
          <span className="mt-1 text-xs font-bold">growve.</span>
        </div>
      </div>

      {/* rings */}
      <div className="absolute inset-8 rounded-full border border-dashed border-primary/30" />
      <div className="absolute inset-0 rounded-full border border-border" />

      {/* nodes */}
      {CHANNELS.map((c, i) => {
        const angle = (i / CHANNELS.length) * Math.PI * 2 - Math.PI / 2;
        const r = 44; // percent radius
        const x = 50 + r * Math.cos(angle);
        const y = 50 + r * Math.sin(angle);
        return (
          <div
            key={c.name}
            className="absolute z-10 -translate-x-1/2 -translate-y-1/2"
            style={{ left: `${x}%`, top: `${y}%` }}
          >
            <div className="flex flex-col items-center gap-1">
              <span className="flex h-12 w-12 items-center justify-center rounded-xl border border-border bg-card text-sm font-bold text-foreground/70 shadow-sm">
                {c.short}
              </span>
              <span className="text-[10px] font-medium text-muted-foreground">
                {c.name}
              </span>
            </div>
          </div>
        );
      })}

      {/* center refresh icon */}
      <div className="absolute left-1/2 top-1/2 z-0 -translate-x-1/2 -translate-y-1/2 text-primary/20">
        <RefreshCw className="h-40 w-40" />
      </div>
    </div>
  );
}
