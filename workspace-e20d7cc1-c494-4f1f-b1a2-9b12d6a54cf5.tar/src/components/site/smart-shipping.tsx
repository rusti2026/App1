"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { SHIPPING_SOLUTIONS, UNIFIED_STEPS, RETURNS_STEPS, STATS } from "./data";
import { SectionHeading } from "./section-heading";

export function SmartShipping() {
  return (
    <section id="smart-shipping" className="scroll-mt-20 bg-muted/30 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Smart Shipping"
          title="Smarter, faster, cheaper shipping"
          subtitle="Bring every order, courier and delivery update into one dashboard. Sell on Amazon, Flipkart, Meesho, Shopify, WooCommerce or your own site — Growve unifies the lot."
        />

        {/* Solutions grid */}
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {SHIPPING_SOLUTIONS.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
            >
              <Card className="h-full border-border/70 bg-card transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-primary/5">
                <CardContent className="p-6">
                  <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <s.icon className="h-5 w-5" />
                  </span>
                  <h3 className="mt-4 text-base font-semibold text-foreground">
                    {s.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {s.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Unified order management steps */}
        <div className="mt-20">
          <h3 className="text-center text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            Multi-channel delivery, made simple
          </h3>
          <p className="mx-auto mt-3 max-w-2xl text-center text-muted-foreground">
            Manage orders across channels, compare couriers, create labels
            instantly and track every shipment — all from a single dashboard.
          </p>

          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {UNIFIED_STEPS.map((step, i) => (
              <motion.div
                key={step.no}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                className="relative rounded-2xl border border-border/70 bg-card p-6"
              >
                <div className="flex items-center justify-between">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <step.icon className="h-5 w-5" />
                  </span>
                  <span className="text-3xl font-extrabold text-primary/15">
                    {step.no}
                  </span>
                </div>
                <h4 className="mt-4 text-base font-semibold text-foreground">
                  {step.title}
                </h4>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Returns & payment management */}
        <div className="mt-20 grid items-center gap-12 lg:grid-cols-2">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              Returns &amp; Payment Management
            </span>
            <h3 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
              Handle returns, COD and refunds with full visibility
            </h3>
            <p className="mt-4 text-muted-foreground">
              Manage returns, failed deliveries and COD payments across couriers.
              Automate reconciliation, cut losses and keep your finances accurate
              and stress-free.
            </p>
            <div className="mt-6">
              <Button asChild variant="outline" className="gap-1.5 rounded-full">
                <Link href="#contact">
                  Talk to us
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1">
            {RETURNS_STEPS.map((step) => (
              <div
                key={step.no}
                className="flex items-start gap-4 rounded-2xl border border-border/70 bg-card p-4"
              >
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <step.icon className="h-5 w-5" />
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-primary">{step.no}</span>
                    <h4 className="text-sm font-semibold text-foreground">
                      {step.title}
                    </h4>
                  </div>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stats band */}
      <div className="mx-auto mt-20 max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-foreground px-6 py-12 text-background sm:px-12">
          <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-primary/30 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-24 -left-16 h-64 w-64 rounded-full bg-emerald-400/10 blur-3xl" />
          <div className="relative grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {STATS.map((s) => (
              <div key={s.label} className="text-center sm:text-left">
                <p className="text-4xl font-extrabold text-primary sm:text-5xl">
                  {s.value}
                </p>
                <p className="mt-2 text-sm font-semibold text-background">{s.label}</p>
                <p className="mt-1 text-xs text-background/60">{s.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
