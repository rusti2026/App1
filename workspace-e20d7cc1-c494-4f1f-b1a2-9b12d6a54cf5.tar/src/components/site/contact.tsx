"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Send, Mail, MapPin, Users, Loader2, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { SectionHeading } from "./section-heading";
import { COMPANY } from "./data";

export function Contact() {
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [email, setEmail] = useState("");
  const [subscribing, setSubscribing] = useState(false);
  const [subscribed, setSubscribed] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitting(true);
    const form = e.currentTarget;
    const data = new FormData(form);
    const payload = Object.fromEntries(data.entries());
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("Request failed");
      setDone(true);
      toast({
        title: "Message sent",
        description: "Thanks for reaching out — we’ll reply within one business day.",
      });
      form.reset();
    } catch {
      toast({
        title: "Something went wrong",
        description: "Please try again or email us directly at admin@growve.in.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleSubscribe(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubscribing(true);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "newsletter", email }),
      });
      if (!res.ok) throw new Error("Request failed");
      setSubscribed(true);
      toast({ title: "Subscribed", description: "You’re on the list for Growve updates." });
      setEmail("");
    } catch {
      toast({
        title: "Subscription failed",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setSubscribing(false);
    }
  }

  return (
    <section id="contact" className="scroll-mt-20 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Contact"
          title="Let’s talk logistics"
          subtitle="Drop us a line with any questions, inquiries or business proposals — we usually reply within one business day."
        />

        <div className="mt-14 grid gap-8 lg:grid-cols-5">
          {/* Left: info + newsletter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-2"
          >
            <Card className="h-full border-border/70 bg-foreground text-background">
              <CardContent className="flex h-full flex-col p-8">
                <h3 className="text-xl font-bold text-background">Reach us directly</h3>
                <p className="mt-2 text-sm text-background/70">
                  Prefer email or want to visit? Here’s how to find us.
                </p>

                <ul className="mt-6 space-y-5">
                  <li className="flex gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/20 text-primary">
                      <MapPin className="h-5 w-5" />
                    </span>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-background/50">
                        Address
                      </p>
                      <p className="mt-1 text-sm text-background/90">{COMPANY.address}</p>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/20 text-primary">
                      <Mail className="h-5 w-5" />
                    </span>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-background/50">
                        Email
                      </p>
                      <a
                        href={`mailto:${COMPANY.email}`}
                        className="mt-1 block text-sm text-background/90 hover:text-primary"
                      >
                        {COMPANY.email}
                      </a>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/20 text-primary">
                      <Users className="h-5 w-5" />
                    </span>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-background/50">
                        Careers
                      </p>
                      <p className="mt-1 text-sm text-background/90">
                        We’re hiring — write to{" "}
                        <a
                          href={`mailto:${COMPANY.careersEmail}`}
                          className="text-primary hover:underline"
                        >
                          {COMPANY.careersEmail}
                        </a>
                      </p>
                    </div>
                  </li>
                </ul>

                {/* Newsletter */}
                <div className="mt-auto pt-8">
                  <p className="text-sm font-semibold text-background">
                    Subscribe to our newsletter
                  </p>
                  <p className="mt-1 text-xs text-background/60">
                    Product updates, logistics tips and Growve news.
                  </p>
                  {subscribed ? (
                    <div className="mt-3 flex items-center gap-2 rounded-lg bg-primary/15 p-3 text-sm text-background">
                      <CheckCircle2 className="h-4 w-4 text-primary" />
                      You’re subscribed. Welcome aboard!
                    </div>
                  ) : (
                    <form onSubmit={handleSubscribe} className="mt-3 flex gap-2">
                      <Input
                        type="email"
                        required
                        placeholder="you@brand.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="border-white/15 bg-white/10 text-background placeholder:text-background/40 focus-visible:ring-primary"
                      />
                      <Button
                        type="submit"
                        disabled={subscribing}
                        className="shrink-0 gap-1.5 rounded-full bg-primary text-primary-foreground hover:bg-primary/90"
                      >
                        {subscribing ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Send className="h-4 w-4" />
                        )}
                      </Button>
                    </form>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Right: form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="lg:col-span-3"
          >
            <Card className="h-full border-border/70">
              <CardContent className="p-8">
                {done ? (
                  <div className="flex h-full min-h-[420px] flex-col items-center justify-center text-center">
                    <span className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
                      <CheckCircle2 className="h-8 w-8" />
                    </span>
                    <h3 className="mt-4 text-xl font-bold text-foreground">
                      Thank you!
                    </h3>
                    <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                      Your message is on its way to our team. We’ll get back to you
                      within one business day.
                    </p>
                    <Button
                      variant="outline"
                      className="mt-6 rounded-full"
                      onClick={() => setDone(false)}
                    >
                      Send another message
                    </Button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-1.5">
                        <Label htmlFor="firstName">
                          First name <span className="text-primary">*</span>
                        </Label>
                        <Input id="firstName" name="firstName" required placeholder="Aarav" />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="lastName">
                          Last name <span className="text-primary">*</span>
                        </Label>
                        <Input id="lastName" name="lastName" required placeholder="Sharma" />
                      </div>
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-1.5">
                        <Label htmlFor="email">
                          Email <span className="text-primary">*</span>
                        </Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          required
                          placeholder="aarav@brand.com"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="phone">Phone</Label>
                        <Input id="phone" name="phone" placeholder="+91 98765 43210" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="company">Company name</Label>
                      <Input id="company" name="company" placeholder="Acme Commerce Pvt. Ltd." />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="message">
                        Message <span className="text-primary">*</span>
                      </Label>
                      <Textarea
                        id="message"
                        name="message"
                        required
                        rows={5}
                        placeholder="Tell us about your business and what you're looking for..."
                      />
                    </div>
                    <Button
                      type="submit"
                      disabled={submitting}
                      className="w-full gap-2 rounded-full sm:w-auto"
                    >
                      {submitting ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4" />
                          Submit
                        </>
                      )}
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
