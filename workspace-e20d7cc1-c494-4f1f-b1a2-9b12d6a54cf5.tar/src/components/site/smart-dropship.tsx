"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Boxes } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { DROPSHIP_FEATURES } from "./data";
import { SectionHeading } from "./section-heading";

export function SmartDropship() {
  return (
    <section id="dropship" className="scroll-mt-20 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="SmartDropship"
          title="Automate dropshipping from order to doorstep"
          subtitle="Forward orders, sync supplier inventory and auto-pick couriers — so you can run a dropship operation without the spreadsheets and the chaos."
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-2">
          {/* Left feature list */}
          <div className="grid gap-5 sm:grid-cols-2">
            {DROPSHIP_FEATURES.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
              >
                <Card className="h-full border-border/70 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-primary/5">
                  <CardContent className="p-5">
                    <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <f.icon className="h-5 w-5" />
                    </span>
                    <h3 className="mt-3 text-sm font-semibold text-foreground">
                      {f.title}
                    </h3>
                    <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                      {f.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Right visual */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="relative overflow-hidden rounded-2xl border border-border bg-gradient-to-br from-primary/10 via-background to-background p-8"
          >
            <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-primary/15 blur-3xl" />
            <div className="relative">
              <div className="flex items-center gap-2 text-primary">
                <Boxes className="h-5 w-5" />
                <span className="text-sm font-semibold">Order flow</span>
              </div>
              <h3 className="mt-3 text-2xl font-bold text-foreground">
                One pipeline. Zero touchpoints.
              </h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Orders flow from your storefront to the right supplier and courier
                automatically — you just watch the deliveries roll in.
              </p>

              <div className="mt-6 space-y-3">
                {[
                  { step: "Order placed", sub: "Customer checks out on your store" },
                  { step: "Auto-routed", sub: "Forwarded to the right supplier" },
                  { step: "Courier picked", sub: "Best rate & ETA selected" },
                  { step: "Delivered", sub: "Buyer gets live updates" },
                ].map((s, i) => (
                  <div key={s.step} className="flex items-start gap-3">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      {i + 1}
                    </span>
                    <div className="flex-1 border-b border-border/60 pb-3">
                      <p className="text-sm font-semibold text-foreground">{s.step}</p>
                      <p className="text-xs text-muted-foreground">{s.sub}</p>
                    </div>
                  </div>
                ))}
              </div>

              <Button asChild className="mt-6 gap-1.5 rounded-full">
                <Link href="#contact">
                  Start dropshipping
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
