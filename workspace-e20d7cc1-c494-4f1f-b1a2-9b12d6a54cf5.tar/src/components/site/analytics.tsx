"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Download, TrendingUp, Wallet, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";

const METRICS = [
  { label: "Logistics cost", value: "₹4.2L", delta: "-8.1%", icon: Wallet, up: false },
  { label: "Delivery success", value: "96.4%", delta: "+3.2%", icon: Truck, up: true },
  { label: "RTO rate", value: "3.6%", delta: "-1.4%", icon: TrendingUp, up: false },
];

export function Analytics() {
  return (
    <section id="analytics" className="scroll-mt-20 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          {/* Copy */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5 }}
          >
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              Analytics &amp; Performance
            </span>
            <h2 className="mt-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Actionable data at your fingertips
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              Unlock comprehensive analytics on logistics costs, courier
              reliability, order lifecycle and revenue leakage from returns.
              Export reports seamlessly for GST, compliance filings, or your
              accounting stack.
            </p>

            <ul className="mt-6 space-y-3">
              {[
                "Courier performance & cost-per-order breakdowns",
                "COD reconciliation and remittance tracking",
                "Return trends and revenue-leakage insights",
                "One-click exports for GST and accounting tools",
              ].map((b) => (
                <li key={b} className="flex items-start gap-3 text-sm text-foreground/80">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                    ✓
                  </span>
                  {b}
                </li>
              ))}
            </ul>

            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild className="gap-1.5 rounded-full">
                <Link href="#contact">
                  Get a Demo
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button variant="outline" className="gap-1.5 rounded-full">
                <Download className="h-4 w-4" />
                Export sample report
              </Button>
            </div>
          </motion.div>

          {/* Visual */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-xl shadow-primary/5">
              <div className="grid grid-cols-3 divide-x divide-border border-b border-border">
                {METRICS.map((m) => (
                  <div key={m.label} className="p-4">
                    <m.icon className="h-4 w-4 text-primary" />
                    <p className="mt-2 text-xl font-bold text-foreground">{m.value}</p>
                    <p className="text-[10px] text-muted-foreground">{m.label}</p>
                    <p
                      className={`mt-1 text-[10px] font-semibold ${
                        m.up ? "text-emerald-600" : "text-primary"
                      }`}
                    >
                      {m.up ? "▲" : "▼"} {m.delta}
                    </p>
                  </div>
                ))}
              </div>

              {/* Line/area chart */}
              <div className="p-5">
                <div className="mb-3 flex items-center justify-between">
                  <p className="text-xs font-medium text-foreground">
                    Monthly delivery performance
                  </p>
                  <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary">
                    Last 8 weeks
                  </span>
                </div>
                <div className="relative h-40 w-full">
                  <svg viewBox="0 0 320 140" className="h-full w-full" preserveAspectRatio="none">
                    <defs>
                      <linearGradient id="area" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="oklch(0.55 0.14 160)" stopOpacity="0.35" />
                        <stop offset="100%" stopColor="oklch(0.55 0.14 160)" stopOpacity="0" />
                      </linearGradient>
                    </defs>
                    <path
                      d="M0,110 L40,90 L80,95 L120,60 L160,70 L200,40 L240,50 L280,25 L320,30 L320,140 L0,140 Z"
                      fill="url(#area)"
                    />
                    <path
                      d="M0,110 L40,90 L80,95 L120,60 L160,70 L200,40 L240,50 L280,25 L320,30"
                      fill="none"
                      stroke="oklch(0.55 0.14 160)"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
                <div className="mt-2 flex justify-between text-[9px] text-muted-foreground">
                  {["W1", "W2", "W3", "W4", "W5", "W6", "W7", "W8"].map((w) => (
                    <span key={w}>{w}</span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
