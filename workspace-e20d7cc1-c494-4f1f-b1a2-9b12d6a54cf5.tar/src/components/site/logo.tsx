import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-2 select-none", className)}>
      <span className="relative inline-flex h-8 w-8 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
        <svg
          viewBox="0 0 24 24"
          fill="none"
          className="h-5 w-5"
          aria-hidden="true"
        >
          <path
            d="M12 2C8 6 6 9 6 13a6 6 0 0 0 12 0c0-4-2-7-6-11Z"
            fill="currentColor"
            fillOpacity="0.95"
          />
          <path
            d="M12 22c3-2.5 4.5-5 4.5-8"
            stroke="oklch(0.16 0.02 170)"
            strokeWidth="1.6"
            strokeLinecap="round"
            fill="none"
          />
        </svg>
      </span>
      <span className="text-xl font-bold tracking-tight text-foreground">
        growve<span className="text-primary">.</span>
      </span>
    </div>
  );
}
