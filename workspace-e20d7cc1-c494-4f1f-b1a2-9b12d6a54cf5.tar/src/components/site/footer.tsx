import Link from "next/link";
import { MapPin, Mail, Users, Linkedin, Twitter, Instagram, Facebook } from "lucide-react";
import { Logo } from "./logo";
import { COMPANY, NAV_LINKS } from "./data";

const FOOTER_LINKS: { title: string; links: { label: string; href: string }[] }[] = [
  {
    title: "Product",
    links: [
      { label: "Features", href: "#features" },
      { label: "Smart Shipping", href: "#smart-shipping" },
      { label: "SmartDropship", href: "#dropship" },
      { label: "Analytics", href: "#analytics" },
      { label: "Pricing", href: "#pricing" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About Us", href: "#about" },
      { label: "FAQs", href: "#faqs" },
      { label: "Contact", href: "#contact" },
      { label: "Book a Demo", href: "#contact" },
      { label: "Log In", href: "#login" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy and Policy", href: "#" },
      { label: "Terms & Conditions", href: "#" },
      { label: "Cookie Policy", href: "#" },
    ],
  },
];

const SOCIALS = [
  { icon: Linkedin, href: "#", label: "LinkedIn" },
  { icon: Twitter, href: "#", label: "Twitter" },
  { icon: Instagram, href: "#", label: "Instagram" },
  { icon: Facebook, href: "#", label: "Facebook" },
];

export function Footer() {
  return (
    <footer className="mt-auto border-t border-border bg-foreground text-background">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-12">
          {/* Brand + contact */}
          <div className="lg:col-span-4">
            <div className="flex items-center gap-2">
              <span className="relative inline-flex h-8 w-8 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5" aria-hidden="true">
                  <path
                    d="M12 2C8 6 6 9 6 13a6 6 0 0 0 12 0c0-4-2-7-6-11Z"
                    fill="currentColor"
                    fillOpacity="0.95"
                  />
                  <path
                    d="M12 22c3-2.5 4.5-5 4.5-8"
                    stroke="oklch(0.16 0.02 170)"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    fill="none"
                  />
                </svg>
              </span>
              <span className="text-xl font-bold tracking-tight text-background">
                growve<span className="text-primary">.</span>
              </span>
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-background/60">
              A next-generation logistics-tech platform for eCommerce and D2C
              brands. Ship smarter, save more and grow faster.
            </p>

            <ul className="mt-6 space-y-3 text-sm">
              <li className="flex gap-2.5 text-background/70">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <span>{COMPANY.address}</span>
              </li>
              <li className="flex gap-2.5 text-background/70">
                <Mail className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <a href={`mailto:${COMPANY.email}`} className="hover:text-primary">
                  {COMPANY.email}
                </a>
              </li>
              <li className="flex gap-2.5 text-background/70">
                <Users className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <span>
                  We’re hiring —{" "}
                  <a
                    href={`mailto:${COMPANY.careersEmail}`}
                    className="text-primary hover:underline"
                  >
                    {COMPANY.careersEmail}
                  </a>
                </span>
              </li>
            </ul>

            <div className="mt-6 flex gap-2">
              {SOCIALS.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 text-background/70 transition-colors hover:border-primary hover:bg-primary hover:text-primary-foreground"
                >
                  <s.icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Link columns */}
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-8">
            {FOOTER_LINKS.map((col) => (
              <div key={col.title}>
                <p className="text-sm font-semibold text-background">{col.title}</p>
                <ul className="mt-4 space-y-2.5">
                  {col.links.map((link) => (
                    <li key={link.label}>
                      <Link
                        href={link.href}
                        className="text-sm text-background/60 transition-colors hover:text-primary"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Company name + copyright */}
        <div className="mt-12 border-t border-white/10 pt-6">
          <p className="text-xs uppercase tracking-wide text-background/40">
            {COMPANY.name}
          </p>
          <p className="mt-2 text-xs text-background/50">
            © {COMPANY.year} Growve.in. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
