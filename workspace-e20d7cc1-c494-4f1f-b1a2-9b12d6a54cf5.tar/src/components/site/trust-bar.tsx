"use client";

import { CHANNELS } from "./data";

export function TrustBar() {
  const items = [...CHANNELS, ...CHANNELS];
  return (
    <section className="border-y border-border/60 bg-muted/30 py-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <p className="text-center text-xs font-medium uppercase tracking-widest text-muted-foreground">
          Integrated with the marketplaces &amp; couriers you already use
        </p>
        <div className="relative mt-6 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_12%,black_88%,transparent)]">
          <div className="flex w-max animate-marquee items-center gap-10">
            {items.map((c, i) => (
              <div
                key={`${c.name}-${i}`}
                className="flex shrink-0 items-center gap-2 opacity-70 transition-opacity hover:opacity-100"
              >
                <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-card text-xs font-bold text-foreground/70">
                  {c.short}
                </span>
                <span className="text-sm font-semibold text-foreground/70">
                  {c.name}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
