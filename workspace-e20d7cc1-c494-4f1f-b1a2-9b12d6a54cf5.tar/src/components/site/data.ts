import type { LucideIcon } from "lucide-react";
import {
  Route,
  BarChart3,
  BellRing,
  Plug,
  Boxes,
  ShieldCheck,
  RefreshCw,
  Wallet,
  MapPin,
  FileText,
  Bot,
  Settings2,
  Zap,
} from "lucide-react";

export const NAV_LINKS: { label: string; href: string }[] = [
  { label: "Features", href: "#features" },
  { label: "Smart Shipping", href: "#smart-shipping" },
  { label: "SmartDropship", href: "#dropship" },
  { label: "Pricing", href: "#pricing" },
  { label: "About", href: "#about" },
  { label: "FAQs", href: "#faqs" },
  { label: "Contact", href: "#contact" },
];

export const CHANNELS: { name: string; short: string }[] = [
  { name: "Amazon", short: "AMZ" },
  { name: "Flipkart", short: "FK" },
  { name: "Meesho", short: "ME" },
  { name: "Shopify", short: "SH" },
  { name: "WooCommerce", short: "WC" },
  { name: "Myntra", short: "MY" },
];

export type Feature = {
  icon: LucideIcon;
  title: string;
  description: string;
  bullets: string[];
};

export const WHY_FEATURES: Feature[] = [
  {
    icon: Settings2,
    title: "Easy Setup",
    description:
      "Be live in minutes with a guided, plug-and-play onboarding. No engineering tickets, no code — connect your stores and ship the same day.",
    bullets: [
      "Step-by-step onboarding wizard",
      "Zero-code store connection",
      "Pre-built courier presets",
    ],
  },
  {
    icon: Wallet,
    title: "Smart Budgeting",
    description:
      "Keep shipping and operating spend in check with live cost visibility and AI-driven courier picks on every single order.",
    bullets: [
      "AI courier recommendations",
      "Per-shipment cost breakdown",
      "Returns & RTO cost control",
    ],
  },
  {
    icon: BellRing,
    title: "Shipment Alerts",
    description:
      "Send buyers automated shipment updates right to their inbox — fewer “where is my order?” tickets and a noticeably better experience.",
    bullets: [
      "Live shipment updates",
      "Smoother buyer experience",
      "Higher first-attempt success",
    ],
  },
  {
    icon: Plug,
    title: "API Integration",
    description:
      "From marketplace APIs to order and shipment workflows, everything plugs into one secure, unified layer that scales as you grow.",
    bullets: [
      "Marketplace & ERP connectors",
      "Automated courier assignment",
      "Real-time tracking webhooks",
    ],
  },
];

export type ShippingStep = {
  no: string;
  title: string;
  description: string;
  icon: LucideIcon;
};

export const UNIFIED_STEPS: ShippingStep[] = [
  {
    no: "01",
    title: "Unified Order Management",
    description:
      "Pull orders from Amazon, Flipkart, Meesho, Shopify, WooCommerce, Myntra and your own storefront into one control center.",
    icon: Boxes,
  },
  {
    no: "02",
    title: "Courier Partner Integration",
    description:
      "Tap into 15+ trusted couriers, compare rates, coverage and delivery speed, and pick the most reliable, cost-effective option.",
    icon: Route,
  },
  {
    no: "03",
    title: "One-Click Labels & Docs",
    description:
      "Generate labels, invoices and manifests in bulk with a single click and automate pickup requests for a clean dispatch flow.",
    icon: FileText,
  },
];

export const RETURNS_STEPS: ShippingStep[] = [
  {
    no: "01",
    title: "Hassle-Free Returns",
    description:
      "Handle returns and failed deliveries (RTO) with detailed NDR insights, re-delivery triggers and stronger recovery rates.",
    icon: RefreshCw,
  },
  {
    no: "02",
    title: "Seamless COD Settlement",
    description:
      "Automate cash-on-delivery reconciliation across couriers, flag delays instantly and keep your books accurate.",
    icon: Wallet,
  },
  {
    no: "03",
    title: "Transparent Refund Tracking",
    description:
      "See the full lifecycle of refunds and buyer reimbursements — pending, approved and completed — from a single view.",
    icon: ShieldCheck,
  },
];

export const SHIPPING_SOLUTIONS: {
  icon: LucideIcon;
  title: string;
  description: string;
}[] = [
  {
    icon: MapPin,
    title: "Real-Time Shipment Tracking",
    description:
      "Live updates on every shipment for total transparency, so you can resolve issues before buyers even notice them.",
  },
  {
    icon: Route,
    title: "Automated Carrier Routing",
    description:
      "Route packages through the fastest, most cost-effective carriers automatically to save both time and money.",
  },
  {
    icon: BarChart3,
    title: "Cost & Performance Analytics",
    description:
      "Slice shipping performance, cost-per-order and delivery efficiency to keep sharpening your logistics strategy.",
  },
  {
    icon: Bot,
    title: "Smart Alert Messaging",
    description:
      "Auto-detect delivery delays and send compliant buyer notifications through official APIs to set the right expectations.",
  },
];

export const DROPSHIP_FEATURES: {
  icon: LucideIcon;
  title: string;
  description: string;
}[] = [
  {
    icon: Zap,
    title: "Automated Order Routing",
    description:
      "Forward orders to the right supplier or warehouse the moment they land, with rules you control end-to-end.",
  },
  {
    icon: Boxes,
    title: "Supplier Inventory Sync",
    description:
      "Keep supplier stock mirrored across every channel so listings stay accurate and overselling stays at zero.",
  },
  {
    icon: Route,
    title: "Smart Courier Selection",
    description:
      "Auto-pick the best courier per drop based on pincode, weight, cost and delivery promise.",
  },
  {
    icon: ShieldCheck,
    title: "SLA & Compliance Guardrails",
    description:
      "Monitor dispatch and delivery SLAs in real time and trigger alerts before a breach ever happens.",
  },
];

export const STATS: { value: string; label: string; sub: string }[] = [
  { value: "13+", label: "Multi-Courier Visibility", sub: "Compare every provider in one dashboard" },
  { value: "99%", label: "Robust Uptime", sub: "A stable platform built for scale" },
  { value: "24/7", label: "Assistance", sub: "Continuous support to keep ops smooth" },
  { value: "15+", label: "Marketplace Integrations", sub: "Amazon, Flipkart, Meesho & more" },
];

export type Faq = { q: string; a: string };

export const FAQS: Faq[] = [
  {
    q: "What is Amazon SP-API integration?",
    a: "It’s a secure connection between your Amazon seller account and Growve. Once linked, orders, inventory and sales data flow automatically — so you stop manually exporting reports and start managing everything from one screen.",
  },
  {
    q: "How does Flipkart API integration help my business?",
    a: "It removes the manual heavy-lifting on Flipkart: orders come in automatically, stock stays in sync, and you get a clear view of performance without jumping between dashboards.",
  },
  {
    q: "Can I manage Amazon and Flipkart orders from one dashboard?",
    a: "Yes. Growve brings both marketplaces into a single workspace, so you can track, update and fulfill orders from Amazon and Flipkart side by side.",
  },
  {
    q: "Is my data secure with these integrations?",
    a: "We use official developer credentials and strict access controls. Your data is encrypted in transit and at rest, and only authorized users on your team can reach it.",
  },
  {
    q: "Will the system prevent overselling?",
    a: "Yes. Inventory is synced in real time across connected channels, so stock levels stay consistent and the risk of overselling drops dramatically.",
  },
  {
    q: "Can I track returns and refunds through Growve?",
    a: "Absolutely. Return requests from your connected marketplaces land in one view, where you can track status, trigger resolutions and follow refunds through to completion.",
  },
  {
    q: "Do I need technical knowledge to use it?",
    a: "Not at all. Growve is built for operators. If you can use a spreadsheet, you can run integrations, manage orders and read reports here.",
  },
  {
    q: "What kind of reports do I get?",
    a: "You get sales, financial and performance reports — revenue, margins, product-level performance and courier analytics — exportable for GST, compliance or your accounting tools.",
  },
  {
    q: "Is it scalable for high-volume sellers?",
    a: "Yes. The platform is engineered for high transaction volumes and stays performant through peak seasons and flash-sale spikes.",
  },
  {
    q: "How do I get started?",
    a: "Create your Growve account, add your API credentials for the marketplaces you sell on, and our support team will guide you through a quick setup — often completed the same day.",
  },
];

export const COMPANY = {
  name: "GROWVE RETAIL AND MANAGEMENT SERVICES PRIVATE LIMITED",
  short: "growve.",
  address:
    "Unit no. 404, Filix Tower, LBS Marg, Opp. Asian Paints, Sonapur, Bhandup West, Mumbai, Maharashtra 400078",
  email: "admin@growve.in",
  careersEmail: "people@growve.in",
  year: "2025",
};
