"use client";

import { motion } from "framer-motion";
import { Target, Eye, Rocket, Cpu, LineChart, HeartHandshake } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { SectionHeading } from "./section-heading";

const PILLARS = [
  {
    icon: Cpu,
    title: "Smart automation",
    text: "SmartDropship, Smart Shipping and analytics working as one — automating routing, shipping, returns, tracking and finance across every channel.",
  },
  {
    icon: LineChart,
    title: "Insight-driven",
    text: "Live dashboards for courier performance, COD reconciliation and return trends, so decisions are backed by data, not guesswork.",
  },
  {
    icon: HeartHandshake,
    title: "Customer-centric",
    text: "Responsive support and a platform engineered to cut errors, control costs and keep your buyers coming back.",
  },
];

export function About() {
  return (
    <section id="about" className="scroll-mt-20 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="About growve."
          title="Empowering e-commerce with smarter logistics"
          subtitle="We simplify shipping for modern brands — from seamless API integrations to AI-powered courier selection — bringing all your logistics needs into one powerful platform."
        />

        {/* Mission & Vision */}
        <div className="mt-14 grid gap-6 lg:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5 }}
          >
            <Card className="h-full border-border/70">
              <CardContent className="p-8">
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <Target className="h-6 w-6" />
                </span>
                <h3 className="mt-4 text-xl font-bold text-foreground">Our Mission</h3>
                <p className="mt-3 leading-relaxed text-muted-foreground">
                  Give online sellers a logistics backbone that just works — so
                  they can sell on more channels without drowning in operations.
                  We handle the order-to-delivery pipeline end to end, freeing
                  founders to spend their hours on growth instead of spreadsheets.
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card className="h-full border-border/70">
              <CardContent className="p-8">
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <Eye className="h-6 w-6" />
                </span>
                <h3 className="mt-4 text-xl font-bold text-foreground">Our Vision</h3>
                <p className="mt-3 leading-relaxed text-muted-foreground">
                  A world where running a multi-channel e-commerce business feels
                  effortless. We’re building the intelligent tools and
                  integrations that turn complex fulfillment into a calm,
                  predictable flow — so merchants can scale with confidence.
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Who we are */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5 }}
          className="mt-6 rounded-2xl border border-border/70 bg-muted/30 p-8 sm:p-10"
        >
          <div className="flex items-center gap-2 text-primary">
            <Rocket className="h-5 w-5" />
            <span className="text-sm font-semibold">Who we are &amp; what drives us</span>
          </div>
          <p className="mt-3 max-w-3xl leading-relaxed text-muted-foreground">
            Founded in 2025 and headquartered in Mumbai, Growve was built by a
            team that has lived through the pain of inventory mismatches, RTO
            headaches and delayed shipments. We turn that first-hand frustration
            into automation that feels intuitive, scales reliably and never gets
            in your way — because every feature is shaped by the sellers who use
            it.
          </p>

          <div className="mt-8 grid gap-5 sm:grid-cols-3">
            {PILLARS.map((p) => (
              <div key={p.title} className="rounded-xl border border-border/60 bg-card p-5">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <p.icon className="h-5 w-5" />
                </span>
                <h4 className="mt-3 text-sm font-semibold text-foreground">{p.title}</h4>
                <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                  {p.text}
                </p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
