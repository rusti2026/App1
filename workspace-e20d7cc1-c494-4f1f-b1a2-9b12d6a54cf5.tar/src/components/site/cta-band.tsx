"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, CalendarCheck } from "lucide-react";
import { Button } from "@/components/ui/button";

export function CtaBand() {
  return (
    <section className="py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5 }}
          className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary to-emerald-600 px-6 py-14 text-center shadow-xl shadow-primary/20 sm:px-12"
        >
          <div className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/15 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-20 -left-12 h-56 w-56 rounded-full bg-white/10 blur-3xl" />
          <div className="relative mx-auto max-w-2xl">
            <h2 className="text-3xl font-extrabold tracking-tight text-primary-foreground sm:text-4xl">
              Ready to ship smarter and grow faster?
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-primary-foreground/80">
              Book a free demo and see how Growve unifies your orders, couriers,
              returns and analytics into one powerful platform.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button
                size="lg"
                asChild
                className="w-full gap-2 rounded-full bg-background text-foreground hover:bg-background/90 sm:w-auto"
              >
                <Link href="#contact">
                  <CalendarCheck className="h-4 w-4" />
                  Book a Demo
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                className="w-full gap-2 rounded-full border-white/30 bg-transparent text-primary-foreground hover:bg-white/10 hover:text-primary-foreground sm:w-auto"
              >
                <Link href="#pricing">
                  View pricing
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
