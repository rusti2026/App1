import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "growve. — Logistics-Tech SaaS for eCommerce & D2C Brands",
  description:
    "Growve is a next-generation logistics-tech platform for eCommerce and D2C brands. Multi-channel order management, smart shipping, courier aggregation, returns, and analytics — all in one place.",
  keywords: [
    "Growve",
    "logistics SaaS",
    "eCommerce shipping",
    "multi-channel seller",
    "Amazon SP-API",
    "Flipkart API",
    "courier aggregator",
    "D2C logistics",
    "smart shipping",
    "order management",
  ],
  authors: [{ name: "Growve Retail and Management Services Pvt. Ltd." }],
  openGraph: {
    title: "growve. — Logistics-Tech SaaS for eCommerce & D2C Brands",
    description:
      "Powerful logistics-tech platform for eCommerce and D2C brands. Smart shipping, multi-channel integration, returns, and analytics.",
    url: "https://www.growve.in",
    siteName: "growve.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "growve. — Logistics-Tech SaaS",
    description:
      "Next-generation logistics-tech platform for eCommerce and D2C brands.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
