import { Header } from "@/components/site/header";
import { Hero } from "@/components/site/hero";
import { TrustBar } from "@/components/site/trust-bar";
import { MultiChannel } from "@/components/site/multi-channel";
import { WhyGrowve } from "@/components/site/why-growve";
import { SmartShipping } from "@/components/site/smart-shipping";
import { SmartDropship } from "@/components/site/smart-dropship";
import { Analytics } from "@/components/site/analytics";
import { Pricing } from "@/components/site/pricing";
import { About } from "@/components/site/about";
import { Faqs } from "@/components/site/faqs";
import { CtaBand } from "@/components/site/cta-band";
import { Contact } from "@/components/site/contact";
import { Footer } from "@/components/site/footer";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header />
      <main className="flex-1">
        <Hero />
        <TrustBar />
        <MultiChannel />
        <WhyGrowve />
        <SmartShipping />
        <SmartDropship />
        <Analytics />
        <Pricing />
        <About />
        <Faqs />
        <CtaBand />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
