import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";

const contactSchema = z.object({
  type: z.literal("newsletter").optional(),
  firstName: z.string().min(1).max(80).optional(),
  lastName: z.string().min(1).max(80).optional(),
  email: z.string().email().max(160),
  phone: z.string().max(40).optional(),
  company: z.string().max(160).optional(),
  message: z.string().max(5000).optional(),
});

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const parsed = contactSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 422 }
    );
  }

  const data = parsed.data;

  try {
    if (data.type === "newsletter") {
      await db.newsletterSubscriber.upsert({
        where: { email: data.email },
        update: {},
        create: { email: data.email },
      });
      return NextResponse.json({ ok: true, type: "newsletter" });
    }

    if (!data.firstName || !data.lastName || !data.message) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 422 }
      );
    }

    const submission = await db.contactSubmission.create({
      data: {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        phone: data.phone ?? null,
        company: data.company ?? null,
        message: data.message,
      },
    });

    return NextResponse.json({
      ok: true,
      type: "contact",
      id: submission.id,
    });
  } catch (err) {
    console.error("[api/contact] error:", err);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    message: "Growve contact API. Send a POST request to submit a message.",
  });
}
