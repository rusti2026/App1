# MERIDIAN — Trading Platform Architecture
### "Bloomberg Terminal meets Robinhood" — dark-first, real-time, bank-grade

---

## 1. System Architecture (Text Diagram)

### 1a. Production Target Architecture (reference)

```
                            ┌──────────────────────────────────────────────┐
                            │                   CLIENTS                    │
                            │   Next.js PWA (Web)  ·  iOS/Android (RN)     │
                            └───────────────┬──────────────────────────────┘
                                            │ TLS 1.3 / WSS
                                    ┌───────▼───────┐
                                    │  CDN + WAF    │  CloudFront + AWS WAF (DDoS, bots)
                                    │  (static)     │
                                    └───────┬───────┘
                                    ┌───────▼───────┐
                                    │ API Gateway   │  AuthN/Z, rate-limit, request-id
                                    └───┬───────┬───┘
              REST/WS (market, social) │       │ gRPC (trading, ledger — low latency)
        ┌──────────────────────────────▼─┐   ┌─▼──────────────────────────────┐
        │  Market Data Service           │   │  Trading Engine Service         │
        │  · ingests venue feeds         │   │  · order validation (SOD rules) │
        │  · normalizes ticks (pb/avro)  │   │  · risk checks (buying power)   │
        │  · fans out via Redis pub/sub  │   │  · order book / matching sim    │
        │  · OHLCV aggregation           │   │  · execution reports            │
        └───────┬───────────────┬────────┘   └───────┬───────────────┬────────┘
                │               │                    │               │
        ┌───────▼───┐   ┌───────▼────────┐   ┌───────▼───────┐  ┌────▼─────────┐
        │  Redis    │   │   Kafka        │   │  Ledger Svc   │  │ Broker Adapter│
        │  cluster  │   │  (event bus)   │   │  (double-entry│  │ Alpaca/IBKR/  │
        │  cache +  │   │  topics:       │   │   immutable)  │  │ Binance FIX/WS│
        │  pub/sub  │   │  orders,fills, │   └───────┬───────┘  └────┬─────────┘
        └───────┬───┘   │  ticks,kyc     │           │               │
                │       └───────┬────────┘   ┌───────▼──────────────────────────┐
        ┌───────▼───────────────▼────────────▼───────────┐                      │
        │  PostgreSQL (RDS, multi-AZ, PITR)              │◀─────────────────────┘
        │  Users · Wallets · Ledger · Orders · Trades    │   (idempotent consumers)
        │  Assets · Positions · KYC · Audit (append-only)│
        └────────────────────────────────────────────────┘
                │
        ┌───────▼───────────┐   ┌────────────────┐  ┌─────────────────────┐
        │ Workers (K8s)     │   │ KYC/AML Vendor │  │ Payments/Banking    │
        │ · settlements     │   │ Onfido/Stripe  │  │ Plaid (ACH links)   │
        │ · statements/tax  │   │ Identity       │  │ Iron Mountain wires │
        │ · risk jobs       │   └────────────────┘  └─────────────────────┘
        └───────────────────┘
```

**Key decisions**
- **Event-driven core**: every state change (order→fill→ledger→notification) is a Kafka event; services are idempotent consumers. This gives replay/audit + horizontal scale.
- **Ledger is append-only, double-entry**: balances are *derived*, never mutated in place. This is the fintech correctness backbone (reconcilable to the cent).
- **Money as integer minor units** (cents/satoshis). Never floats.
- **WS fan-out**: Socket.io (Redis adapter) for 10k+ connections per pod; sticky sessions at ingress; per-user topic authorization.
- **OWASP**: parameterized queries (Prisma), CSP + strict headers, CSRF via SameSite + Origin checks + custom header, argon/scrypt password KDF, AES-256-GCM field-level encryption for secrets at rest, RBAC middleware, audit log on every privileged action.

### 1b. Sandbox Implementation (this repo — faithful subset)

Sandbox constraint mapping (dev parity preserved; prod path documented):

| Production      | Sandbox implementation                          |
|-----------------|--------------------------------------------------|
| PostgreSQL      | Prisma + SQLite (schema kept PG-portable)        |
| Redis pub/sub   | In-memory event bus + memory cache               |
| Kafka           | In-process event queue (same event shapes)       |
| NestJS services | Next.js Route Handlers (`/api/*`, "use server")  |
| Socket.io svc   | Mini-service `mini-services/*` (Phase 2)         |
| K8s/Docker      | Single node process, Caddy gateway               |

```
Browser (SPA at /)
   │  fetch (same-origin)          WebSocket (Phase 2: /?XTransformPort=3003)
   ▼
Next.js 16 ── /api/auth/*      ── security core (scrypt, JWT, TOTP, AES-GCM)
   │         /api/kyc/*            rate limiter, audit log, RBAC
   │         /api/portfolio/*   ── Prisma (SQLite) ← ledger is source of truth
   │         /api/market/*      ── seeded assets (Phase 2: simulated feed svc)
   ▼
db/custom.db  +  worklog.md (agent coordination)
```

### 1c. Confirmed Production Architecture — India (client-approved)

Target stack confirmed by product owner (SEBI-regulated India brokerage):

```
CLIENT LAYER     Mobile (Flutter/RN) · Web (Next.js + TS) · Admin console · Algo/API clients (REST+WS keys)
                     │
API GATEWAY      OAuth 2.0 + JWT · rate limiting · circuit breakers · TLS 1.3
                     │
MICROSERVICES    Order service (validation·routing·OMS) · Risk engine (SPAN margin·limits·kill-switch)
                 Portfolio service (holdings·P&L·ledger) · Payments+notify (UPI·push/SMS/email)
                     │
DATA LAYER       PostgreSQL (orders·users·ledger OLTP) · TimescaleDB (ticks·OHLC·history)
                 Redis (live quotes·sessions·pub/sub)
                     │
REAL-TIME PIPE   Market data ingestion (exchange feed handlers) → Kafka (tick buffer + aggregation)
                 → WebSocket gateway (10k+ concurrent streams)
                     │
EXTERNAL         Exchange/broker APIs (NSE·BSE·MCX · Zerodha Kite · Angel One)
                 Third-party (KYC DigiLocker · UPI gateway · SMS/email)

ORDER PATH (write):  App taps Buy → Risk check → Route to exchange → Fill/reject → Update ledger + push via WS
MARKET DATA (read):  Exchange tick feed → Kafka buffer → Aggregate → Redis hot cache → WS push to apps · persist to TimescaleDB
```

**Invariants (from diagrams):** risk engine is ALWAYS in the order path; order confirmations flow back async over WS; market data path is strictly read-optimized (hot cache first, persistence async).

### 1d. Sandbox mapping of the confirmed architecture (this repo)

| Confirmed production component | Sandbox implementation |
|---|---|
| Exchange feed handlers (NSE/BSE) | `mini-services/market-data-service` simulated tick generator |
| Kafka tick buffer + aggregation | In-process event bus inside the market-data service (same event shapes) |
| Redis hot cache | In-memory `Map<symbol, TickQuote>` + `GET /quotes` |
| WebSocket gateway (10k+) | socket.io on port 3003 via Caddy `?XTransformPort=3003` |
| Order service + OMS | `POST /api/orders`, `GET /api/orders`, cancel route (Next.js handlers) |
| Risk engine (in order path) | `src/lib/trading/risk.ts` — every order passes through it |
| Broker routing (Kite/Angel One) | `src/lib/trading/matcher.ts` simulated exchange matcher |
| Portfolio service (holdings·P&L·ledger) | `/api/portfolio/summary`, `src/lib/trading/engine.ts` (double-entry ledger) |
| "order confirmations" async arrow | `POST /internal/emit` (shared secret) → WS room `user:{id}` → `order-update` |
| DigiLocker KYC · UPI · SMS | Simulated (Phase 1 KYC reviewer; UPI in M4–M6 slice) |

---

## 2. Database Schema Design (core tables)

Full Prisma schema lives in `prisma/schema.prisma`. Money = **Int minor units** (paise for INR wallets). No floats.

| Table          | Purpose / key fields                                                                 |
|----------------|--------------------------------------------------------------------------------------|
| `User`         | identity: email(unique), phone, passwordHash(scrypt), role(USER/ADMIN), status, mfaEnabled, mfaSecretEnc(AES-256-GCM) |
| `Session`      | server-side revocable sessions: jti, tokenHash, expiresAt, ip, userAgent, revokedAt  |
| `OtpChallenge` | email/SMS OTP: destination, channel, purpose, codeHash(sha256), attempts, expiresAt  |
| `KycProfile`   | 1:1 User: legalName, dob, address, taxIdLast4(encrypted), docType/Number(encrypted), pep, status(PENDING/APPROVED/REJECTED), riskRating |
| `Wallet`       | 1:1 User: cashAvailableCents, cashPendingCents (cache; derived from ledger)          |
| `LedgerEntry`  | append-only: walletId, direction(CREDIT/DEBIT), category(DEPOSIT/TRADE/FEE/ADJUSTMENT), amountCents, balanceAfterCents, refType/refId |
| `Transaction`  | funds movement: walletId, type(DEPOSIT/WITHDRAWAL), method(ACH/WIRE/CRYPTO), amountCents, status, reference, settledAt |
| `Asset`        | symbol PK, name, type(STOCK/CRYPTO/ETF), exchange, last/prevClose/high/low (cents), volume |
| `PriceBar`     | OHLCV: @@id([symbol,t]) — charting (Phase 2)                                         |
| `WatchlistItem`| @@id([userId, symbol])                                                               |
| `Position`     | userId+symbol unique: qty, avgCostCents (Phase 3)                                    |
| `Order`        | side, type(MARKET/LIMIT/STOP/STOP_LIMIT), qty, limit/stop price, TIF, status, fills (Phase 3) |
| `Trade`        | execution records: orderId, qty, priceCents, feeCents (Phase 3)                      |
| `AuditLog`     | append-only security trail: userId?, action, ip, userAgent, detail                   |

Relationships: User 1—1 Wallet/KycProfile; Wallet 1—N LedgerEntry/Transaction; User 1—N Session/Order/WatchlistItem; Asset 1—N PriceBar/WatchlistItem/Order/Position.

---

## 3. Delivery Roadmap (client-approved M1–M18)

Client milestones mapped to sandbox build phases:

| Window | Milestone (production) | Sandbox build (this repo) | Status |
|---|---|---|---|
| **M1–M2** Foundation | SEBI/broker partnership · KYC+auth (DigiLocker, OTP, biometrics) · app shell & design system · CI/CD, cloud accounts | **Phase 1** — security core (scrypt/JWT/TOTP/AES-256-GCM), email+OTP auth, MFA, KYC wizard (simulated reviewer), wallet + double-entry ledger, dashboard shell, design system | ✅ shipped (browser-verified) |
| **M2–M4** Core trading loop | Market data ingestion → Kafka → WS gateway · watchlists + live quotes · order placement (market/limit/SL) via broker API · portfolio + holdings | **Phase 2 (current)** — market-data mini-service (simulated exchange feed → event bus → hot cache → socket.io gateway on :3003), live watchlist/tape/movers, order service + risk engine + simulated broker matcher (MARKET/LIMIT/STOP/STOP_LIMIT), positions/holdings with live P&L, order confirmations over WS | 🚧 this delivery |
| **M4–M6** MVP hardening + launch | Candlestick charts + indicators · funds via UPI · notifications · load test (10k WS) · pen-test · store release | **Phase 3** — lightweight-charts candles w/ SMA/RSI, depth view, UPI deposit simulation, notifications, load profile, hardening | ⏳ next |
| **M7–M9** Trading depth | BO/CO/GTT · margin engine (SPAN + exposure) · risk limits + kill-switch · option chain w/ Greeks · advanced charting | **Phase 4** — margin engine (CNC 1x / MIS 5x, exposure-aware), CO/BO legs + OCO + exit, notifications center, runtime kill-switch console (GTT shipped in Phase 3; option chain → Phase 5) | ✅ shipped (browser-verified) |
| **M9–M12** Scale + retention | Algo trading API · paper trading · screeners + price alerts · IPO + mutual funds · multi-language · K8s autoscaling | **Phase 5** — API keys, screeners, admin console, CI/CD + K8s manifests | ⏳ |
| **M13–M18** Full broker (optional) | Direct exchange connectivity · co-location · own OMS · DR site · 99.99% SLA · SEBI audit cycles | Out of sandbox scope (production track) | — |

---

## 4. Phase 1 API Contract (implemented now)

All responses JSON. Mutations require same-origin `Origin` header (auto) — helper `apiFetch` also sends `x-requested-with: meridian-web`. Session = httpOnly cookie `meridian_session` (HS256 JWT, jti ↔ `Session` row, 7d).

| Endpoint | Method | Body | Response |
|---|---|---|---|
| `/api/health` | GET | — | `{ ok, time, db }` |
| `/api/auth/session` | GET | — | `{ authenticated: boolean, user?: { id, email, name, role, status, mfaEnabled, phoneVerified, kycStatus, onboardingDone } }` |
| `/api/auth/register` | POST | `{ email, password, name }` | `{ user }` + sets cookie; errors: `400` zod, `409` email taken |
| `/api/auth/login` | POST | `{ email, password }` | `{ status: "ok" }` sets cookie, OR `{ status: "mfa_required", tempToken }` (10 min) |
| `/api/auth/login/mfa` | POST | `{ tempToken, code }` | `{ status: "ok" }` sets cookie |
| `/api/auth/logout` | POST | — | `{ ok: true }` clears+revokes |
| `/api/auth/otp/request` | POST | `{ channel: "EMAIL"\|"SMS", destination }` | `{ challengeId, expiresAt, devCode }` — devCode shown in UI (no SMS gateway in sandbox) |
| `/api/auth/otp/verify` | POST | `{ challengeId, code }` | `{ verified: true }` marks phone/email verified |
| `/api/auth/mfa/setup` | POST | — | `{ secret, otpauthUri, qrDataUrl }` (not yet enabled) |
| `/api/auth/mfa/enable` | POST | `{ code }` | `{ enabled: true }` |
| `/api/auth/mfa/disable` | POST | `{ password }` | `{ enabled: false }` |
| `/api/kyc/submit` | POST | `{ legalFirstName, legalLastName, dateOfBirth, country, address1, address2?, city, region, postalCode, taxIdLast4, docType, docNumber, pep }` | `{ status: "PENDING" }` (simulated reviewer auto-approves ~5s after submit, on poll) |
| `/api/kyc/status` | GET | — | `{ status, onboardingDone }` |
| `/api/portfolio/summary` | GET | — | `{ cashAvailableCents, cashPendingCents, positionsValueCents, totalEquityCents, dayPnlCents, dayPnlPct, positions: [], ledger: LedgerEntry[≤10] }` |
| `/api/market/overview` | GET | — | `{ movers: [{ symbol, name, type, lastPriceCents, changeCents, changePct, volume }], indices: [...] }` |
| `/api/watchlist` | GET/POST/DELETE | `{ symbol }` | `{ items: [...] }` |

Errors: `{ error: string, code?: string }` with proper HTTP status. Zod-validated bodies. Generic auth errors (no user enumeration). All auth events → AuditLog.

---

## 5. Design System Spec (frontend)

**Brand**: MERIDIAN — Markets, in motion. Wordmark: `MERIDIAN` letterspaced caps + `▲▼` tick motif.

**Rules (non-negotiable)**
- Dark mode **default** (class strategy via next-themes). Light mode toggle in header.
- NO blue/indigo anywhere. Palette:
  - `--profit` / up / buy: emerald `#22c07a` (oklch ~0.72 0.17 160)
  - `--loss` / down / sell: red `#ef5350`
  - `--terminal` accent (Bloomberg touch): amber `#f5a623`
  - background near-black with faint green cast (`#0a0e0d`), cards `#101513`
- All numerals: `font-mono tabular-nums` (Geist Mono already loaded).
- Sticky footer: root `min-h-screen flex flex-col`, footer `mt-auto`, safe-area `pb-[env(safe-area-inset-bottom)]`.
- Lists (watchlist/movers/ledger): `max-h-96 overflow-y-auto` + custom thin scrollbar.
- Touch targets ≥44px; `sr-only` labels; semantic HTML; loading skeletons; sonner toasts.
- Motion: framer-motion, subtle (fade/slide 150–250ms). Ticker tape: CSS marquee, `prefers-reduced-motion` respected.

**App shell (single route `/` — SPA view state machine)**

`landing → auth (login|signup|otp|mfa) → onboarding (KYC wizard) → dashboard`

Session bootstrap: `GET /api/auth/session` on mount (TanStack Query) → route to view. Zustand holds UI state (view, authStep, tempToken). Guard: dashboard requires authenticated; onboarding shown when `kycStatus !== "APPROVED"`.

**Views**
1. **Landing**: sticky glass header (logo, theme toggle, CTA). Hero: headline, sub, CTAs, live-looking ticker tape (from `/api/market/overview`, marquee). Stats band. Feature grid (real-time data, paper trading, bank-grade security, ledger transparency). Footer: sticky, © MERIDIAN (demo), disclaimer "Paper trading simulation — not investment advice."
2. **Auth**: centered card. Tabs Login/Signup. Signup: name, email, password (strength meter, zod ≥10 chars + complexity). Login → if `mfa_required`: input-otp step with tempToken. Link "Verify with one-time code" → OTP flow (channel EMAIL/SMS select, devCode banner `Dev mode: code 123456`).
3. **Onboarding**: 3-step KYC wizard (① Identity: names/DOB/country/taxIdLast4 ② Address ③ Declarations: doc type/number + PEP + attestations checkbox) with progress indicator, zod per step, submit → "Under review…" animation → poll `/api/kyc/status` → APPROVED → confetti-less success → dashboard.
4. **Dashboard**: 
   - Top cards row: Total equity, Cash available, Buying power, Day P&L (mono numerals, green/red).
   - Grid: Market movers (sortable list w/ sparkline-ish change badges + add-to-watchlist star), Watchlist (add/remove, `max-h-96` scroll), Recent ledger activity (feed), Security center (MFA setup dialog with QR from `/api/auth/mfa/setup`, phone verify via OTP, active sessions info, "sign out all" optional).
   - Empty states + skeletons. KYC-pending banner if unapproved.

---

## 6. Phase 2 Contract — Market Data (WS) + Trading (REST)

### 6a. WebSocket gateway — `io("/?XTransformPort=3003")`, socket.io `path: "/"`

Client → Server events:

| event | payload | notes |
|---|---|---|
| `subscribe` | `{ symbols: string[] }` | joins `asset:{symbol}` rooms; unknown symbols ignored |
| `unsubscribe` | `{ symbols: string[] }` | |
| `watch-depth` | `{ symbol }` | joins `depth:{symbol}` room |
| `auth-user` | `{ token }` | short-lived WS ticket from `GET /api/ws-ticket` (JWT purpose `ws`, 120 s) → joins `user:{id}` room |
| `ping` | `{ t: number }` | echoed back as `pong` |

Server → Client events:

| event | payload |
|---|---|
| `hello` | `{ serverTime, symbols }` |
| `snapshot` | `{ quotes: TickQuote[] }` — sent once per `subscribe` |
| `tick` | `TickQuote` — ~500 ms cadence per symbol, only to rooms with subscribers |
| `depth` | `DepthSnapshot` — ~1 s cadence |
| `order-update` | `{ order: OrderDTO }` — fill/reject/cancel confirmations pushed to `user:{id}` |
| `portfolio-nudge` | `{ ts }` — client should refetch portfolio summary + orders |
| `pong` | `{ t, serverTime }` — client measures RTT |

Types (minor units = paise):
`TickQuote = { symbol, name, type, exchange, lastPriceCents, prevCloseCents, openCents, highCents, lowCents, changeCents, changePct, volume, ts }`
`DepthSnapshot = { symbol, bids: { priceCents, qty }[], asks: { priceCents, qty }[], ts }` (5 levels per side)

Internal service-to-service (the sandbox analog of the "order confirmations" async arrow):
`POST http://127.0.0.1:3003/internal/emit { secret, room, event, payload }` — secret = AUTH_SECRET from project `.env`; rooms are `user:{userId}`.

### 6b. Trading REST (session auth + KYC APPROVED required; Origin guard; rate limit 30/min)

| Endpoint | Method | Body / Query | Response |
|---|---|---|---|
| `/api/orders` | POST | `{ symbol, side: "BUY"\|"SELL", type: "MARKET"\|"LIMIT"\|"STOP"\|"STOP_LIMIT", qty, limitPriceCents?, stopPriceCents?, timeInForce?: "DAY"\|"GTC" }` | `201 { order: OrderDTO, fill?: { qty, priceCents, feeCents } }` — risk rejects: `422 { error, code }` |
| `/api/orders` | GET | `?scope=ALL\|OPEN` (default ALL) | `{ orders: OrderDTO[] }` (newest first, ≤50) |
| `/api/orders/{id}/cancel` | POST | — | `{ order: OrderDTO }` · `409 NOT_CANCELLABLE` when not open |
| `/api/candles` | GET | `?symbol=&tf=DAY` | `{ symbol, bars: { t, openCents, highCents, lowCents, closeCents, volume }[] }` — 90 daily bars |
| `/api/ws-ticket` | GET | — | `{ ticket }` — JWT purpose `ws`, 120 s TTL, for `auth-user` |

`OrderDTO = { id, symbol, side, type, qty, limitPriceCents?, stopPriceCents?, timeInForce, status, filledQty, avgFillPriceCents, rejectReason?, brokerRef?, createdAt, updatedAt }`

**Risk engine (ALWAYS in the order path — client-approved invariant).** Checks, in order: kill-switch (`TRADING_KILL_SWITCH=1` env) → market hours (sim: always open) → instrument tradeable (INDEX symbols not tradeable) → qty sanity → price band (limit/stop within ±20% of LTP) → BUY buying power (cash minus open-order reservations; market est. at LTP +25 bps slippage) → SELL quantity held (no shorting until M7–M9 margin engine) → feed availability. Reject codes: `KILL_SWITCH`, `MARKET_CLOSED`, `NOT_TRADEABLE`, `PRICE_BAND`, `INSUFFICIENT_FUNDS`, `INSUFFICIENT_QTY`, `FEED_UNAVAILABLE`.

**Execution model (simulated broker = the M2–M4 "broker API").** MARKET fills instantly at LTP ±25 bps slippage; LIMIT/STOP/STOP_LIMIT rest in the book and are matched every 2 s against the live feed (limit crossing fills at min/max(limit, LTP); STOP and STOP_LIMIT activate on trigger cross). Fee per fill: `min(₹20, 0.03% of notional)` (discount-broker model). Every fill runs in ONE Prisma transaction: Order update → Trade row → append-only LedgerEntry (TRADE) → Position (avg cost / realized PnL) → Wallet cache; then WS `order-update` + `portfolio-nudge` to the user room.

### 7. Phase 3 — GTT / AMO / Price Alerts / Screener (sandbox contract)

**Order extensions.** `Order.expiresAt` (GTT expiry) and `Order.activateAt` (AMO eligibility) join the schema; `OrderStatus` gains `QUEUED`; `OrderKind` gains `GTT`. `POST /api/orders` accepts `type: "GTT"`, optional `expiresAt` (ISO, must be now+5 min … now+365 days) and optional `amo: true` (MARKET/LIMIT only; never with GTT).

**GTT (Zerodha-style Good-Till-Triggered).** `stopPriceCents` = trigger, `limitPriceCents` = limit. Risk treats GTT like STOP_LIMIT for the ±20% trigger band and like LIMIT for the BUY funds reservation (open GTT BUYs count toward reserved notional). The matcher fires BUY when `LTP <= trigger` (fill `min(LTP, limit)`) and SELL when `LTP >= trigger` (fill `max(LTP, limit)`), evaluated every 2 s like resting orders. Orders unfilled when `expiresAt` passes are set `CANCELED` with `rejectReason: "EXPIRED"` + `order-update` WS push.

**AMO (After-Market Order).** `amo: true` creates the order as `QUEUED` with `activateAt = nextSessionOpen(now)` — the simulated exchange rolls hourly sessions, so this is the top of the next UTC hour (production analog: next trading day 09:00 IST pre-open release). The matcher releases QUEUED → NEW when `activateAt` passes; MARKET AMOs fill in the same cycle at live price, LIMIT AMOs flow through resting logic. `scope=OPEN` includes QUEUED; QUEUED orders stay cancellable until release.

**Price alerts — `/api/alerts`** (session auth; POST/DELETE also Origin-guarded, 30/min).

| Endpoint | Method | Body / Query | Response |
|---|---|---|---|
| `/api/alerts` | GET | — | `{ alerts: PriceAlertDTO[] }` (newest first, ≤50, asset name joined) |
| `/api/alerts` | POST | `{ symbol, condition: "ABOVE"\|"BELOW", targetCents: int > 0 }` | `201 { alert }` · `503 FEED_UNAVAILABLE` when no live quote · `422 ALERT_LIMIT` at 30 ACTIVE per user |
| `/api/alerts` | DELETE | `?id=` | `{ ok: true }` (ACTIVE → CANCELED; TRIGGERED → `422 INVALID_STATE`) |

The matcher evaluates ACTIVE alerts every cycle against the same feed snapshot as resting orders; ABOVE fires when `LTP >= targetCents`, BELOW when `LTP <= targetCents`, once. WS event `alert` to `user:{id}`: `{ alert: PriceAlertDTO }` (`{ id, symbol, name?, condition, targetCents, status, createdAt, triggeredAt? }`).

**Screener — `GET /api/market/screener`** (public): `{ quotes: MarketQuote[] }` for all 21 assets, live feed joined over seeded DB fallback (same pattern as overview).

---

## 8. Phase 4 Contract — Margin Engine · CO/BO · Notifications · Risk Console

### 8a. Margin engine (SEBI peak-margin analog)

`PlaceOrderPayload` gains `product?: "CNC" | "MIS"` (default `CNC`) and CO/BO strategy fields. Leverage table (post-2021 SEBI peak-margin rules):

| Product / family | Leverage | Margin | SELL semantics |
|---|---|---|---|
| `CNC` | 1x | full notional | needs holdings (`qty <= positionQty`) |
| `MIS` | 5x | `ceil(notional / 5)` (rupee-rounded) | shorting allowed — margin reserved |
| `CO` (Cover) | 5x | MIS margin | shorting allowed |
| `BO` (Bracket) | 5x | MIS margin | shorting allowed |

- `estPrice` = `limitPriceCents` (LIMIT entries) else LTP ±25 bps slippage buffer (MARKET).
- **Margin reservation**: `available = cashAvailable − Σ margin(open orders)` — open orders (NEW / PARTIALLY_FILLED / QUEUED, incl. short SELLs) reserve their margin; the estimator uses each order's limit price when present (MARKET legs are transient — swept within one matcher cycle).
- `GET /api/margin?symbol=&side=&type=&qty=&product=&strategy=&limitPriceCents=&stopPriceCents=&targetCents=` (session auth) → `MarginResponse { notionalCents, requiredCents, availableCents, leverage, feeEstimateCents }` — used by the ticket for a live margin line. Never places anything.
- **Short positions**: `Position.qty` may go negative (MIS/CO/BO). `executeFill` becomes direction-aware: closing fills realize PnL (`(avg − price) × qty` for covering BUYs, `(price − avg) × qty` for long SELLs); crossing zero resets avg to the new entry price; extending a short re-averages. Portfolio math stays `equity = cash + Σ qty × LTP` (signed) and `unrealized = (LTP − avg) × qty` — correct for both directions. `PositionDetail` renders negative qty as a SHORT side.

### 8b. CO (Cover Order) / BO (Bracket Order)

`POST /api/orders` payload for strategy orders: `strategy: "CO" | "BO"`, `type` = entry type (`MARKET` | `LIMIT` only), mandatory `stopPriceCents` (SL trigger), `targetCents` (BO only), `product` forced `MIS` server-side (explicit CNC with a strategy → `422 INVALID_PRODUCT`). AMO/GTT never combine with strategies. Entry rows are created with `legKind: "ENTRY"`, `strategy`, and (BO) `targetCents`.

Leg lifecycle (matcher + placement paths share `onEntryFilled`):

| Family | On entry FILLED | Legs | OCO |
|---|---|---|---|
| CO | create STOP leg — opposite side, same qty, `type: "STOP"`, trigger = `stopPriceCents`, `legKind: "STOP"`, `parentOrderId` = entry id, product MIS, **no cash reservation** | 1 | — |
| BO | create TARGET leg (`type: "LIMIT"`, limit = `targetCents`, `legKind: "TARGET"`) + STOP leg as above | 2 | first leg FILLED → sibling `CANCELED` (`rejectReason: "OCO_CLOSED"`) |

- Legs flow through existing matching (LIMIT/STOP resting, MARKET sweep) — no new fill logic. BUY legs re-check cash (buyback) via the existing matcher path.
- **Exit**: `POST /api/orders/{id}/exit` — parent ENTRY order, strategy CO/BO, `filledQty > 0`: cancels open legs (`MANUAL_EXIT`), creates a MARKET EXIT leg (`legKind: "EXIT"`, opposite side, qty = `entry.filledQty − closedQty`) for the next sweep, audits + notifies. `409 NOTHING_TO_EXIT` when already flat. `409 NOT_CANCELLABLE` on non-strategy orders.
- **Cancel**: entry orders cancel normally while NEW/QUEUED (no legs exist yet); after fill use `/exit` (`409` with hint).
- Leg validation at placement: SL trigger on the correct side of entry (BUY: SL < est. entry; SELL: SL > est. entry), within the ±20% band; BO target beyond entry (BUY: target > entry; SELL: target < entry), also within band → else `422 INVALID_LEG`.
- `OrderDTO` carries `product`, `strategy`, `legKind`, `parentOrderId`, `targetCents`. Orders list stays flat — the frontend groups legs under their parent.

### 8c. Notifications

`Notification { id, userId, type, title, body, refType?, refId?, readAt?, createdAt }` — pruned to newest 100 per user. `notifyUser()` writes the row AND emits WS `notification` → `user:{id}` with `{ notification: NotificationDTO }` (fire-and-forget, same pattern as `order-update`).

| Endpoint | Method | Body / Query | Response |
|---|---|---|---|
| `/api/notifications` | GET | `?limit=30` | `{ notifications: NotificationDTO[], unread }` |
| `/api/notifications/read` | POST | `{ ids?: string[], all?: boolean }` | `{ ok: true, unread }` |
| `/api/notifications` | DELETE | `?id=` or `?all=true` | `{ ok: true }` |

Wired at every lifecycle event: order placed / filled / rejected / cancelled, GTT expiry, AMO release, CO/BO legs created, OCO sibling closed, exit executed, alert triggered, kill-switch toggled.

### 8d. Risk console (ADMIN)

Runtime kill switch in `SystemFlag { key: "TRADING_KILL_SWITCH", value: "0"/"1" }` (env `TRADING_KILL_SWITCH=1` stays as a boot-time override). Read through a 5 s cache; the matcher also skips fills while ON (resting orders stay resting).

| Endpoint | Method | Body | Response |
|---|---|---|---|
| `/api/admin/risk` | GET | — (ADMIN) | `RiskStatusResponse { killSwitch, source: "flag" \| "env" \| "off" }` |
| `/api/admin/risk` | POST | `{ killSwitch: boolean }` (ADMIN, audited) | `{ killSwitch }` · `403 ROLE_REQUIRED` for non-admins |

Demo admin: `admin@meridian.dev` / `MeridianAdmin1` (seeded, KYC APPROVED, funded ₹10,00,000).
