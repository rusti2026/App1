/**
 * MERIDIAN — Phase 2 seed: NSE/BSE instrument universe + 90 days of OHLCV bars
 * + demo account (₹10,00,000 paper capital, PAN-based KYC, 2 open positions).
 * Run: bun prisma/seed.ts
 * Money is Int minor units (paise). Deterministic PRNG → identical history on reseed.
 */
import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/lib/security/hash";
import { encryptField } from "../src/lib/security/crypto-field";

const db = new PrismaClient();

/* Deterministic PRNG so reseeding produces identical history (mulberry32). */
function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashCode(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

type SeedAsset = {
  symbol: string;
  name: string;
  type: "STOCK" | "ETF" | "INDEX";
  exchange: "NSE" | "BSE";
  lastPriceRupees: number;
  volumeBase: number; // 0 for indices
  vol: number; // daily volatility factor
};

const rupees = (r: number) => Math.round(r * 100);

const ASSETS: SeedAsset[] = [
  { symbol: "RELIANCE",   name: "Reliance Industries Ltd.",    type: "STOCK", exchange: "NSE", lastPriceRupees: 2951.20,  volumeBase: 8_900_000,  vol: 0.014 },
  { symbol: "TCS",        name: "Tata Consultancy Services",   type: "STOCK", exchange: "NSE", lastPriceRupees: 4102.35,  volumeBase: 2_600_000,  vol: 0.012 },
  { symbol: "HDFCBANK",   name: "HDFC Bank Ltd.",              type: "STOCK", exchange: "NSE", lastPriceRupees: 1642.10,  volumeBase: 12_500_000, vol: 0.011 },
  { symbol: "INFY",       name: "Infosys Ltd.",                type: "STOCK", exchange: "NSE", lastPriceRupees: 1854.55,  volumeBase: 7_800_000,  vol: 0.014 },
  { symbol: "ICICIBANK",  name: "ICICI Bank Ltd.",             type: "STOCK", exchange: "NSE", lastPriceRupees: 1243.80,  volumeBase: 11_200_000, vol: 0.012 },
  { symbol: "SBIN",       name: "State Bank of India",         type: "STOCK", exchange: "NSE", lastPriceRupees: 821.45,   volumeBase: 15_600_000, vol: 0.016 },
  { symbol: "TATAMOTORS", name: "Tata Motors Ltd.",            type: "STOCK", exchange: "NSE", lastPriceRupees: 992.30,   volumeBase: 18_400_000, vol: 0.021 },
  { symbol: "BHARTIARTL", name: "Bharti Airtel Ltd.",          type: "STOCK", exchange: "NSE", lastPriceRupees: 1585.20,  volumeBase: 6_300_000,  vol: 0.012 },
  { symbol: "LT",         name: "Larsen & Toubro Ltd.",        type: "STOCK", exchange: "NSE", lastPriceRupees: 3546.75,  volumeBase: 2_100_000,  vol: 0.014 },
  { symbol: "ADANIENT",   name: "Adani Enterprises Ltd.",      type: "STOCK", exchange: "NSE", lastPriceRupees: 3152.90,  volumeBase: 3_400_000,  vol: 0.026 },
  { symbol: "WIPRO",      name: "Wipro Ltd.",                  type: "STOCK", exchange: "NSE", lastPriceRupees: 562.10,   volumeBase: 13_800_000, vol: 0.015 },
  { symbol: "IRFC",       name: "Indian Railway Finance Corp.", type: "STOCK", exchange: "NSE", lastPriceRupees: 152.80,  volumeBase: 32_500_000, vol: 0.022 },
  { symbol: "ZOMATO",     name: "Zomato Ltd.",                 type: "STOCK", exchange: "NSE", lastPriceRupees: 264.50,   volumeBase: 68_000_000, vol: 0.024 },
  { symbol: "HINDUNILVR", name: "Hindustan Unilever Ltd.",     type: "STOCK", exchange: "NSE", lastPriceRupees: 2385.60,  volumeBase: 1_700_000,  vol: 0.009 },
  { symbol: "MARUTI",     name: "Maruti Suzuki India Ltd.",    type: "STOCK", exchange: "NSE", lastPriceRupees: 11240.85, volumeBase: 920_000,    vol: 0.013 },
  { symbol: "TITAN",      name: "Titan Company Ltd.",          type: "STOCK", exchange: "NSE", lastPriceRupees: 3485.30,  volumeBase: 1_400_000,  vol: 0.013 },
  { symbol: "NIFTYBEES",  name: "Nippon India ETF Nifty 50 BeES", type: "ETF", exchange: "NSE", lastPriceRupees: 268.40,  volumeBase: 9_800_000,  vol: 0.006 },
  { symbol: "GOLDBEES",   name: "Nippon India ETF Gold BeES",  type: "ETF",   exchange: "NSE", lastPriceRupees: 67.15,    volumeBase: 15_200_000, vol: 0.007 },
  { symbol: "NIFTY50",    name: "NIFTY 50",                    type: "INDEX", exchange: "NSE", lastPriceRupees: 24850.55, volumeBase: 0,          vol: 0.005 },
  { symbol: "BANKNIFTY",  name: "NIFTY BANK",                  type: "INDEX", exchange: "NSE", lastPriceRupees: 53418.20, volumeBase: 0,          vol: 0.006 },
  { symbol: "SENSEX",     name: "BSE SENSEX",                  type: "INDEX", exchange: "BSE", lastPriceRupees: 81234.65, volumeBase: 0,          vol: 0.005 },
];

const DAYS = 90;

async function seedAsset(a: SeedAsset) {
  const rnd = mulberry32(hashCode(a.symbol));
  const lastPriceCents = rupees(a.lastPriceRupees);
  const closes: number[] = [];
  let px = lastPriceCents / (1 + (rnd() - 0.45) * a.vol * 8); // end at target
  for (let i = 0; i < DAYS; i++) {
    px = px * (1 + (rnd() - 0.5) * a.vol);
    closes.push(Math.max(1, Math.round(px)));
  }
  // Rescale so the final close is exactly lastPriceCents.
  const scale = lastPriceCents / closes[closes.length - 1];
  for (let i = 0; i < closes.length; i++) closes[i] = Math.max(1, Math.round(closes[i] * scale));

  const prevCloseCents = closes[closes.length - 2];
  const today = new Date();
  today.setUTCHours(0, 0, 0, 0);
  const volume = a.volumeBase > 0 ? Math.round(a.volumeBase * (0.7 + rnd() * 0.6)) : 0;

  const bars = closes.map((close, i) => {
    const open = i === 0 ? Math.round(close / (1 + (rnd() - 0.5) * a.vol)) : closes[i - 1];
    const hi = Math.max(open, close, Math.round(Math.max(open, close) * (1 + rnd() * a.vol * 0.6)));
    const lo = Math.min(open, close, Math.round(Math.min(open, close) * (1 - rnd() * a.vol * 0.6)));
    const t = new Date(today.getTime() - (DAYS - 1 - i) * 86_400_000);
    return {
      symbol: a.symbol,
      t,
      openCents: open,
      highCents: hi,
      lowCents: lo,
      closeCents: close,
      volume: a.volumeBase > 0 ? Math.round(a.volumeBase * (0.6 + rnd() * 0.8)) : 0,
    };
  });

  const data = {
    name: a.name,
    type: a.type,
    exchange: a.exchange,
    lastPriceCents,
    prevCloseCents,
    dayHighCents: bars[bars.length - 1].highCents,
    dayLowCents: bars[bars.length - 1].lowCents,
    volume,
  };

  await db.asset.upsert({ where: { symbol: a.symbol }, create: { symbol: a.symbol, ...data }, update: data });
  await db.priceBar.deleteMany({ where: { symbol: a.symbol } });
  await db.priceBar.createMany({ data: bars });
}

/**
 * Demo account reset to the India baseline:
 *  ₹10,00,000 paper funding → bought 50 RELIANCE @ ₹2,890.00 and 30 INFY @ ₹1,810.00
 *  → cash now ₹8,01,200. Ledger is a consistent append-only chain.
 */
async function seedDemoUser() {
  const passwordHash = hashPassword("MeridianDemo1");
  const user = await db.user.upsert({
    where: { email: "demo@meridian.dev" },
    create: {
      email: "demo@meridian.dev",
      name: "Demo Trader",
      passwordHash,
      emailVerified: true,
      phone: "+91-98200-12345",
      phoneVerified: true,
    },
    update: { phone: "+91-98200-12345", phoneVerified: true },
  });

  await db.kycProfile.upsert({
    where: { userId: user.id },
    create: {
      userId: user.id,
      legalFirstName: "Demo",
      legalLastName: "Trader",
      dateOfBirth: "1990-06-15",
      country: "India",
      address1: "1st Floor, Express Towers, Nariman Point",
      city: "Mumbai",
      region: "MH",
      postalCode: "400021",
      taxIdLast4Enc: encryptField("4821"),
      docType: "PAN",
      docNumberEnc: encryptField("AKZPD4821K"),
      pep: false,
      status: "APPROVED",
      riskRating: "LOW",
      submittedAt: new Date(),
      reviewedAt: new Date(),
      reviewNote: "Simulated compliance auto-review (sandbox)",
    },
    update: {
      country: "India",
      city: "Mumbai",
      region: "MH",
      postalCode: "400021",
      docType: "PAN",
      taxIdLast4Enc: encryptField("4821"),
      docNumberEnc: encryptField("AKZPD4821K"),
      status: "APPROVED",
    },
  });

  const FUNDING = 100_000_000;   // ₹10,00,000.00 in paise
  const RIL_COST = 50 * 289_000; // 50 × ₹2,890.00 = ₹1,44,500.00
  const INFY_COST = 30 * 181_000; // 30 × ₹1,810.00 = ₹54,300.00
  const FINAL_CASH = FUNDING - RIL_COST - INFY_COST; // ₹8,01,200.00

  let wallet = await db.wallet.findUnique({ where: { userId: user.id } });
  if (!wallet) wallet = await db.wallet.create({ data: { userId: user.id } });

  // Reset demo financial state (dev database — safe).
  await db.ledgerEntry.deleteMany({ where: { walletId: wallet.id } });
  await db.transaction.deleteMany({ where: { walletId: wallet.id } });
  await db.position.deleteMany({ where: { userId: user.id } });
  await db.order.deleteMany({ where: { userId: user.id } });

  await db.ledgerEntry.createMany({
    data: [
      {
        walletId: wallet.id,
        direction: "CREDIT",
        category: "ADJUSTMENT",
        amountCents: FUNDING,
        balanceAfterCents: FUNDING,
        refType: "SYSTEM",
        memo: "Paper trading funding (simulated)",
      },
      {
        walletId: wallet.id,
        direction: "DEBIT",
        category: "TRADE",
        amountCents: RIL_COST,
        balanceAfterCents: FUNDING - RIL_COST,
        refType: "SYSTEM",
        memo: "BUY 50 RELIANCE @ ₹2,890.00",
      },
      {
        walletId: wallet.id,
        direction: "DEBIT",
        category: "TRADE",
        amountCents: INFY_COST,
        balanceAfterCents: FINAL_CASH,
        refType: "SYSTEM",
        memo: "BUY 30 INFY @ ₹1,810.00",
      },
    ],
  });

  await db.wallet.update({
    where: { id: wallet.id },
    data: { currency: "INR", cashAvailableCents: FINAL_CASH, cashPendingCents: 0 },
  });

  await db.position.createMany({
    data: [
      { userId: user.id, symbol: "RELIANCE", qty: 50, avgCostCents: 289_000, realizedPnlCents: 0 },
      { userId: user.id, symbol: "INFY", qty: 30, avgCostCents: 181_000, realizedPnlCents: 0 },
    ],
  });

  for (const symbol of ["RELIANCE", "INFY", "NIFTY50", "ZOMATO"]) {
    await db.watchlistItem.upsert({
      where: { userId_symbol: { userId: user.id, symbol } },
      create: { userId: user.id, symbol },
      update: {},
    });
  }
}

/**
 * Admin account for the Phase 4 risk console (kill switch, risk API).
 * KYC APPROVED + funded so the admin can also trade if needed.
 */
async function seedAdminUser() {
  const passwordHash = hashPassword("MeridianAdmin1");
  const user = await db.user.upsert({
    where: { email: "admin@meridian.dev" },
    create: {
      email: "admin@meridian.dev",
      name: "Risk Desk Admin",
      passwordHash,
      emailVerified: true,
      role: "ADMIN",
      phone: "+91-98200-99999",
      phoneVerified: true,
    },
    update: { role: "ADMIN", phoneVerified: true },
  });

  await db.kycProfile.upsert({
    where: { userId: user.id },
    create: {
      userId: user.id,
      legalFirstName: "Risk Desk",
      legalLastName: "Admin",
      dateOfBirth: "1985-01-10",
      country: "India",
      address1: "Trade Center, Bandra Kurla Complex",
      city: "Mumbai",
      region: "MH",
      postalCode: "400051",
      taxIdLast4Enc: encryptField("7788"),
      docType: "PAN",
      docNumberEnc: encryptField("BQAPR7788L"),
      pep: false,
      status: "APPROVED",
      riskRating: "LOW",
      submittedAt: new Date(),
      reviewedAt: new Date(),
      reviewNote: "Simulated compliance auto-review (sandbox)",
    },
    update: {
      docType: "PAN",
      taxIdLast4Enc: encryptField("7788"),
      docNumberEnc: encryptField("BQAPR7788L"),
      status: "APPROVED",
    },
  });

  let wallet = await db.wallet.findUnique({ where: { userId: user.id } });
  if (!wallet) {
    wallet = await db.wallet.create({ data: { userId: user.id } });
    await db.ledgerEntry.create({
      data: {
        walletId: wallet.id,
        direction: "CREDIT",
        category: "ADJUSTMENT",
        amountCents: 100_000_000, // ₹10,00,000.00
        balanceAfterCents: 100_000_000,
        refType: "SYSTEM",
        memo: "Paper trading funding (simulated)",
      },
    });
    await db.wallet.update({
      where: { id: wallet.id },
      data: { currency: "INR", cashAvailableCents: 100_000_000, cashPendingCents: 0 },
    });
  }
}

async function main() {
  // Wipe the old US-flavored universe; FKs cascade to bars/watchlist/positions/orders/trades.
  await db.asset.deleteMany({});
  for (const a of ASSETS) await seedAsset(a);
  await seedDemoUser();
  await seedAdminUser();
  const counts = {
    assets: await db.asset.count(),
    bars: await db.priceBar.count(),
    users: await db.user.count(),
    demoPositions: await db.position.count(),
  };
  console.log("Seed complete:", counts);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
