/**
 * MERIDIAN — Market Data Service (sandbox)
 * Simulated exchange feed → event bus (Kafka analog) → hot cache (Redis analog)
 * → WebSocket gateway (socket.io, path "/", port 3003 via Caddy ?XTransformPort=3003).
 *
 * REST:  GET /health · GET /quotes[?symbols=A,B]
 * WS:    subscribe/unsubscribe/watch-depth/auth-user/ping  (see ARCHITECTURE.md §6a)
 * S2S:   POST /internal/emit { secret, room, event, payload }  (order confirmations arrow)
 */
import { createServer } from "http";
import { Server } from "socket.io";
import { EventEmitter } from "events";
import { readFileSync } from "fs";
import { createHmac, timingSafeEqual } from "crypto";
import { join } from "path";

const PORT = 3003;
const TICK_MS = 500;
const DEPTH_MS = 1000;
const PRICE_TICK = 5; // ₹0.05 in paise

/* ── env (project root .env first, service-local overrides) ── */
function loadEnvFile(p: string): Record<string, string> {
  try {
    const out: Record<string, string> = {};
    for (const line of readFileSync(p, "utf8").split("\n")) {
      const m = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$/);
      if (m) out[m[1]!] = m[2]!;
    }
    return out;
  } catch {
    return {};
  }
}
const env = { ...loadEnvFile(join(import.meta.dir, "..", "..", ".env")), ...loadEnvFile(join(import.meta.dir, ".env")) };
const AUTH_SECRET = env.AUTH_SECRET ?? "";
const INTERNAL_SECRET = env.INTERNAL_EMIT_SECRET ?? AUTH_SECRET;
if (AUTH_SECRET.length < 32) {
  console.error("AUTH_SECRET missing or too short — add it to the project .env");
  process.exit(1);
}

/* ── instrument universe (mirrors prisma/seed.ts) ── */
type Instrument = {
  symbol: string;
  name: string;
  type: "STOCK" | "ETF" | "INDEX";
  exchange: string;
  prevCloseRupees: number;
  vol: number; // per-tick volatility fraction
  volumeBase: number;
  prevClosePaise: number;
};
const raw = JSON.parse(readFileSync(join(import.meta.dir, "instruments.json"), "utf8")) as {
  instruments: Array<Omit<Instrument, "prevClosePaise">>;
};
const INSTRUMENTS: Instrument[] = raw.instruments.map((i) => ({
  ...i,
  prevClosePaise: Math.round(i.prevCloseRupees * 100),
}));
const BY_SYMBOL = new Map(INSTRUMENTS.map((i) => [i.symbol, i]));

/* ── hot cache (Redis analog): latest quote per symbol ── */
type Quote = { symbol: string; last: number; open: number; high: number; low: number; volume: number; ts: number };
const book = new Map<string, Quote>();
for (const inst of INSTRUMENTS) {
  const pc = inst.prevClosePaise;
  book.set(inst.symbol, { symbol: inst.symbol, last: pc, open: pc, high: pc, low: pc, volume: 0, ts: Date.now() });
}

function hashCode(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

function tickDto(q: Quote) {
  const inst = BY_SYMBOL.get(q.symbol)!;
  const change = q.last - inst.prevClosePaise;
  return {
    symbol: q.symbol,
    name: inst.name,
    type: inst.type,
    exchange: inst.exchange,
    lastPriceCents: q.last,
    prevCloseCents: inst.prevClosePaise,
    openCents: q.open,
    highCents: q.high,
    lowCents: q.low,
    changeCents: change,
    changePct: Number(((change / inst.prevClosePaise) * 100).toFixed(2)),
    volume: q.volume,
    ts: q.ts,
  };
}

/* ── L2 depth (synthetic, stable within a 2s bucket) ── */
function depthFor(symbol: string) {
  const q = book.get(symbol);
  if (!q) return null;
  const spread = Math.max(PRICE_TICK, Math.round((q.last * 0.0002) / PRICE_TICK) * PRICE_TICK);
  const bucket = Math.floor(Date.now() / 2000);
  const qtyFor = (lvl: number, salt: number) => 50 + (hashCode(`${symbol}:${bucket}:${lvl}:${salt}`) % 47) * 25;
  const bids: Array<{ priceCents: number; qty: number }> = [];
  const asks: Array<{ priceCents: number; qty: number }> = [];
  for (let i = 0; i < 5; i++) {
    bids.push({ priceCents: q.last - (i + 1) * spread, qty: qtyFor(i, 1) });
    asks.push({ priceCents: q.last + (i + 1) * spread, qty: qtyFor(i, 2) });
  }
  return { symbol, bids, asks, ts: Date.now() };
}

/* ── event bus (Kafka analog): topics with the same event shapes ── */
const bus = new EventEmitter();

/* ── HTTP: REST + socket.io share port 3003 ── */
function json(res: import("http").ServerResponse, status: number, body: unknown) {
  res.writeHead(status, { "content-type": "application/json", "access-control-allow-origin": "*" });
  res.end(JSON.stringify(body));
}

const router = (req: import("http").IncomingMessage, res: import("http").ServerResponse) => {
  const url = new URL(req.url ?? "/", "http://localhost");
  // socket.io owns EIO transport requests — never touch them.
  if (url.searchParams.has("EIO") || url.pathname.includes("socket.io")) return;

  if (req.method === "GET" && url.pathname === "/health") {
    return json(res, 200, { ok: true, service: "market-data", symbols: INSTRUMENTS.length, uptimeSec: Math.round(process.uptime()), ts: Date.now() });
  }

  if (req.method === "GET" && url.pathname === "/quotes") {
    const filter = url.searchParams.get("symbols");
    const syms = filter
      ? filter.split(",").map((s) => s.trim()).filter((s) => BY_SYMBOL.has(s))
      : Array.from(book.keys());
    return json(res, 200, { quotes: syms.map((s) => tickDto(book.get(s)!)), ts: Date.now() });
  }

  if (req.method === "POST" && url.pathname === "/internal/emit") {
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      try {
        const { secret, room, event, payload } = JSON.parse(body) as {
          secret?: string; room?: string; event?: string; payload?: unknown;
        };
        const a = Buffer.from(secret ?? "");
        const b = Buffer.from(INTERNAL_SECRET);
        if (a.length !== b.length || !timingSafeEqual(a, b)) {
          return json(res, 401, { ok: false, error: "bad secret" });
        }
        if (!room || !event) return json(res, 400, { ok: false, error: "room and event required" });
        io.to(room).emit(event, payload);
        return json(res, 200, { ok: true, sockets: io.sockets.adapter.rooms.get(room)?.size ?? 0 });
      } catch {
        return json(res, 400, { ok: false, error: "bad json" });
      }
    });
    return;
  }

  return json(res, 404, { ok: false, error: "not found" });
};

const httpServer = createServer(router);

const io = new Server(httpServer, {
  // DO NOT change the path — Caddy forwards ?XTransformPort=3003 to this port.
  path: "/",
  cors: { origin: "*", methods: ["GET", "POST"] },
  pingTimeout: 60000,
  pingInterval: 25000,
});

/* socket.io v4 hijacks every "request" listener at attach time and — with path "/" —
 * engine.io's check() (path === req.url.slice(0, path.length)) matches ALL URLs, so
 * /health, /quotes and /internal/emit would be answered {"code":0,"message":"Transport
 * unknown"} before reaching `router`. Rewire to cooperative dispatch: REST router first;
 * engine.io explicitly handles EIO polling requests + websocket upgrades. The WS
 * contract path "/" (§6a) is unchanged. */
httpServer.removeAllListeners("request");
httpServer.removeAllListeners("upgrade");
httpServer.on("request", router);
httpServer.on("request", (req, res) => {
  const u = new URL(req.url ?? "/", "http://localhost");
  if (u.searchParams.has("EIO") || u.pathname.includes("socket.io")) io.engine.handleRequest(req, res);
});
httpServer.on("upgrade", (req, socket, head) => io.engine.handleUpgrade(req, socket, head));

/* ── WS ticket verification (JWT purpose "ws", HMAC-SHA256, no deps) ── */
function verifyWsToken(token: string): { sub: string } | null {
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [h, p, s] = parts;
  const expected = createHmac("sha256", AUTH_SECRET).update(`${h}.${p}`).digest("base64url");
  const a = Buffer.from(s);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(p, "base64url").toString("utf8")) as {
      sub?: string; purpose?: string; exp?: number;
    };
    if (payload.purpose !== "ws") return null;
    if (typeof payload.exp === "number" && payload.exp * 1000 < Date.now()) return null;
    if (!payload.sub) return null;
    return { sub: String(payload.sub) };
  } catch {
    return null;
  }
}

/* ── connection lifecycle ── */
io.on("connection", (socket) => {
  socket.emit("hello", { serverTime: Date.now(), symbols: INSTRUMENTS.map((i) => i.symbol) });

  socket.on("subscribe", (data: { symbols?: string[] }) => {
    const syms = (data?.symbols ?? []).filter((s) => BY_SYMBOL.has(s));
    for (const s of syms) socket.join(`asset:${s}`);
    socket.emit("snapshot", { quotes: syms.map((s) => tickDto(book.get(s)!)), ts: Date.now() });
  });

  socket.on("unsubscribe", (data: { symbols?: string[] }) => {
    for (const s of data?.symbols ?? []) socket.leave(`asset:${s}`);
  });

  socket.on("watch-depth", (data: { symbol?: string }) => {
    const s = data?.symbol;
    if (!s || !BY_SYMBOL.has(s)) return;
    socket.join(`depth:${s}`);
    const d = depthFor(s);
    if (d) socket.emit("depth", d);
  });

  socket.on("unwatch-depth", (data: { symbol?: string }) => {
    if (data?.symbol) socket.leave(`depth:${data.symbol}`);
  });

  socket.on("auth-user", (data: { token?: string }) => {
    const payload = verifyWsToken(data?.token ?? "");
    if (!payload) {
      socket.emit("auth-error", { message: "invalid ticket" });
      return;
    }
    socket.join(`user:${payload.sub}`);
    socket.emit("auth-ok", { userId: payload.sub });
  });

  socket.on("ping", (data: { t?: number }) => {
    socket.emit("pong", { t: data?.t ?? 0, serverTime: Date.now() });
  });

  socket.on("error", (e: Error) => console.error(`socket error ${socket.id}:`, e.message));
});

/* ── fan-out: bus topic → rooms (only rooms with subscribers) ── */
bus.on("ticks", ({ symbol }: { symbol: string }) => {
  const room = `asset:${symbol}`;
  if (io.sockets.adapter.rooms.has(room)) {
    io.to(room).emit("tick", tickDto(book.get(symbol)!));
  }
});

/* ── simulated exchange feed: random walk + gentle mean reversion, tick-size snapped ── */
setInterval(() => {
  const ts = Date.now();
  for (const inst of INSTRUMENTS) {
    const q = book.get(inst.symbol)!;
    const reversion = (inst.prevClosePaise - q.last) * 0.0005;
    const shock = (Math.random() - 0.5) * 2 * inst.vol;
    let next = q.last * (1 + shock) + reversion;
    next = Math.round(next / PRICE_TICK) * PRICE_TICK;
    if (next < 100) next = 100;
    q.last = next;
    q.ts = ts;
    if (next > q.high) q.high = next;
    if (next < q.low) q.low = next;
    if (inst.volumeBase > 0) q.volume += Math.round(Math.random() * inst.volumeBase * 0.00004);
    bus.emit("ticks", { symbol: q.symbol, quote: q });
  }
}, TICK_MS);

setInterval(() => {
  for (const inst of INSTRUMENTS) {
    const room = `depth:${inst.symbol}`;
    if (io.sockets.adapter.rooms.has(room)) {
      const d = depthFor(inst.symbol);
      if (d) io.to(room).emit("depth", d);
    }
  }
}, DEPTH_MS);

httpServer.listen(PORT, () => {
  console.log(`market-data-service on :${PORT} · ${INSTRUMENTS.length} symbols · tick ${TICK_MS}ms`);
});

process.on("SIGTERM", () => {
  httpServer.close(() => process.exit(0));
});
process.on("SIGINT", () => {
  httpServer.close(() => process.exit(0));
});
