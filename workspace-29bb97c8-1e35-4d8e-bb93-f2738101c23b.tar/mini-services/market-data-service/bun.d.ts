/*
 * Ambient Bun runtime types for the mini-services (tsc runs with the root
 * Next.js tsconfig, which includes every TS file; "import.meta.dir" is
 * Bun-specific and not part of the DOM lib types).
 */
interface ImportMeta {
  dir: string;
}
