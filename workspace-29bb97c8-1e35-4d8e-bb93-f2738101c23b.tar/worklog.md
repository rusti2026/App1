# Worklog — MERIDIAN Trading Platform

Project: production-track trading app (Next.js 16, TS, Prisma/SQLite, shadcn/ui, Tailwind 4).
Master spec: /home/z/my-project/ARCHITECTURE.md (architecture, schema, roadmap, API contract, design system).

---
Task ID: 1
Agent: Z.ai Code (lead)
Task: Architecture doc, schema design, roadmap, API contract, agent coordination setup.

Work Log:
- Inspected scaffold (Next 16, Tailwind 4, shadcn/ui full set, Prisma+SQLite at db/custom.db), .env, uploaded ui-ux-pro-max-skill zip (design datasets; folded dark-fintech guidance into design spec).
- Wrote ARCHITECTURE.md: text architecture diagram (production + sandbox mapping), DB schema (14 tables, money-as-cents, append-only ledger), 5-phase roadmap, Phase 1 API contract, design system spec.
- Initialized this worklog.

Stage Summary:
- ARCHITECTURE.md is the single source of truth for all agents. Task 2 (frontend SPA) and Task 3 (backend APIs) build against it in parallel.
---
Task ID: 2
Agent: full-stack-developer
Task: Complete frontend of MERIDIAN — single-route SPA (landing | auth | onboarding | dashboard) per ARCHITECTURE.md §4 API contract and §5 design system.

Work Log:
- Surveyed scaffold (shadcn/ui New York set, fonts, Tailwind 4 tokens), worklog, ARCHITECTURE.md; confirmed all Phase 1 endpoints before coding.
- Extended globals.css: `--color-profit/loss/terminal` in `@theme inline` (light oklch 0.60/13/155 · 0.58/19/25 · 0.75/15/75; dark 0.75/17/160 · 0.65/21/25 · 0.80/14/80), dark bg/card re-tinted to near-black green cast (0.145/0.005/160, 0.185/0.006/160), amber ring in dark, `.thin-scroll` scrollbar, `@keyframes marquee`, `.ticker-mask` edge fade.
- Built typed API layer: `lib/api-client.ts` (`apiFetch<T>`, same-origin credentials, `x-requested-with: meridian-web`, typed `ApiError{status,code,message}` from `{error,code?}` bodies, global 401 → `meridian:session-expired` window event) and `lib/types.ts` covering every §4 response shape (no server imports).
- Zustand store (`store/app-store.ts`): view, authMode, authStep (credentials|mfa|otp), tempToken, actions incl. `openAuth`/`resetToLanding`.
- TanStack Query hooks: use-session (+logout), use-auth (register/login/loginMfa/otp request+verify/mfa setup+enable+disable), use-market (overview + watchlist GET/POST/DELETE with optimistic add/remove + rollback), use-portfolio (summary), use-kyc (submit + 2s status poll).
- Shell: providers.tsx (QueryClientProvider + next-themes dark default + sonner richColors bottom-right + session-expired listener → toast + store reset + cache clear), sticky translucent header (logo ▲ square, theme toggle, Log in/Get started, avatar dropdown w/ role badge + sign out, mobile Sheet menu), sticky footer (© 2025 disclaimer, Privacy/Terms/Disclosures, mt-auto + safe-area inset), branded splash screen.
- Views: Landing (hero + live top-movers terminal card, full-width CSS marquee ticker from /api/market/overview w/ hover-pause + reduced-motion static, stats band, 3 feature cards, how-it-works, CTA banner). Auth (Login/Signup tabs, zod-validated fields w/ inline errors, live 4-bar password strength meter, MFA InputOTP step w/ shake-on-fail, reusable OtpFlow: EMAIL/SMS channel select, amber devCode banner w/ copy + expiry countdown). Onboarding (3-step KYC wizard: identity/address/declarations, per-step zod, Progress indicator, submit → UNDER REVIEW pulse screen → 2s poll → APPROVED success → auto-advance 1.2s, REJECTED resubmit banner, skips wizard when onboardingDone). Dashboard (greeting + disabled "New trade" w/ tooltip "Phase 3 — trading engine", 4 KPI cards, market movers w/ optimistic star toggle, watchlist w/ live quote join + datalist + empty state, ledger feed w/ direction glyphs + relative dates, security center: TOTP QR/MFA dialogs, phone verify via OtpFlow dialog, KYC badge, session row; KYC-pending banner).
- page.tsx: session-query-driven state machine (deriveView: unauth → landing/auth by store; authed → dashboard iff onboardingDone && kycStatus==="APPROVED", else onboarding), AnimatePresence view fades honoring useReducedMotion, skip-link, semantic HTML + aria labels throughout.
- QA: `bun run lint` clean (fixed react-hooks/set-state-in-effect findings via derived onboarding phase, static-aria theme toggle, useSyncExternalStore session row); `bunx tsc --noEmit` — zero errors in src (only pre-existing examples/skills errors); grep for `blue|indigo` in owned paths → 0 matches; all 15 fetch paths verified 1:1 against §4; dev server GET / 200.

Stage Summary:
- Frontend is feature-complete against Phase 1 contract: register→login→(MFA)→OTP→KYC→dashboard all wired; global 401 handling; dark-first premium terminal aesthetic, no blue/indigo, mono tabular numerals everywhere.
- Backend-dependent behaviors degrade gracefully (skeletons/empty states/"awaiting feed") so UI is reviewable before Task 3 lands; API paths/bodies must not drift from lib/types.ts.
- Ambiguity resolutions: buying power = cashAvailableCents (+ "settling" subtext uses cashPendingCents); login bad-credentials 401 is surfaced inline, not as global session-expiry (auth endpoints exempt from the 401 auto-handler); watchlist item typed {symbol, addedAt?}; ledger memo/createdAt rendered when present; session "device/started" is client-derived until Phase 5 device APIs exist.
---
---
Task ID: 3
Agent: Z.ai Code (lead)
Task: Backend security core, all Phase 1 APIs, seed data, security headers.

Work Log:
- Built zero-dependency security core in src/lib/security/: scrypt password hashing (hash.ts), HS256 JWT w/ purpose-scoped tokens (jwt.ts), RFC 6238 TOTP + base32 + otpauth URI (totp.ts), AES-256-GCM field encryption (crypto-field.ts), sliding-window rate limiter (rate-limit.ts), append-only audit trail (audit.ts), server-revocable sessions (session.ts — JWT jti ↔ Session.id).
- 16 route handlers under src/app/api/: health, auth (session/register/login/login-mfa/logout/otp-request/otp-verify/mfa-setup/mfa-enable/mfa-disable), kyc (submit/status with simulated 5s auto-review), portfolio/summary (ledger-backed), market/overview (public), watchlist (GET/POST/DELETE).
- CSRF: Origin check + x-requested-with marker (passesOriginGuard). Rate limits: register 5/15m, login 20/15m per IP + 8/15m per account, MFA attempts, OTP sends. Zod validation everywhere. Generic auth errors (no user enumeration).
- next.config.ts: OWASP baseline headers (CSP, XFO DENY, nosniff, HSTS, COOP, Permissions-Policy).
- prisma/seed.ts: 16 assets (stocks/ETFs/crypto), 90 daily OHLCV bars each (deterministic PRNG), demo user demo@meridian.dev / MeridianDemo1 (KYC APPROVED, $100k paper wallet, watchlist).

Stage Summary:
- API contract in ARCHITECTURE.md §4 implemented 1:1 and verified via curl + TOTP round-trip test (enable → logout → mfa_required → challenge → session).
- Keys added to .env: AUTH_SECRET, FIELD_ENCRYPTION_KEY.

---
Task ID: 4
Agent: Z.ai Code (lead)
Task: Integration, bug fixes found in browser E2E, final verification.

Work Log:
- Agent Browser E2E golden path: register → KYC 3-step wizard → UNDER REVIEW → auto-APPROVED → dashboard. Verified watchlist star add/remove, ledger feed ($100,000 paper funding entry), security center (MFA dialog w/ QR + live TOTP enrollment, KYC Approved badge, session info), logout→landing, MFA login challenge UI, demo account login, mobile 390px layout, light mode toggle.
- FIX 1 (backend): createSession stored Session row with auto-cuid but JWT jti was a separate UUID → every session lookup failed (SESSION_GONE). Now Session.id = jti.
- FIX 2 (backend): register returned empty {} body; now returns contract shape { user { id, email, name, role } } with cookie headers.
- FIX 3 (frontend, onboarding-view): validateStep returned null on SUCCESS for steps 1/2, so handleContinue never advanced the wizard. Refactored to boolean validateStep + buildPayload().
- FIX 4 (frontend, use-session): queryClient.clear() after logout didn't refetch active session observer → UI stuck on dashboard. Now setQueryData(authenticated:false) + removeQueries(predicate ≠ session).
- Dev server restarted to pick up new .env keys (was started before env existed).
- Ops note: DOB uses native input[type=date] — Playwright fill needs keyboard segment events; fine for real users.

Stage Summary:
- All E2E flows browser-verified; lint clean; health {ok,db:true}; no runtime errors in dev.log.
- Demo credentials: demo@meridian.dev / MeridianDemo1 (MFA off). rex.calloway@example.com / HarborLight2026 has MFA (TOTP) enabled.

---
Task ID: 5
Agent: Z.ai Code (lead, via subagent)
Task: ARCHITECTURE.md — confirmed India architecture sections, M1–M18 roadmap, Phase 2 REST/WS contract; createSession body fix.

Work Log:
- (1a) Pre-check that §1c/§1d exist: `rg -n "1c. Confirmed|1d. Sandbox" ARCHITECTURE.md` → 85:### 1c. Confirmed Production Architecture — India (client-approved); 112:### 1d. Sandbox mapping of the confirmed architecture (this repo). Proceeded.
- (1b) §2 intro edited: "Money = **Int cents**" → "Money = **Int minor units** (paise for INR wallets)". Verified: `rg -n "Int minor units"` → line 131.
- (1c) Replaced entire §3 "Phase-by-Phase Roadmap" table with "## 3. Delivery Roadmap (client-approved M1–M18)" — 6-row production-milestone ↔ sandbox-phase mapping (M1–M2 ✅ shipped, M2–M4 🚧 Phase 2 this delivery, M4–M6 ⏳ next, M7–M9 + M9–M12 ⏳, M13–M18 out of sandbox scope). Verified: `rg -n "## 3. Delivery Roadmap|## 6. Phase 2 Contract|6a. WebSocket gateway|6b. Trading REST"` → 154 / 230 / 232 / 263; `rg -c "Phase-by-Phase"` → no matches, exit code 1 (old section fully gone).
- (1d) Appended §6 at EOF: "## 6. Phase 2 Contract — Market Data (WS) + Trading (REST)" — §6a WS gateway (socket.io :3003 via `?XTransformPort=3003`; client→server subscribe/unsubscribe/watch-depth/auth-user/ping; server→client hello/snapshot/tick/depth/order-update/portfolio-nudge/pong; TickQuote + DepthSnapshot types in paise; `POST http://127.0.0.1:3003/internal/emit` with AUTH_SECRET shared secret) and §6b Trading REST (orders POST/GET, /api/orders/{id}/cancel, /api/candles, /api/ws-ticket; OrderDTO; risk-engine check order + reject codes KILL_SWITCH…FEED_UNAVAILABLE; execution + fee model).
- (Job 2) src/lib/security/session.ts:24 — createSession response body `NextResponse.json({}, …)` → `NextResponse.json({ status: "ok" }, { status: 200 })` to match the documented login/login-mfa contract. Verified: `rg -n 'status: "ok"' src/lib/security/session.ts` → line 24.
- Lint: `bun run lint` → exit code 0, no findings (output tail: `$ eslint .`).

Stage Summary:
- ARCHITECTURE.md is again the single source of truth for the Phase 2 build: confirmed India production architecture mapping (§1c/§1d), client-approved M1–M18 delivery roadmap (§3), and the full Phase 2 REST + WS contract with risk-engine invariants (§6). Money documented as Int minor units (paise).
- createSession now returns the documented `{ status: "ok" }` body on successful login/MFA; lint clean.
---
Task ID: 6
Agent: Z.ai Code (lead, via subagent)
Task: Prisma schema Phase 2 additions + India (NSE/BSE) reseed.

Work Log:
- (A) 4 schema edits applied to prisma/schema.prisma: Wallet.currency default "USD"→"INR" (line 121, comment "minor units = paise"); Order gained rejectReason String? + brokerRef String? (lines 237–238); Asset.type comment → "STOCK | ETF | CRYPTO | INDEX (INDEX = benchmark, not tradeable)"; Asset.symbol comment → "RELIANCE, NIFTY50, NIFTYBEES".
- (A-verify) `bun run db:push` → "Your database is now in sync with your Prisma schema. Done in 13ms" + Prisma Client v6.19.2 regenerated.
- (B) prisma/seed.ts fully replaced with Phase 2 content: 21 NSE/BSE instruments (16 stocks, 2 ETFs, 3 indices NIFTY50/BANKNIFTY/SENSEX), mulberry32 PRNG keyed by symbol hash, 90 daily OHLCV bars each rescaled to exact lastPriceCents, demo user reset (₹10,00,000 funding, BUY 50 RELIANCE @ ₹2,890.00 + BUY 30 INFY @ ₹1,810.00 → cash ₹8,01,200.00 = 80,120,000 paise, consistent 3-entry ledger chain), PAN KYC (doc AKZPD4821K encrypted via crypto-field), INR wallet, 4 watchlist symbols. Old US universe wiped via asset.deleteMany (FK cascade).
- (C) `bun prisma/seed.ts` → "Seed complete: { assets: 21, bars: 1890, users: 6, demoPositions: 2 }" (21×90 = 1890 bars ✓).
- (C-verify) Prisma check query → {"assets":21,"bars":1890,"wallet":{"currency":"INR","cash":80120000},"pos":[INFY 30 @ 181000, RELIANCE 50 @ 289000],"ledgerBalances":[100000000,85550000,80120000]} — ledger chain 1,00,00,000 → 85,55,000 → 80,12,000 paise is arithmetic-consistent.
- (C-grep) `rg -n "rejectReason|brokerRef|@default(\"INR\")" prisma/schema.prisma` → lines 237/238 (rejectReason, brokerRef); the @default("INR") alternative didn't match because parens are regex metacharacters — re-verified with escaped pattern → line 121 `currency String @default("INR") // minor units = paise`. All 4 edits present.

Stage Summary:
- Schema is Phase 2-ready: INR wallets, Order.rejectReason/brokerRef for the risk engine + simulated broker, INDEX asset type documented as non-tradeable.
- DB reseeded to India universe: 21 NSE/BSE assets, 1890 bars, demo@meridian.dev (MeridianDemo1) = ₹8,01,200 cash + RELIANCE 50 / INFY 30 positions + PAN KYC APPROVED. Deterministic seed → identical history on every reseed.

---
Task ID: 7
Agent: Z.ai Code (lead, via subagent)
Task: INR formatters (en-IN, paise) + Phase 2 shared contract types.

Work Log:
- Rewrote src/components/meridian/format.ts (content exact per task spec): USD formatters removed; en-IN locale with fixed 2 fraction digits; new formatInr / formatSignedInr (U+2212 minus for mono alignment), formatPts / formatSignedPts (symbol-free index points), formatSignedPct, trendGlyph, formatVolume, relativeTime, initialsOf unchanged.
- Rewrote src/lib/types.ts (content exact): header now cites §4 + §6 and "paise for INR"; AssetType + "INDEX"; DocType → PAN | AADHAAR | PASSPORT | DRIVERS_LICENSE (NATIONAL_ID removed); added OrderSide/OrderKind/OrderStatus; MarketQuote gained exchange?/prevCloseCents?; PositionDTO → PositionDetail (name, last/mktValue/unrealizedPnl/dayPnl cents + dayPnlPct); added Phase 2 §6b trading types (OrderDTO, PlaceOrderPayload, FillInfo, PlaceOrderResponse, OrdersResponse) and §6a WS types (TickQuote, DepthLevel, DepthSnapshot, Candle, CandlesResponse, WsTicketResponse, RiskRejectCode).
- formatUsd consumers (rg -l "formatUsd|formatSignedUsd" src → 6 files, NOT edited, left for frontend task): src/components/meridian/dashboard/watchlist-card.tsx, dashboard/ledger-card.tsx, dashboard/summary-cards.tsx, dashboard/market-movers-card.tsx, views/landing-view.tsx, ticker-tape.tsx.
- `bunx tsc --noEmit | rg -v "examples|skills"` → 10 errors under src/, all expected handoffs, none in the two rewritten files: (1) 7× views importing removed formatUsd/formatSignedUsd (ledger-card 14,10+14,27; market-movers-card 23,27; summary-cards 8,3+9,3; watchlist-card 23,27; ticker-tape 7,27; landing-view 13,3); (2) src/app/api/portfolio/summary/route.ts(44,5) TS2322 — route still returns Phase 1 {symbol,qty,avgCostCents} positions, not PositionDetail (backend task); (3) src/components/meridian/views/onboarding-view.tsx(51,5) TS2322 — view still uses removed DocType "NATIONAL_ID" (frontend task).
- `bun run lint` → exit 0, no findings (output tail: `$ eslint .`).

Stage Summary:
- Client contract + formatters are INR/Phase 2-ready: money everywhere is integer paise with Indian digit grouping (₹ and symbol-free pts variants), and lib/types.ts now mirrors §6a WS + §6b trading 1:1 including RiskRejectCode.
- Outstanding known-broken consumers (intentionally untouched): 6 views on formatUsd/formatSignedUsd, onboarding-view NATIONAL_ID DocType, and portfolio/summary route PositionDetail shape — to be fixed by the frontend/backend Phase 2 tasks.
---
Task ID: 8
Agent: Z.ai Code (lead, via subagent)
Task: market-data mini-service (:3003) — feed sim → bus → hot cache → socket.io WS gateway + REST + internal emit.

Work Log:
- Read worklog.md, ARCHITECTURE.md §6a (WS contract: rooms asset:{s}/depth:{s}/user:{id}, events hello/snapshot/tick/depth/order-update/portfolio-nudge/pong, POST /internal/emit with AUTH_SECRET) and prisma/seed.ts — instruments.json mirrors the 21-instrument NSE/BSE universe 1:1 (16 STOCK, 2 ETF, 3 INDEX; vol scaled to per-tick).
- Wrote mini-services/market-data-service/{package.json, instruments.json, index.ts} (package.json + instruments.json verbatim); `bun install` → socket.io@4.8.4 (21 packages).
- Port 3003 free (pgrep clean). Started `bun run dev` (bun --hot index.ts): "market-data-service on :3003 · 21 symbols · tick 500ms".
- BUG FOUND IN SPEC + FIX: with socket.io v4.8 + `path: "/"`, engine.io's attach() captures ALL "request" listeners and its check() (path === req.url.slice(0, path.length)) matches every URL, so /health + /quotes + /internal/emit were hijacked and answered {"code":0,"message":"Transport unknown"} (HTTP 400) — verified live and in engine.io 6.6.11 source (server.js attach/handleRequest). Minimal fix in index.ts (everything else byte-identical): named the REST handler `router`, and right after `new Server(httpServer, {path:"/"})` rewired to cooperative dispatch — removeAllListeners("request"/"upgrade"), re-add router first, then a handoff listener that calls io.engine.handleRequest(req,res) for EIO/socket.io URLs, plus an "upgrade" listener calling io.engine.handleUpgrade. WS contract path "/" unchanged; §6a client URL io("/?XTransformPort=3003") unaffected.
- Verification (raw outputs):
  (5a) GET /health → {"ok":true,"service":"market-data","symbols":21,"uptimeSec":7,"ts":1791002516273}
  (5b) GET /quotes?symbols=NIFTY50,RELIANCE → {"quotes":[{symbol NIFTY50, lastPriceCents 2485480, prevCloseCents 2485055, changePct 0.02, volume 0, ...},{symbol RELIANCE, lastPriceCents 294935, prevCloseCents 295120, changePct -0.06, volume 1935, ...}]} — §6a TickQuote shape, paise.
  (5c) GET /?EIO=4&transport=polling → 0{"sid":"xIGVUo2hIXbvZyQPAAAA","upgrades":["websocket"],"pingInterval":25000,"pingTimeout":60000,"maxPayload":1000000}
  (5d) POST /internal/emit wrong secret → {"ok":false,"error":"bad secret"} HTTP 401 ✓
  (5e) POST /internal/emit with AUTH_SECRET → {"ok":true,"sockets":0} ✓
  (5f) /quotes?symbols=RELIANCE twice 2s apart → lastPriceCents 294690 (ts …526919) → 294715 (ts …528919) — feed live at 500ms cadence.
- Bonus E2E (socket.io-client): hello(21 symbols) → subscribe[RELIANCE,BOGUS] → snapshot RELIANCE only (unknown symbol ignored) → watch-depth TCS → depth 5×5 levels → ping{t:1234} → pong:t1234 → bad token → auth-error:invalid ticket → tick:RELIANCE:295075 ×2. Valid purpose="ws" JWT (HS256, AUTH_SECRET) → auth-ok {"userId":"ws-test"} → POST /internal/emit room user:ws-test → {"ok":true,"sockets":1} → client received ORDER-UPDATE {"order":{"id":"t2","status":"FILLED"}} — full §6a order-confirmation arrow proven.
- service.log clean (no errors); process running (bun --hot index.ts). /tmp test client removed.

Stage Summary:
- market-data-service is LIVE on :3003: 21-symbol simulated feed (500ms ticks, tick-size ₹0.05 snapped, mean reversion), hot-cache book, socket.io WS gateway honoring §6a exactly (subscribe/unsubscribe/watch-depth/unwatch-depth/auth-user/ping; hello/snapshot/tick/depth/pong/auth-ok/auth-error), REST /health + /quotes, and S2S POST /internal/emit (AUTH_SECRET, timing-safe compare) for order-update/portfolio-nudge pushes. instrument universe mirrors prisma/seed.ts.
- ONE deviation from verbatim spec (documented above): cooperative request dispatch rewiring after io attach — required because socket.io v4 with path "/" otherwise swallows all REST routes with "Transport unknown". Restart: `cd /home/z/my-project/mini-services/market-data-service && (nohup bun run dev > service.log 2>&1 &)`; stop via `pkill -f "bun --hot index.ts"`. Next: Task 9 trading REST (/api/ws-ticket issues the purpose="ws" JWT this service verifies).

---
Task ID: 9+10
Agent: Z.ai Code (lead, via subagent)
Task: Trading core — risk engine, sim-broker engine, 2s matcher, order APIs, candles, ws-ticket, live overview/portfolio.

Work Log:
- Read worklog, ARCHITECTURE.md §6 contract, and reused APIs 1:1 (api-utils, jwt, audit, rate-limit, db, types, schema). Verified :3000 (Next dev) and :3003 (market-data) healthy before starting.
- Adaptations per task notes: (1) audit() requires a Request → added minimal exported auditSystem(action, detail) to src/lib/security/audit.ts (ip=null, userAgent="meridian-matcher"; extracts detail.userId/detail.detail into existing columns — no schema or existing call-site changes) AND extended AuditAction with ORDER_PLACED/ORDER_FILLED/ORDER_REJECTED/ORDER_CANCELLED so route call sites typecheck. (2) WINDOW.MIN_1 already exists (=60_000) → used it directly; the spec's `WINDOW.MIN_1 ?? 60_000` would be a TS 5.6 unreachable-?? error on a literal type. (3) ws-ticket needs purpose "ws" → extended TokenPurpose in src/lib/security/jwt.ts to "session"|"mfa"|"ws" (§6a; :3003 verifies purpose="ws").
- Created 6 lib files verbatim: src/lib/market/quotes-client.ts, src/lib/trading/{notify,risk,dto,engine,matcher}.ts. New routes: /api/orders (POST+GET), /api/orders/[id]/cancel, /api/candles, /api/ws-ticket; rewrote /api/market/overview (live join, INDEX→indices, 12 movers) and /api/portfolio/summary (live mark-to-market PositionDetail). ENV: no new keys — MARKET_DATA_URL defaults to 127.0.0.1:3003, INTERNAL_EMIT_SECRET falls back to AUTH_SECRET (what :3003 expects), kill switch unset.
- BUG (environment, not code): first market order → 500 EXECUTION_ERROR; dev.log showed "Unknown argument brokerRef" on order.update — the long-running dev server still held the PRE-Task-6 Prisma client in memory while node_modules/.prisma was current. Restarted dev server (bun run dev → tee dev.log) and cleaned the one orphaned NEW order row via the cancel API (which also pre-verified T4b).
- tsc noise fix: mini-services/market-data-service/index.ts import.meta.dir errors were pre-existing since Task 8 (root tsconfig includes **/*.ts; DOM lib lacks Bun's ImportMeta.dir) → added 3-line ambient mini-services/market-data-service/bun.d.ts (interface ImportMeta { dir: string }). Not my code path, but required to satisfy the "only 7 known errors" gate.
- Verification: `bun run lint` → exit 0, no findings. `bunx tsc --noEmit | rg -v "examples|skills"` → exactly the 7 documented handoffs (ledger-card ×2, summary-cards ×2, market-movers-card, watchlist-card, ticker-tape, landing-view formatUsd/formatSignedUsd + onboarding-view NATIONAL_ID); portfolio/summary route error GONE.
- E2E (cookie jar /tmp/m2-cookies.txt, demo@meridian.dev): T1 market BUY 5 RELIANCE → HTTP 201 {"status":"FILLED",filledQty:5,avgFillPriceCents:294490,brokerRef:"SIM-MURX73NB",fill:{5, 294490, fee 442}}. T2 portfolio → RELIANCE qty 55 avgCost 289499, cash 78,647,108p (=80,120,000−1,472,892 exact), ledger[0]=DEBIT TRADE "BUY 5 RELIANCE @ ₹2944.90" balanceAfter 78,647,108, live dayPnl fields populated. T3 SBIN LTP 82735 → LIMIT BUY 10 @ 81080 (−2%) → 201 status NEW. T4a OPEN scope lists it; T4b cancel → 200 CANCELED. T5 marketable LIMIT BUY 10 SBIN @ 83355 (LTP+0.5%) → NEW at placement, matcher FILLED by first 2s poll, final {status FILLED, filledQty 10, avgFillPriceCents 82925 = min(ltp,limit) ✓, brokerRef SIM-MURX7QSG}. T6 SELL 100000 RELIANCE → 422 INSUFFICIENT_QTY "You hold 55 unit(s)…". T7 BUY NIFTY50 → 422 NOT_TRADEABLE. T8 RELIANCE LIMIT @ 206202 (−30%) → 422 PRICE_BAND. T9 /api/ws-ticket → 200 {ticket} JWT payload purpose:"ws", 120s. T10 POST /api/orders without cookie (origin-guard headers kept, jar dropped) → 401 NO_SESSION. Bonus: /api/candles?symbol=RELIANCE → 90 bars (2026-07-06→2026-10-03); without symbol → 400 VALIDATION.
- DB spot-check: matcher audit row via auditSystem {action ORDER_FILLED, ip null, userAgent meridian-matcher, detail "BUY 10 SBIN @ ₹829.25 (matcher)"}; Trade count 2; TRADE-category ledger 4 (2 seeded + 2 new). dev.log tail clean — no matcher cycle errors, no unhandled exceptions.

Stage Summary:
- Phase 2 trading core is live end-to-end: risk engine always in the order path (KILL_SWITCH/MARKET_CLOSED/NOT_TRADEABLE/INSUFFICIENT_QTY/FEED_UNAVAILABLE/PRICE_BAND/INSUFFICIENT_FUNDS), MARKET fills instantly at LTP±25bps snapped to ₹0.05, LIMIT/STOP/STOP_LIMIT rest and are matched every 2s against the :3003 hot cache with cash re-check, every fill is one Prisma tx (Order→Trade→append-only LedgerEntry→Position avg-cost/realized-PnL→Wallet cache) with fee min(₹20, 0.03%, floor ₹1), WS order-update + portfolio-nudge pushed to user:{id} rooms, overview/portfolio join live quotes with seeded-DB fallback, candles + 120s ws-ticket (purpose "ws"). Matcher fills audited via new auditSystem helper. All response shapes match lib/types.ts 1:1 — ready for frontend order-ticket/positions wiring.

---
Task ID: 12
Agent: frontend-styling-expert (completed by successor verifier)
Task: Phase 2 frontend — live terminal (WS quote layer, indices strip, live tape/movers/watchlist, instrument detail w/ candlesticks+SMA+RSI+depth+order ticket, holdings+orders cards, WS status footer), India copy alignment, tsc fixes.

Work Log:
- (per read-only file inventory of the delivered build) deps added to package.json: socket.io-client 4.8.4 + lightweight-charts 5.2.1.
- src/hooks/use-quotes.ts: ONE shared socket.io connection (module-level singleton getSocket(), same-origin io('/?XTransformPort=3003'), never a `path` option, transports websocket+polling, infinite reconnection); useQuoteSocket(symbols) per-symbol live quotes; useUserEvents() joins the authed user room — order-update events raise success/reject toasts and invalidate orders/portfolio queries.
- src/hooks/use-orders.ts: useOrders / usePlaceOrder / useCancelOrder over the §6b REST contract.
- New dashboard components: indices-strip.tsx (NIFTY 50 / BANK NIFTY / SENSEX live point chips), positions-card.tsx (holdings, live mark-to-market + unrealized P&L), orders-card.tsx (OMS feed with status chips + inline Cancel for NEW orders), instrument-detail.tsx (candlestick chart + SMA20/50 + volume histogram + RSI pane via lightweight-charts, 5×5 depth panel, order ticket with MARKET/LIMIT/SL-M/SL and big ticking Last).
- Live wiring: dashboard-view (indices strip + watchlist + holdings + movers + orders + ledger), site-header, site-footer (WS status dot + RTT), ticker-tape, landing-view hero quote card — all on the WS quote layer; formatUsd/formatSignedUsd fully removed (0 occurrences in src); onboarding copy aligned to India KYC (PAN / Aadhaar / Passport / DL doc types, DigiLocker mention, AES-256 note).
- Verification state at handoff: `bunx tsc --noEmit | rg -v "examples|skills"` → 0 errors in src (Task 7's 7 documented handoffs all resolved); `bun run lint` → exit 0.

Stage Summary:
- src/hooks/{use-quotes,use-orders}.ts, src/components/meridian/{indices-strip,instrument-detail,dashboard/{positions-card,orders-card}}.tsx, dashboard-view/site-header/site-footer/ticker-tape/landing-view live wiring, onboarding India copy; package.json +socket.io-client@4.8.4 +lightweight-charts@5.2.1; formatUsd removed.
- tsc + lint verified clean read-only by successor before Task 13 browser E2E (which found only 2 small mobile-layout CSS issues, fixed there).

---
Task ID: 13
Agent: Z.ai Code (lead, via subagent)
Task: Final browser E2E verification of Phase 2 + fixes.

Work Log:
- STEP 1 health: /api/health {ok:true,db:true}; :3003/health {ok:true,symbols:21,uptimeSec:3157}; /api/market/overview → movers 12 (WIPRO/TCS/TATAMOTORS…) + indices [BANKNIFTY 53,327.25, NIFTY50 24,836.65, SENSEX 81,102.60] live paise.
- (a) LANDING PASS — renders, ticker tape with live ₹ quotes (RELIANCE ₹2,944.65 ▼ −0.22% · TCS ₹4,006.00 ▼ −2.35% · …), footer bottom 2122.75 ≈ content bottom 2123 (mt-auto anchor), no horizontal scroll. Evidence /tmp/meridian-e2e/01b-landing-desktop.png.
- (b) LOGIN PASS — profile carried a pre-existing session, so signed out first then signed in via auth → Login tab as demo@meridian.dev / MeridianDemo1 → dashboard. (Note: duplicate "Session expired" toasts fire right after deliberate sign-out — in-flight queries 401 into the global handler; cosmetic, left as-is.) Evidence 02-after-login.png.
- (c) DASHBOARD LIVE PASS — indices chips CHANGED between snapshots 4s apart: NIFTY 24,810.25→24,822.75, BANK NIFTY 53,301.90→53,317.75, SENSEX 81,303.80→81,285.60; watchlist rows show ₹ prices + ▲/▼ % badges (TCS ₹4,033.40 ▼ −1.68% · 343.6K …); footer green animate-ping bg-profit dot + RTT "1 ms · Simulated NSE feed"; holdings INFY 30 × ₹1,810.00 (+₹727.50) and RELIANCE 55 × ₹2,894.99 (+₹3,226.30); KPIs in INR with Indian grouping (TOTAL EQUITY ₹10,04,209.57, CASH ₹7,74,123.62, DAY P&L −₹183.40). Evidence 03-dashboard.png.
- (d) DETAIL+CHART PASS — RELIANCE dialog: candlestick pane + SMA20/50 + volume bars + RSI pane confirmed by canvas pixel sampling (main pane 27 distinct colors, painted; 11 canvases) AND VLM screenshot review ("candles red/green, SMA lines, volume bars, RSI 70/59.13/30, no glitches"); ORDER BOOK · 5 LEVELS bid/ask updates (top bid ₹2,971.95→₹2,973.35, spread ₹1.20); big Last ticking ₹2,973.20→₹2,973.40. Evidence 04-reliance-dialog.png.
- (e) ORDER FLOW PASS — TCS ticket, side BUY, MARKET, qty 1 → submit → toast "Order filled · BUY 1 TCS @ ₹4,049.30" (pushed over WS order-update); Orders card row 05:41 TCS BUY MARKET 1 @ ₹4,049.30 FILLED; holdings TCS 1→2 (new avg ₹4,050.28 — TCS 1 had pre-existed from the partial frontend E2E); cash ₹7,74,123.62→₹7,70,073.11 = −₹4,050.51 (fill ₹4,049.30 + fee ₹1.21 = 0.03% floor ₹1). Evidence 05/06 pngs.
- (f) RESTING ORDER + CANCEL PASS — SBIN LTP ₹826.00 → LIMIT BUY 2 @ ₹784.70 (−5%, inside 20% band) → toast "Order accepted · BUY 2 SBIN", Orders row "05:42 SBIN BUY LIMIT 2 @ ₹784.70 NEW" with Cancel control → click Cancel → toast "Order cancelled", row flips to CANCELED (matcher did not fill it while resting ✓). Evidence 07/08/09 pngs.
- (g) RESPONSIVE+THEME PASS after FIX — at 390×844 the page had 28px horizontal overflow (scrollWidth 418): watchlist add-symbol input's intrinsic min-width (size=20) + nowrap card content floored the mobile implicit grid tracks at min-content (watchlist card 402px, holdings row `truncate` subtitle nowrap → holdings card 402px). FIX (frontend): watchlist-card.tsx `relative flex-1`→`relative min-w-0 flex-1` + Input `min-w-0`; dashboard-view.tsx both card grids given explicit `grid-cols-1` (= minmax(0,1fr)) alongside their md:/lg: variants. Re-verified: scrollWidth 390 = viewport, holdings/watchlist cards shrink, `truncate` now ellipsizes, dialog opens full-width 390px usable with painted chart, footer 390px; desktop 1280 re-checked (3-col track 362.656px ×3, watchlist spans 2 = 741px) unchanged. Light mode toggled: VLM review of 13/14 pngs — dark text on light bg, candles/SMA/volume/RSI readable, no contrast or layout breakage; toggled back to dark (default). Evidence 10–15 pngs.
- (h) CONSOLE PASS — `agent-browser errors` empty for the whole session; console shows only React DevTools/HMR info lines and a benign repeated Radix warning "Missing Description or aria-describedby for DialogContent" (a11y lint hint, not an error); WS is same-origin io('/?XTransformPort=3003') proven by `GET /?XTransformPort=3003&EIO=4&transport=polling … 200` requests + green footer dot + moving quotes — no WS failures.
- STEP 3 reruns after fixes: `bun run lint` exit 0; `bunx tsc --noEmit 2>&1 | rg -v "examples|skills"` → empty output (0 src errors); affected flows re-verified in browser (mobile overflow gone, watchlist input accepts text + Add enables, desktop layout unchanged).
- STEP 4 dev.log: tail 30 = clean GET 200s (overview/orders/portfolio cadence); the only error-shaped lines (311/834/1353 of 4572) are stale Task-7-era "Export formatSignedUsd doesn't exist" compile errors from BEFORE the frontend fix (formatUsd now 0 occurrences in src; last occurrence long before this session) — zero unhandled errors/stack traces during this session.

Stage Summary:
- Phase 2 (M2–M4 core trading loop) is browser-verified end-to-end and shippable: landing → login → live dashboard (WS indices/watchlist/holdings/KPIs) → instrument detail (candles/SMA/RSI/depth/LTP) → MARKET fill with fee-correct cash debit and WS toast → LIMIT rest + cancel via WS, all with zero browser errors; mobile 390px and light mode clean after 2 small CSS fixes (watchlist-card.tsx, dashboard-view.tsx). lint + tsc clean. Evidence: /tmp/meridian-e2e/*.png.

---
Task ID: 13b
Agent: Z.ai Code (lead, via subagent)
Task: Polish — dedupe global "Session expired" toast on in-flight 401s after sign-out.

Work Log:
- src/lib/api-client.ts: made the global 401 → session-expired path idempotent. Added module-level `SESSION_EXPIRY_DEBOUNCE_MS = 4_000` + `let lastSessionExpiryAt = 0`; on a non-auth-endpoint 401, the `meridian:session-expired` dispatch only fires if `Date.now() - lastSessionExpiryAt >= 4000` (first hit sets the timestamp and dispatches, later 401s within the window are silently skipped). The existing `AUTH_FALLBACK_PATHS` exemption (login/mfa/register/otp/session → 401 stays a user-level error) is untouched; everything else identical. providers.tsx toast + resetToLanding + queryClient.clear handler unchanged.
- Verify: `bunx tsc --noEmit | rg -v "examples|skills" | head -5` → empty (clean). `bun run lint` → exit 0. Browser sanity via agent-browser: landing → Log in as demo@meridian.dev / MeridianDemo1 → dashboard ("Good morning, Demo") loads → sign out via avatar menu → network log shows TWO in-flight authenticated queries 401ing post-signout (/api/watchlist, /api/portfolio/summary) yet exactly ONE "Session expired" toast (+ the expected "Signed out" toast); SPA reset to landing confirmed.

Stage Summary:
- Duplicate "Session expired" toasts after sign-out fixed via a 4s idempotency guard on the global 401 dispatch in api-client.ts; tsc/lint clean, browser-verified (2× 401 → 1 toast).

---
Task ID: 14-foundation
Agent: Z.ai Code (lead)
Task: Session restore (secrets/services), KYC docType bug fix, Phase 3 foundation (GTT/AMO/Alerts contract + schema).

Work Log:
- Runtime restore: .env had lost AUTH_SECRET/FIELD_ENCRYPTION_KEY between sessions; regenerated both, cleared 15 stale sessions + 3 KycProfile rows (old-key ciphertext), restarted Next (:3000) and market-data (:3003) services, verified health + live feed.
- FIXED BUG: /api/kyc/submit zod enum still expected PASSPORT|DRIVERS_LICENSE|NATIONAL_ID while India frontend sends PAN|AADHAAR -> 400. Enum now PAN|AADHAAR|PASSPORT|DRIVERS_LICENSE; schema comment aligned. Browser-verified: full KYC re-submit -> auto-APPROVED -> dashboard live.
- Verified base app E2E after restore: demo login -> dashboard (watchlist/positions/movers live), instrument detail renders.
- Foundation for Phase 3: prisma Order += expiresAt (GTT), activateAt (AMO), status comment += QUEUED; new PriceAlert model (userId, symbol, condition ABOVE|BELOW, targetCents, status ACTIVE|TRIGGERED|CANCELED, triggeredAt) + relations on User/Asset; bun run db:push OK, PriceAlert table live.
- src/lib/types.ts contract extended (source of truth for Tasks 14-a/14-b): OrderKind += "GTT"; OrderStatus += "QUEUED"; OrderDTO += expiresAt/activateAt; PlaceOrderPayload += expiresAt/amo; new AlertCondition/AlertStatus/PriceAlertDTO/CreateAlertPayload/AlertsResponse; UserWsEvent += "alert" with AlertEventPayload.

Stage Summary:
- Sandbox AMO semantics (documented decision): the simulated exchange runs a continuous feed; sessions roll at the top of each hour. AMO orders are QUEUED and released by the matcher at the next hour boundary (nextSessionOpen()); regular orders behave as before. GTT is Zerodha-style: trigger (stopPriceCents) + limit (limitPriceCents) + expiry (expiresAt, max 365d), survives restarts.
- Demo user state: demo@meridian.dev / MeridianDemo1, KYC APPROVED, INR wallet ~7.7L, positions RELIANCE/INFY/SBIN/TCS.
- Next: Task 14-a (backend GTT/AMO/alerts/screener) and 14-b (frontend ticket/alerts/screener tab) run in parallel against this contract.
---
Task ID: 14-b
Agent: full-stack-developer
Task: Phase 3 frontend — GTT/AMO order ticket, price alerts UI (popover + card + WS toast), Screener tab.

Work Log:
- Read worklog, ARCHITECTURE.md §5/§6, frozen contract src/lib/types.ts, and all touched files (instrument-detail, orders-card, dashboard-view, use-quotes, use-orders, use-market, app-store, format, api-client, watchlist/movers cards) before coding. Noted: instrument detail lives at dashboard/instrument-detail.tsx (task path was approximate); details open via onOpen callbacks (dashboard-view setState), not app-store.
- format.ts: added formatTimeHM (ISO → "14:00" local 24h) and formatDateShort (ISO → "12 May") for the QUEUED release subtext and GTT expiry labels. No other formatter changes.
- src/hooks/use-alerts.ts (new): ALERTS_KEY, useAlerts (GET /api/alerts, 15s poll), useCreateAlert (POST, success toast "Alert set for {symbol}" + invalidate — typed <unknown, Error, CreateAlertPayload> since the POST response shape is not in the frozen contract), useCancelAlert (DELETE ?id=…, optimistic removal + rollback + invalidate, mirrors useCancelOrder).
- src/hooks/use-screener.ts (new): useScreener (GET /api/market/screener → ScreenerResponse { quotes }, 5s poll).
- src/hooks/use-quotes.ts: module-level alertListeners set + sock.on("alert") dispatch inside the SAME singleton createSocket (exactly one connection preserved); useUserEvents handles `alert` → sonner toast.info "Price alert · {symbol}" / description "Crossed {condition} ₹{target}" (formatInr) + invalidate ALERTS_KEY. order-update/portfolio-nudge behavior untouched.
- instrument-detail.tsx: (a) ORDER_TYPES += { GTT, "GTT" }; GTT panel = trigger + limit ₹ inputs and expiry Select (1 week/1 month/3 months → ISO computed at submit via 7/30/90d). Defaults are DERIVED, not state-synced (react-hooks/set-state-in-effect lint rule): trigger = LTP ∓0.5% (BUY −, SELL +) snapped to the ₹0.05 tick, live-tracking until the user edits (dirty flags reset when re-entering GTT via the type select), limit mirrors trigger until edited. Payload: { type:"GTT", stopPriceCents, limitPriceCents, expiresAt } with Math.round(x*100) paise conversion. Validation: positive, trigger ≥ 5 paise, trigger within ±20% of LTP with an inline amber hint (renders band range) that blocks submit; est. total uses the GTT limit. (b) AMO: Checkbox "After market (AMO)" only for MARKET/LIMIT with helper "Queued now — releases at the next hourly session open."; payload gains amo:true. (c) AlertBellButton in the ticket header: Popover with ABOVE/BELOW toggle (profit/loss styling), ₹ target input defaulting to LTP (content remounts per open so the default refreshes), "Create alert" → useCreateAlert; closes on success.
- orders-card.tsx: QUEUED renders a neutral badge (muted dot, border-border/60 bg-muted/30) + subtext "Releases ~HH:00" from activateAt (formatTimeHM); GTT rows show "{qty} · T ₹trigger · L ₹limit" plus "Expires {d MMM}" from expiresAt; Cancel now also offered for QUEUED (NEW/PARTIALLY_FILLED/QUEUED).
- dashboard/alerts-card.tsx (new): CANCELED filtered out; ACTIVE section first (▲/▼ glyph by condition, target via formatInr, "Set {relativeTime}", X cancel), TRIGGERED below (green "Triggered" badge, "Triggered {relativeTime}", no cancel); empty state "No alerts yet — set one from any instrument."; max-h-96 + thin-scroll, card conventions of siblings.
- dashboard/screener-card.tsx (new): Card with filter chips (All · Gainers · Losers · Most Active) + uppercase text search (symbol/name); shadcn Table in max-h-[420px] overflow-y-auto thin-scroll wrapper, sticky header; columns Symbol(+name+type badge) / LTP / Chg % / Volume / High / Low; rows join live WS quotes (useQuoteSocket over the screener symbols — supplies High/Low from TickQuote, which the frozen MarketQuote lacks, plus sub-second LTP/pct/volume); click-a-header toggle sort (default Volume desc; new numeric cols default desc, symbol asc; chips reset sort: Gainers→chg desc, Losers→chg asc, Most Active→volume desc); profit/loss tokens, tabular-nums, INDEX symbols use formatPts; row click (and focusable symbol button) opens the instrument detail via the same onOpen flow as watchlist/movers.
- dashboard-view.tsx: shadcn Tabs — Overview (default) and Screener; Overview keeps the existing grids (Watchlist+Positions, then Movers+Orders+Alerts in the 3-col row) with LedgerCard now full-width below; SecurityCard and InstrumentDetailDialog stay outside the Tabs (dialog survives tab switches). Greeting/KYC banner/SummaryCards untouched.
- Cross-agent fix (src gate): src/lib/db.ts (owned by 14-foundation/14-a, loaded via require-cache purge) used the destructured PrismaClient value as a TYPE → TS2749; added `type PrismaClientInstance = InstanceType<typeof PrismaClient>` and used it in the global cache declaration. Type-level only, no runtime change.
- Verification: `bun run lint` exit 0; `bunx tsc --noEmit | rg -v "examples/|skills/"` → empty (0 src errors). /api/market/screener smoke → 200 {quotes:[…]} matching the contract; /api/alerts → 401 unauth (correct). dev.log: only parallel-agent 500s (api/alerts + GTT order.create PrismaClientValidationError) from the stale in-memory Prisma client in the long-running dev server (needs a dev-server restart — explicitly out of my scope, documented in Task 9+10); frontend pages compile/render (GET / 200) and all Phase 2 flows are untouched.

Stage Summary:
- Phase 3 frontend shipped against the frozen types.ts contract: GTT (trigger/limit/expiry, live LTP-tracked defaults, ±20% band validation, ₹0.05 floor) and AMO (queued-order toggle + helper) in the order ticket; price alerts end-to-end UX (bell popover create → alerts card with active/triggered sections → WS `alert` toast + cache invalidation → optimistic cancel); Screener tab (sortable/filterable/searchable live table); Orders card renders QUEUED release time + GTT trigger/limit/expiry. Files: format.ts, use-alerts.ts, use-screener.ts, use-quotes.ts, instrument-detail.tsx, orders-card.tsx, alerts-card.tsx, screener-card.tsx, dashboard-view.tsx, db.ts (type-only fix). Backend routes land from 14-a; until the dev server is restarted to pick up the new Prisma client, GET/POST /api/alerts 500 and the alerts card shows its retrying error state (by design). lint + tsc clean.
---
Task ID: 14-a
Agent: full-stack-developer
Task: Phase 3 backend - GTT orders, AMO orders, price alerts, market screener endpoint (against frozen contract in src/lib/types.ts).

Work Log:
- Read worklog + ARCHITECTURE.md (S6, S1c/S1d) + full source of contract-critical files before coding.
- risk.ts: added nextSessionOpen() (next top-of-UTC-hour boundary strictly after now - sandbox analog of the next pre-open release window); assessRisk now treats GTT like STOP_LIMIT for the +/-20% trigger band and like LIMIT for the BUY funds reservation. All other kinds unchanged.
- orders/route.ts: type enum += GTT; optional expiresAt (z.string().datetime, must be now+5min..now+365d) and amo (MARKET/LIMIT only, never with GTT). Open-BUY reservation query now includes LIMIT and GTT BUYs. AMO path creates QUEUED + activateAt=nextSessionOpen(now), audits "AMO ..."; GTT path creates NEW + expiresAt, audits "GTT ... trigger= limit=". GET scope=OPEN includes QUEUED.
- matcher.ts (2s cycle, one feed snapshot per cycle): (1) AMO release - QUEUED with activateAt<=now -> NEW (activateAt kept) + audit "released AMO ..." + order-update; MARKET AMOs fill in the same cycle via a MARKET execution sweep that also retries MARKET orders stranded NEW by a past feed outage (latent bug fixed). (2) fillPriceFor case GTT: BUY fires when LTP<=trigger (fill min(LTP,limit)), SELL when LTP>=trigger (fill max(LTP,limit)). (3) GTT expiry: expired GTT -> CANCELED/EXPIRED + order-update + audit ORDER_CANCELLED. (4) Price alerts: ACTIVE alerts evaluated on the same quote snapshot (symbols merged into one fetchLiveQuotes call); ABOVE LTP>=target, BELOW LTP<=target -> TRIGGERED + triggeredAt + WS "alert" event + audit ALERT_TRIGGERED. Shared fill helper (cash re-check -> transactional fill -> audit -> WS) extracted for DRY.
- dto.ts: toOrderDTO emits expiresAt/activateAt ISO-or-null; new toAlertDTO (asset name joined).
- audit.ts: AuditAction union extended with ALERT_CREATED / ALERT_TRIGGERED / ALERT_CANCELED.
- NEW /api/alerts (GET list<=50 with asset name; POST validates asset + live quote (503 FEED_UNAVAILABLE) + 30-ACTIVE cap (422 ALERT_LIMIT), audits ALERT_CREATED; DELETE ?id= owner-only, ACTIVE->CANCELED (audits ALERT_CANCELED), TRIGGERED->422 INVALID_STATE, CANCELED idempotent). Calls ensureMatcher() at module load so alerts evaluate before any order exists.
- NEW /api/market/screener (public GET, { quotes: MarketQuote[] } for all 21 assets, live feed joined over DB fallback like overview).
- Cancel route now also accepts QUEUED (AMO) orders - deviation from task list, required so AMO can be canceled before release (reported).
- DEV-SERVER FIX (no restart): running Next process had the pre-Phase-3 Prisma client pinned in Node's require cache and the pre-Phase-3 matcher interval pinned on globalThis (both survive hot reload). db.ts now versions the PrismaClient on the generated client file's mtime (purge require cache + rebuild on change, reuse otherwise); matcher.ts versions its interval on matcher source mtime (clears stale closure timers). Both documented in-code; prod restart behavior unchanged.
- Verified: lint clean; tsc clean in src/** (only pre-existing examples//skills/ errors); live smoke tests below.

Stage Summary:
- GTT/AMO/alerts/screener are live end-to-end on the running server: GTT SELL RELIANCE (trigger LTP+1%, limit trigger+0.1%, exp 7d) -> 201 resting NEW; AMO BUY MARKET SBIN -> 201 QUEUED activateAt 18:00Z -> released + FILLED by matcher at session open (trade row 1 @ 83090p, fee 100p, ledger updated); GTT with 6-min expiry auto-canceled CANCELED/EXPIRED; alert ABOVE INFY -> 201 ACTIVE then DELETE -> CANCELED; screener returns 21 quotes. Full audit trail present for every step (user + matcher contexts).
- API notes for 14-b (frontend): PlaceOrderPayload accepts expiresAt/amo; OrderDTO now carries expiresAt/activateAt; scope=OPEN includes QUEUED (AMO) rows - render them as "queued for next session"; QUEUED orders are cancellable; WS "alert" event payload { alert: PriceAlertDTO }; screener tab can consume GET /api/market/screener (public).
- Next: 14-b (frontend GTT/AMO ticket + alerts UI + screener tab) against this backend.

---
Task ID: 14-integration
Agent: Z.ai Code (lead)
Task: Integration verification + full browser E2E of Phase 3 features.

Work Log:
- Merged parallel outputs: src/lib/db.ts landed on 14-a's mtime-versioned PrismaClient (with 14-b's type-safe InstanceType fix); `bunx tsc --noEmit` 0 errors in src/**, `bun run lint` clean, dev.log error-free.
- Browser E2E (agent-browser, demo session): Screener tab — 21 rows, GAINERS/LOSERS/MOST ACTIVE chips, header sorting (volume desc verified), live LTP updates, no h-scroll at 390px. Order ticket — GTT option renders Trigger/Limit/Expiry with live-tracking defaults; AMO checkbox with release note; bell popover ABOVE/BELOW + target defaulting to LTP.
- Live loops proven on the running feed: alert ABOVE ₹2907 created via UI → feed crossed → status TRIGGERED + green badge in Price alerts card + WS push. GTT BUY (T ₹2,890 / L ₹2,891.50) placed via UI → resting NEW → feed crossed down → FILLED @ ₹2,902.90 (≤ limit), ledger TRADE −₹2,903.90 incl. fee. GTT SELL resting order cancelled via UI → CANCELED. AMO MARKET BUY SBIN placed via UI → QUEUED, "Releases ~19:00", cancellable (backend already proved release+fill at 18:00Z with audits). GTT expiry → CANCELED/EXPIRED (14-a test, rendered in card).
- Screenshots: /tmp/meridian-desktop-phase3.png, /tmp/meridian-mobile-phase3.png.

Stage Summary:
- Phase 3 (GTT/AMO/Alerts/Screener) is browser-verified end-to-end and shippable. Money paths intact (paise, double-entry ledger, fee engine). English-only verified (CJK sweep across repo: zero matches). Demo user: demo@meridian.dev / MeridianDemo1 (KYC APPROVED after re-submit; docType enum bug fixed).
- Next roadmap candidates: BO/CO order types, options chain + Greeks, margin engine (SPAN+exposure analog), notifications center, analytics dashboard, multi-language (i18n scaffolding exists via next-intl).
---
Task ID: 15-foundation
Agent: Z.ai Code (lead)
Task: Session restore + Phase 4 foundation (schema, contract freeze, seed admin).

Work Log:
- Runtime restore: .env had lost AUTH_SECRET/FIELD_ENCRYPTION_KEY again between sessions; regenerated both, cleared stale Session/OtpChallenge/KycProfile rows, restarted market-data service (:3003 healthy, 21 symbols). Demo user must re-submit KYC (browser flow, auto-approves).
- Contract freeze (source of truth for 15-a/15-b): ARCHITECTURE.md §8 (margin engine CNC 1x / MIS 5x / CO 5x / BO 5x with open-order margin reservation; CO/BO leg lifecycle via strategy+legKind+parentOrderId+targetCents on Order, OCO semantics, /api/orders/{id}/exit; /api/margin; /api/notifications GET/POST read/DELETE; /api/admin/risk runtime kill switch via SystemFlag + 5s cache, matcher skips fills while ON; demo admin admin@meridian.dev / MeridianAdmin1).
- prisma/schema.prisma: Order += product(CNC default)/strategy/legKind/parentOrderId/targetCents + @@index(parentOrderId); new Notification model (pruned to 100/user); new SystemFlag model; User.notifications relation. db:push OK, client regenerated (v6.19.2).
- src/lib/types.ts frozen: OrderProduct/OrderStrategy/OrderLegKind, OrderDTO += product/strategy/legKind/parentOrderId/targetCents, PlaceOrderPayload += product/strategy/targetCents, NotificationDTO/NotificationsResponse/MarkNotificationsReadPayload, MarginRequest/MarginResponse, RiskStatusResponse/RiskToggleResponse, UserWsEvent += "notification", RiskRejectCode += INVALID_PRODUCT/INVALID_LEG. toOrderDTO patched for the new fields (tree compiles).
- prisma/seed.ts: seedAdminUser() — admin@meridian.dev / MeridianAdmin1, role ADMIN, KYC APPROVED, ₹10,00,000 funded. Seed run OK (7 users).

Stage Summary:
- Phase 4 foundation is in place: schema live, contract frozen in types.ts + ARCHITECTURE.md §8, admin seeded, market-data feed running. 15-a (backend margin/CO/BO/notifications/risk) and 15-b (frontend ticket/legs/bell/console) can now run in parallel against §8.
---
Task ID: 15-a
Agent: full-stack-developer
Task: Phase 4 BACKEND — margin engine, CO/BO strategy legs + exit, notifications, runtime kill switch, short positions (ARCHITECTURE.md §8).

Work Log:
- NEW src/lib/trading/margin.ts: LEVERAGE {CNC:1, MIS:5}; marginForCents (CNC SELL from holdings → 0, else ceil(notional/leverage) rounded UP to whole rupees); estimateEntryPriceCents (limit-capped types LIMIT/GTT/STOP_LIMIT → limit price (GTT keeps §7 reserve-at-limit semantics), else LTP ±25bps snapped to ₹0.05 tick like marketFillPrice); sumReservedMarginCents over open orders (NEW/PARTIALLY_FILLED/QUEUED, both sides, unfilled remainder only; est = limit ?? 0 — MARKET open orders are transient, swept within one 2s matcher cycle, documented); requiredMarginForCents — exposure-aware: closing an opposite position releases margin, only the excess needs fresh margin, reducingOnly flag (see deviations).
- NEW src/lib/trading/kill-switch.ts: getKillSwitchState() reads SystemFlag TRADING_KILL_SWITCH with env TRADING_KILL_SWITCH=1 as boot override, 5s cache on globalThis, returns {on, source: flag|env|off}; setKillSwitch() upserts flag + invalidates cache.
- engine.ts: executeFill position block rewritten direction-aware — BUY over a short covers (realized (avg−price)×closedQty, excess opens long at price, crossing zero resets avg); SELL over a long closes (realized (price−avg)×closedQty only on closed part, oversell flips to short at price); SELL over flat/short opens/extends short with weighted avg of short legs, realized unchanged on pure extension. Trade/ledger/wallet/fee untouched; money Int paise.
- risk.ts: RiskContext += product/strategy/targetCents; openBuyNotionalCents → openReservedMarginCents (sum of margin of ALL open orders via margin.ts); BUY and MIS/CO/BO SELL reject INSUFFICIENT_FUNDS when reserved+required>cash (exposure-aware: reducingOnly passes); CNC SELL keeps holdings check with clear messages for negative positionQty; band checks unchanged; PRICE_BAND now exported for route-level leg validation; nextSessionOpen/marketFillPrice untouched.
- NEW src/lib/trading/legs.ts: onEntryFilled (ENTRY+strategy only → CO arms STOP leg, BO arms TARGET(LIMIT@target)+STOP leg; legs = product MIS, opposite side, parentOrderId, legKind set, strategy null so no recursion; auditSystem LEG_CREATED + notifyUser LEG_CREATED "Cover/Bracket armed") and handleLegFill (TARGET/STOP filled → cancel open siblings rejectReason OCO_CLOSED + WS + audit + notifyUser OCO_COMPLETED; EXIT filled → notifyUser ORDER_EXITED "Position exited"); afterFillHooks dispatcher for the matcher.
- notify.ts: notifyUser(userId,{type,title,body,refType?,refId?}) — creates Notification row, prunes feed to newest 100, emits WS "notification" {notification: DTO}, never throws. dto.ts: toNotificationDTO added.
- orders route POST: product (default CNC)/strategy/targetCents in zod with strategy combos (MARKET|LIMIT only, CO needs SL, BO needs SL+target, rejects expiresAt/amo); explicit CNC+strategy → 422 INVALID_PRODUCT, strategy forces MIS; entry rows created with legKind ENTRY (+targetCents for BO); route-level INVALID_LEG validation (BUY SL<estEntry, SELL SL>estEntry, BO target beyond entry, SL/target within ±20% of LTP); kill switch now via getKillSwitchState(); MARKET entries (incl. strategy) fill inline then onEntryFilled; notifications on placed/filled/rejected (incl. matcher-reject parity). GET unchanged (scope OPEN = QUEUED/NEW/PARTIALLY_FILLED).
- NEW exit route POST /api/orders/[id]/exit: own strategy ENTRY with filledQty>0 else 409 NOTHING_TO_EXIT; closedQty = Σ leg filledQty; cancels open legs (MANUAL_EXIT) + still-open entry remainder; creates MARKET EXIT leg (opposite side, product MIS, parentOrderId) for exitQty → matcher sweep fills it; audit ORDER_EXITED + notifyUser; 201 {order, exitOrder}; non-strategy → 409 NOT_EXITABLE.
- cancel route: legs (legKind ≠ ENTRY) → 409 NOT_CANCELLABLE "use exit on the parent order"; strategy ENTRY FILLED → 409 "Order filled — use exit"; + notifyUser ORDER_CANCELLED (WS kept).
- NEW /api/margin GET (session auth): zod query, 404 unknown symbol, 400 bad qty/missing limit, 503 feed down; returns MarginResponse {notional, required, available = cash − Σ reserved(open), leverage, feeEstimate = simFeeCents(notional)}.
- NEW /api/notifications (GET ?limit≤100 newest-first + unread; DELETE ?id / ?all=true) and /api/notifications/read (POST {ids|all} → readAt=now → {ok, unread}); origin guard + 30/min on mutations, owner-scoped writes.
- NEW /api/admin/risk GET/POST via new requireAdmin in api-utils (403 ROLE_REQUIRED); POST zod {killSwitch} → setKillSwitch + audit RISK_KILL_SWITCH_ON/OFF + notifyUser RISK to the actor; GET returns RiskStatusResponse with source.
- matcher.ts: kill-switch read once per cycle → skip everything while ON (release/expiry/fills/alerts, no notifications); notifyUser rows alongside every WS push (AMO release, GTT expiry, fills, INSUFFICIENT_FUNDS rejects, alert triggers); afterFillHooks after every fill (MARKET sweep included — arms CO/BO legs, runs OCO, notifies exits); BUY cash re-check is now margin- and exposure-aware (was full-notional — would have wrongly rejected MIS resting BUYs / SL cover legs).
- portfolio/summary: short-safe math — holdings query qty {not:0} (was gt:0, missed fresh shorts), unrealized/dayPnl = signed (Δprice)×qty for both directions, dayPnlPct against |costBasis|; mktValue stays signed; equity coherent. PositionDetail shape untouched.
- E2E (admin cookie jar, live feed): (a) /api/margin MIS BUY 10 RELIANCE → required 588,700p ≈ notional/5, CNC → 2,943,200p, 404/400/401 paths OK; (b) MIS BUY 400 RELIANCE (₹11.8L notional > ₹9.95L cash, margin ₹2.35L) FILLED, cash −₹1.83L (funding analog), MIS SELL 400 flatten FILLED → cash ₹9.95L; (c) CO MARKET BUY 5 SBIN SL ₹808.79 → 201 FILLED entry + STOP leg (parentOrderId=entry); (d) BO LIMIT BUY 5 SBIN @824.50 → matcher FILLED → TARGET+STOP legs → /exit → EXIT leg created + legs MANUAL_EXIT → sweep filled @823.40 → SBIN BO position flat; (e) INVALID_LEG (BUY SL above LTP, target below entry) + INVALID_PRODUCT (CNC+CO) + strategy+amo 400; (f) CNC SELL unheld → INSUFFICIENT_QTY; (g) MIS SELL 5 INFY unheld → short qty −5, mktValue −₹9,369, unrl −₹5.25, cover BUY realized (avg−price)×5; (h) 16 notification rows across types, read {all:true} → unread 0; (i) /api/admin/risk GET {killSwitch:false,source:off} → POST ON → orders 422 KILL_SWITCH, non-admin demo → 403 ROLE_REQUIRED → POST OFF; (j) resting LIMIT BUY stayed NEW through 3-4 cycles while ON, FILLED @820.85 first cycle after OFF. GTT expiry + notifyUser checked (CANCELED/EXPIRED + "GTT expired" row). GTT MIS BUY placed with 6-min expiry → expired CANCELED/EXPIRED + ORDER_CANCELLED notification.
- QA: `bun run lint` exit 0; `bunx tsc --noEmit | rg -v "examples/|skills/"` → 0 errors; dev.log clean through the whole curl pass (only a pre-existing EADDRINUSE line from server boot).

Deviations / notes for 15-b:
- estimateEntryPriceCents uses the limit price for GTT and STOP_LIMIT too (not just LIMIT) — preserves §7 "open GTT BUYs reserve at limit" and worst-case STOP_LIMIT pricing.
- Exposure-aware margin (requiredMarginForCents) added beyond the §8 letter: closing an opposite MIS position releases margin and reducing-only orders skip the funds check (route + inline fill + matcher re-check). Without it, a leveraged account (negative cash after a 5x MIS BUY) could never flatten and a CO short's STOP cover leg would be matcher-rejected — found live during test (b).
- Plain resting orders now also emit order-update WS on placement (AMO path already did; GTT/resting now match — additive, helps live tickets).
- Matcher BUY re-check is margin-based (was full-notional) for the same coherence reason; CNC stays ≈ full notional.
- Strategy entries are PARTIALLY_FILLED-safe: exit route cancels a still-open entry remainder defensively (sim fills entries all-at-once, so this is belt-and-braces).
- legKind "ENTRY" is only written on strategy orders; plain orders keep legKind null.

Stage Summary:
- Phase 4 backend is live: SEBI-style margin engine (CNC 1x / MIS 5x, open-order reservations, exposure-aware), CO/BO leg engine with OCO + manual exit, notification center (rows + WS + prune 100), runtime kill switch (SystemFlag + env override + 5s cache, matcher + placement enforce it), and direction-aware fills with shorts in portfolio math. All gates green; account left flat except 3 SBIN MIS + realized-PnL rows.
- API notes for 15-b: OrderDTO carries product/strategy/legKind/parentOrderId/targetCents — group legs under parent in the orders card; WS "notification" event payload {notification: NotificationDTO} for the bell; GET /api/margin powers the ticket margin line (availableCents already nets open-order reservations); exit button → POST /api/orders/{id}/exit → 201 {order, exitOrder}; legs are NOT user-cancellable (409 NOT_CANCELLABLE); filled strategy entries reject cancel with an exit hint; /api/admin/risk for the console (403 ROLE_REQUIRED for users).

---
Task ID: 15-b
Agent: full-stack-developer
Task: Phase 4 frontend — notification bell, CO/BO order ticket + CNC|MIS products + live margin line, orders leg grouping + Exit, SHORT positions, ADMIN risk console (against frozen src/lib/types.ts / ARCHITECTURE.md §8).

Work Log:
- Read worklog (1..15-foundation), ARCHITECTURE.md §5/§6a/§8, frozen types.ts, and full source of every touched file (instrument-detail, orders-card, positions-card, dashboard-view, site-header, use-quotes/use-orders/use-alerts, api-client, format, app-store) before coding. Backend (15-a) confirmed alive in dev.log (SystemFlag/matcher queries) but coded strictly against the contract, no endpoint testing beyond shape.
- src/hooks/use-notifications.ts (new): NOTIFICATIONS_KEY, useNotifications (GET /api/notifications → NotificationsResponse, 15s poll), useMarkNotificationsRead (POST /api/notifications/read { ids? | all }, invalidates; error toast), useDeleteNotification (DELETE ?id=, optimistic removal + rollback — unread count decremented only when the removed row was unread; hook provided per contract, no delete UI in the bell panel per spec).
- src/hooks/use-margin.ts (new): useMargin(request | null) — serializes MarginRequest to the §8a query string, debounces ~400ms on the serialized value (typing never spams the endpoint), GET /api/margin with keepPreviousData so the margin line never flickers; enabled only when the ticket is CO/BO/MIS (CNC passes null → endpoint never called).
- src/hooks/use-risk.ts (new): useRiskStatus(enabled=true) (GET /api/admin/risk → RiskStatusResponse, 15s poll, retry:false so a mid-session demotion 403 stays quiet), useToggleKillSwitch (POST { killSwitch } → success toast "Trading paused/resumed…" + invalidate RISK_KEY, error toast).
- src/hooks/use-orders.ts: added useExitOrder (POST /api/orders/{id}/exit, invalidates orders + portfolio, success toast "Exit order placed — market square-off incoming", error toast surfaces 409 NOTHING_TO_EXIT/NOT_CANCELLABLE). Existing useOrders/usePlaceOrder/useCancelOrder untouched.
- src/hooks/use-quotes.ts: same singleton socket gained a "notification" dispatcher (module-level notificationListeners + sock.on inside createSocket — ONE connection preserved); useUserEvents handles { notification } → toast.info(title, { description: body }) + invalidate NOTIFICATIONS_KEY. order-update/portfolio-nudge/alert handlers byte-identical.
- site-header.tsx: NotificationBell (authed users only) between ThemeToggle and UserMenu — ghost icon button 44px touch target, unread badge (bg-loss, white, max "9+") on the bell, Radix Popover w-80 sm:w-88 p-0: header row "Notifications" + "Mark all read" (disabled when unread=0); opening with unread>0 marks all read (per-row click marks { ids:[id] } for items arriving while open); rows = type icon + title (font-medium when unread) + body (line-clamp-2, min-w-0) + relativeTime + unread dot (terminal amber); unread rows bg-muted/40; icons: ORDER_FILLED ArrowUpRight profit · ORDER_REJECTED/CANCELLED X loss · LEG_CREATED GitBranch · OCO_COMPLETED Split · ALERT_TRIGGERED BellRing terminal · RISK ShieldAlert loss · other Info muted; empty "No notifications yet — order updates and alerts land here."; skeleton/error states; list max-h-96 thin-scroll.
- instrument-detail.tsx (order ticket): kind selector extended with "CO · Cover" / "BO · Bracket" (local TicketKind — payload keeps type=entry kind + strategy per §8b). Strategy panel (bordered sub-card): Market|Limit entry sub-toggle + static "MIS · 5x" badge, Est. entry line (limit or live LTP), Entry-limit (reuses limitPrice state, id ticket-strategy-limit), BO Target input, Stop trigger input with helpers ("Auto-exits at trigger if the trade goes against you." / "Target and stop-loss arm automatically after entry."), defaults derived GTT-style (SL = LTP ∓0.5% protective side, BO target = LTP ±1% profit side, ₹0.05 tick, live-tracking until edited, dirty flags reset on re-entering CO/BO). Validation = GTT band-hint pattern (amber mono role="note", blocks submit): SL on the correct side of est. entry (BUY below / SELL above), BO target beyond est. entry, SL/target/limit within ±20% of LTP (band range shown), all ≥ ₹0.05, qty ≥ 1 — each hint carries the est. entry reference. Product: CNC|MIS segmented control for non-strategy kinds with helper text ("Delivery — full money, sell needs holdings." / "Intraday — 5x margin, shorting allowed."); AMO never combines with strategies; payload gains product for plain kinds, { type: entryType, strategy, product:"MIS", stopPriceCents, targetCents?(BO), limitPriceCents?(LIMIT) } for strategies (timeInForce DAY unchanged; GTT/STOP payloads unchanged apart from product). Margin line: for CO/BO/MIS the dl shows "Required ₹X · Available ₹Y · {leverage}x" (required in loss color when required>available) + subtle "Fee est." row (feeEstimateCents); required>available also renders an amber hint (tailored copy: reduce qty for strategies / switch product for MIS) and blocks submit; CNC keeps Est. total / Cash available / Holding as today. React-compiler lint fix: margin-request builder extracted to a module-level pure buildMarginRequest() and handler memoization removed (useCallback/useMemo on derived-primitive deps tripped react-hooks/preserve-manual-memoization); zero behavior change.
- orders-card.tsx: flat feed grouped presentationally — legs (parentOrderId) whose parent is on the page render indented (↳ + pl-10) right under the entry; orphan legs render inline with a "leg of parent ·{id-suffix}" subtext. Leg mono badges: TARGET profit / STOP loss / EXIT terminal. Entry rows with strategy get a terminal CO/BO badge + subtext "SL ₹810.00 · T ₹835.00" (CO shows SL only). Exit button (outline, terminal accent, 44px) on FILLED/PARTIALLY_FILLED strategy entries → useExitOrder; legs show no actions; Cancel still only on NEW/PARTIALLY_FILLED/QUEUED entries. Non-strategy rows carry the product chip in the subtext line (merged with QUEUED "Releases ~HH:00" / GTT "Expires d MMM"). Status chips/partial labels/QUEUED dot untouched.
- positions-card.tsx: qty < 0 renders a loss-colored SHORT badge next to the symbol (qty text as-is, negative; signed P&L math already correct); tabular-nums on the qty line.
- risk-console-card.tsx (new, ADMIN only): Card with ShieldAlert "Risk console" + "RISK" corner tag; state row "Trading live" (pulsing profit dot) / "TRADING PAUSED" (loss styling); "Boot-time env override active" note when source==="env"; Switch wrapped in AlertDialog — pause confirm "Pause all trading? / Open orders stay resting; new orders are rejected." with red action, resume confirm symmetric; POST via useToggleKillSwitch → toast + invalidate (switch only flips on server truth). dashboard-view.tsx: RiskConsoleCard rendered only when user.role==="ADMIN" (below SecurityCard, outside Tabs); thin loss banner "Kill switch is ON — order placement is blocked by the risk desk." at the very top of the dashboard while killSwitch is ON (useRiskStatus polled only for admins via enabled gate).
- Design-system compliance: no blue/indigo anywhere (profit/loss/terminal tokens only); font-mono tabular-nums on all numerals; min-w-0/truncate on every flex child in new rows (bell rows, order rows, position rows, margin dd) so 390px never h-overflows; loading skeletons + error + empty states for notifications/orders/console; English-only; no new dependencies; shadcn primitives only (Popover, AlertDialog, Switch, Badge, Button, Input, Label, Card, Skeleton).
- Gates: bun run lint exit 0; bunx tsc --noEmit (filtered examples/|skills/) → 0 errors; curl http://127.0.0.1:3000/ → 200 (compile 249ms); dev.log shows no compile errors (top-of-file EADDRINUSE line is a stale pre-restart artifact, not from this task). Browser E2E deferred to 15-integration per plan.

Stage Summary:
- Phase 4 frontend is code-complete against the frozen contract: notifications (bell popover + WS toast + poll + optimistic-delete hook), CO/BO strategy ticket (entry-type sub-toggle, SL/target with live defaults and band/side validation, forced MIS), CNC|MIS product toggle with leverage helper text, live margin line via debounced /api/margin (required/available/leverage + fee estimate + insufficient-margin block), orders card with indented TARGET/STOP/EXIT legs + strategy SL/T subtext + market Exit, SHORT badges on negative positions, and an ADMIN risk console with confirmed kill-switch toggle + dashboard-wide pause banner. Backend routes from 15-a plug straight in — until they land the bell/console/margin show their retry/empty states by design (404/401 handled).
- Kind matrix in the ticket: MARKET (product toggle, AMO), LIMIT (limit input, product toggle, AMO), SL-M/SL (stop/stop+limit, product toggle), GTT (trigger/limit/expiry + band hint, product toggle), CO (Market|Limit + SL trigger + helper, MIS·5x chip, margin line), BO (Market|Limit + Target + SL trigger + helper, MIS·5x chip, margin line). Non-strategy payloads add product; strategy payloads send type=entryType + strategy + product:"MIS".
- Files: + use-notifications.ts, + use-margin.ts, + use-risk.ts, + risk-console-card.tsx; ~ use-orders.ts, use-quotes.ts, site-header.tsx, instrument-detail.tsx, orders-card.tsx, positions-card.tsx, views/dashboard-view.tsx. src/lib/types.ts, src/lib/trading/*, API routes untouched. Next: 15-integration browser E2E (bell flows, CO/BO lifecycle, exit, kill switch).
---
Task ID: 15-integration
Agent: Z.ai Code (lead)
Task: Phase 4 integration — full browser E2E of margin engine, CO/BO, notifications, risk console.

Work Log:
- Frontend (15-b) and backend (15-a) merged cleanly; lint exit 0; tsc 0 src errors. Note: the 15-a Task call hit a tool deadline AFTER completing all work (worklog + E2E were written) — no recovery needed.
- Browser E2E (agent-browser, demo + admin sessions):
  (a) CO via UI — RELIANCE ticket kind "CO · Cover": entry toggle Market/Limit, est-entry line, MIS·5x chip, SL trigger with live-tracked default; margin line rendered via <dl> (a11y snapshot hides it; verified via JS: Required ₹2,947.00 · Available ₹8,01,200.00 · 5x, fee ₹4.42). Submit → MARKET entry FILLED @ ₹2,961.60 + WS toasts ("Order filled", "Cover armed — stop-loss trigger ₹2870.00") + orders card shows entry row (CO badge, SL subtext, FILLED, Exit button) + indented "↳ SELL STOP 5 @ ₹2,870.00 NEW".
  (b) BO via UI — SBIN MARKET BUY 5, target ₹832.50, SL ₹803.90 → "Bracket armed" + TARGET(LIMIT SELL @832.50) + STOP legs. Ticket validation proven first: target below est market entry blocked submit (INVALID_LEG hint path).
  (c) Exit via UI — RELIANCE CO "Exit" → STOP leg CANCELED (MANUAL_EXIT) + MARKET EXIT leg FILLED @ ₹2,938.55 next sweep + toasts "Exit placed"/"Order cancelled"/"Order filled"/"Position exited"; RELIANCE position flat 50.
  (d) OCO — TITAN BO MARKET BUY 1 (API-placed, tight target): TARGET FILLED → sibling STOP CANCELED with rejectReason "OCO_CLOSED" (polled via DB; matcher hook proven).
  (e) Margin line exactness — BO ₹167.00 required (5x of ₹4,147 est total), MIS SELL ZOMATO ₹106.00 (₹530/5), CNC line unchanged.
  (f) MIS short — ZOMATO SELL 2 MIS (no holdings) FILLED @ ₹264.50; positions card renders "ZOMATO SHORT -2 × ₹264.50 avg" with live unrealized P&L; RELIANCE/SBIN longs unaffected.
  (g) Notifications — bell unread badge (2 → 9+ as events accrued), popover lists type-iconed rows (Bracket armed / Cover armed / Order filled ×N), "Mark all read" → demo unread 15 → 0 (DB-verified; admin's separate feed untouched). WS "notification" toasts fired live for every lifecycle event.
  (h) Risk console (admin@meridian.dev / MeridianAdmin1) — card visible only for ADMIN; toggle → AlertDialog "Pause all trading?" → POST → card "TRADING PAUSED", dashboard banner "Kill switch is ON", toast "Trading paused — kill switch is ON"; Resume via same dialog → "Trading live", banner gone. (Placement 422 KILL_SWITCH + matcher-skip proven by 15-a's curl pass.)
  (i) Mobile 390×844 — scrollWidth 390 = viewport (no overflow); KPI cards/bell/indices render cleanly (screenshot /tmp/meridian-mobile-p4.png).
  (j) Console: zero page errors. dev.log: only verbose prisma:query matcher lines (pre-existing dev logging), no runtime errors.
- Findings (cosmetic, non-blocking): (1) kill-switch ON toast uses success-green styling — risk actions could use loss/amber styling later; (2) strategy SL/target inputs live-track LTP until user edits — programmatic automation fills can race the tracked default (human typing unaffected); (3) the earlier "dialog not opening" was test-side: the a11y role=switch query matched the Security card's MFA switch; the Risk console trigger opens its AlertDialog correctly (screenshot /tmp/meridian-killswitch-on.png).
- ARCHITECTURE.md roadmap: M7–M9 Phase 4 row marked ✅ shipped (browser-verified); option chain explicitly deferred to Phase 5.
- Demo state left intentionally live: SBIN BO armed (TARGET/STOP resting, 5 qty @ 827.35) as a showcase; admin has 15 unread test notifications (harmless).

Stage Summary:
- Phase 4 (M7–M9 sandbox slice: margin engine CNC 1x/MIS 5x with exposure-aware reservations, CO/BO leg engine with OCO + manual exit, notification center with WS push, runtime kill-switch console) is browser-verified end-to-end and shippable. Money paths intact (paise, append-only ledger, fee engine), English-only throughout, lint + tsc clean.
- Next roadmap candidates (Phase 5 per ARCHITECTURE.md): option chain + Greeks (F&O paper trading), algo/API keys + paper trading API, admin console depth, UPI deposit polish, load profile, CI/CD + K8s manifests.
