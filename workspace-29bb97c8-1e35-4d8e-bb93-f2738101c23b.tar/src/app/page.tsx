"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { SiteFooter } from "@/components/meridian/site-footer";
import { SiteHeader } from "@/components/meridian/site-header";
import { SplashScreen } from "@/components/meridian/splash-screen";
import { AuthView } from "@/components/meridian/views/auth-view";
import { DashboardView } from "@/components/meridian/views/dashboard-view";
import { LandingView } from "@/components/meridian/views/landing-view";
import { OnboardingView } from "@/components/meridian/views/onboarding-view";
import { useSession } from "@/hooks/use-session";
import { useAppStore, type View } from "@/store/app-store";
import type { SessionUser } from "@/lib/types";

/**
 * MERIDIAN — single-route SPA.
 *
 * State machine (session query is the source of truth):
 *
 *   splash ── session loading
 *      │
 *      ├─ unauthenticated ──→ landing ⇄ auth (login | signup | mfa | otp)
 *      │
 *      └─ authenticated ──→ onboarding (wizard | review | approved)
 *                              │  (auto after APPROVED)
 *                              ▼
 *                           dashboard
 */
function deriveView(storeView: View, user: SessionUser | undefined): View {
  if (!user) {
    // Unauthenticated: honor the user's explicit choice between landing/auth.
    return storeView === "auth" ? "auth" : "landing";
  }
  // Authenticated: the session decides.
  if (user.onboardingDone && user.kycStatus === "APPROVED") {
    return "dashboard";
  }
  return "onboarding";
}

export default function Page() {
  const { data: session, isPending } = useSession();
  const storeView = useAppStore((s) => s.view);
  const reducedMotion = useReducedMotion();

  if (isPending) {
    return <SplashScreen />;
  }

  const user = session?.authenticated ? session.user : undefined;
  const view = deriveView(storeView, user);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:text-sm focus:text-primary-foreground"
      >
        Skip to content
      </a>

      <SiteHeader user={user ?? null} />

      <main id="main" className="flex flex-1 flex-col">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={view}
            initial={reducedMotion ? undefined : { opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={reducedMotion ? undefined : { opacity: 0, y: -10 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="flex flex-1 flex-col"
          >
            {view === "landing" && <LandingView />}
            {view === "auth" && <AuthView />}
            {view === "onboarding" && user && <OnboardingView user={user} />}
            {view === "dashboard" && user && <DashboardView user={user} />}
          </motion.div>
        </AnimatePresence>
      </main>

      <SiteFooter />
    </div>
  );
}
