import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { fail, ok } from "@/lib/api-utils";

/** Daily OHLCV bars for charting (90d). Public — contains no PII. */
export async function GET(req: NextRequest) {
  const symbol = req.nextUrl.searchParams.get("symbol")?.trim().toUpperCase() ?? "";
  if (!symbol) return fail(400, "symbol is required", "VALIDATION");
  const asset = await db.asset.findUnique({ where: { symbol }, select: { symbol: true } });
  if (!asset) return fail(404, "Unknown symbol.", "UNKNOWN_SYMBOL");

  const bars = await db.priceBar.findMany({
    where: { symbol },
    orderBy: { t: "asc" },
    select: { t: true, openCents: true, highCents: true, lowCents: true, closeCents: true, volume: true },
  });

  return ok({
    symbol,
    bars: bars.map((b) => ({
      t: b.t.toISOString(),
      openCents: b.openCents,
      highCents: b.highCents,
      lowCents: b.lowCents,
      closeCents: b.closeCents,
      volume: b.volume,
    })),
  });
}
