import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, requireAuth, isAuthed } from "@/lib/api-utils";
import { simFeeCents } from "@/lib/trading/engine";
import { estimateEntryPriceCents, LEVERAGE, marginForCents, sumReservedMarginCents } from "@/lib/trading/margin";
import { fetchLiveQuote } from "@/lib/market/quotes-client";
import type { MarginResponse, OrderProduct } from "@/lib/types";

const querySchema = z.object({
  symbol: z.string().trim().min(1).max(20).toUpperCase(),
  side: z.enum(["BUY", "SELL"]),
  type: z.enum(["MARKET", "LIMIT", "STOP", "STOP_LIMIT", "GTT"]),
  qty: z.coerce.number().int().min(1).max(100_000),
  product: z.enum(["CNC", "MIS"]).optional(),
  strategy: z.enum(["CO", "BO"]).optional(),
  limitPriceCents: z.coerce.number().int().positive().optional(),
  stopPriceCents: z.coerce.number().int().positive().optional(),
  targetCents: z.coerce.number().int().positive().optional(),
});

/**
 * Margin estimator (§8a) — pure read, never places anything. Session auth; no
 * origin guard needed for GET. Powers the live margin line on the order ticket.
 */
export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  const user = auth.user;

  const raw = req.nextUrl.searchParams;
  const parsed = querySchema.safeParse(Object.fromEntries(raw.entries()));
  if (!parsed.success) {
    const first = parsed.error.issues[0];
    return fail(400, first ? `${first.path.join(".") || "query"}: ${first.message}` : "Invalid query", "VALIDATION");
  }
  const q = parsed.data;

  const asset = await db.asset.findUnique({ where: { symbol: q.symbol } });
  if (!asset) return fail(404, "Unknown symbol.", "UNKNOWN_SYMBOL");

  // Strategy families are priced as MIS (intraday, 5x) — same rule as POST /api/orders.
  const product: OrderProduct = q.strategy ? "MIS" : (q.product ?? "CNC");

  // LIMIT-family orders estimate at their limit price (worst case); a LIMIT
  // without a price cannot be estimated.
  if ((q.type === "LIMIT" || q.type === "GTT" || q.type === "STOP_LIMIT") && !q.limitPriceCents) {
    return fail(400, `${q.type} orders require limitPriceCents`, "VALIDATION");
  }

  const quote = await fetchLiveQuote(asset.symbol);
  if (!quote) return fail(503, "Live price unavailable — please try again.", "FEED_UNAVAILABLE");

  const estPriceCents = estimateEntryPriceCents(q.type, q.side, q.limitPriceCents ?? null, quote.lastPriceCents);
  const notionalCents = q.qty * estPriceCents;

  const [wallet, openOrders] = await Promise.all([
    db.wallet.findUnique({ where: { userId: user.id } }),
    db.order.findMany({
      where: { userId: user.id, status: { in: ["NEW", "PARTIALLY_FILLED", "QUEUED"] } },
      select: { side: true, product: true, qty: true, filledQty: true, limitPriceCents: true },
    }),
  ]);

  const response: MarginResponse = {
    notionalCents,
    requiredCents: marginForCents(product, q.side, q.qty, estPriceCents),
    availableCents: (wallet?.cashAvailableCents ?? 0) - sumReservedMarginCents(openOrders),
    leverage: LEVERAGE[product],
    feeEstimateCents: simFeeCents(notionalCents),
  };
  return ok(response);
}
