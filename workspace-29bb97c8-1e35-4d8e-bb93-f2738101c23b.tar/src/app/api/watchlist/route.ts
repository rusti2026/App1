import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, parseBody, passesOriginGuard, requireAuth, isAuthed } from "@/lib/api-utils";
import { audit } from "@/lib/security/audit";

export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;

  const items = await db.watchlistItem.findMany({
    where: { userId: auth.user.id },
    orderBy: { createdAt: "desc" },
    select: { symbol: true, createdAt: true },
  });
  return ok({ items: items.map((i) => ({ symbol: i.symbol, addedAt: i.createdAt.toISOString() })) });
}

const postSchema = z.object({ symbol: z.string().trim().min(1).max(12) });

export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;

  const parsed = await parseBody(req, postSchema);
  if ("response" in parsed) return parsed.response;
  const symbol = parsed.data.symbol.toUpperCase();

  const asset = await db.asset.findUnique({ where: { symbol } });
  if (!asset) return fail(404, `Unknown symbol ${symbol}.`, "UNKNOWN_SYMBOL");

  const existing = await db.watchlistItem.findUnique({
    where: { userId_symbol: { userId: auth.user.id, symbol } },
  });
  if (!existing) {
    await db.watchlistItem.create({ data: { userId: auth.user.id, symbol } });
    await audit("WATCHLIST_ADD", req, { userId: auth.user.id, detail: symbol });
  }
  return ok({ symbol });
}

export async function DELETE(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;

  const symbol = req.nextUrl.searchParams.get("symbol")?.toUpperCase();
  if (!symbol) return fail(400, "symbol query param required.", "MISSING_SYMBOL");

  await db.watchlistItem.deleteMany({
    where: { userId: auth.user.id, symbol },
  });
  await audit("WATCHLIST_REMOVE", req, { userId: auth.user.id, detail: symbol });
  return ok({ ok: true });
}
