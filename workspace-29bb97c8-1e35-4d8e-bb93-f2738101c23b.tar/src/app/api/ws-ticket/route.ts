import { NextRequest } from "next/server";
import { ok, passesOriginGuard, fail, requireAuth, isAuthed } from "@/lib/api-utils";
import { signToken } from "@/lib/security/jwt";

const WS_TICKET_TTL_SECONDS = 120;

/** Short-lived ticket so the socket.io gateway can join the user's room without exposing the session cookie. */
export async function GET(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  const { token } = signToken(auth.user.id, "ws", WS_TICKET_TTL_SECONDS);
  return ok({ ticket: token });
}
