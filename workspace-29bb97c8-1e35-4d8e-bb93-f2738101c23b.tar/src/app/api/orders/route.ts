import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, parseBody, passesOriginGuard, rateKey, requireAuth, isAuthed } from "@/lib/api-utils";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";
import { assessRisk, marketFillPrice, nextSessionOpen, PRICE_BAND } from "@/lib/trading/risk";
import { executeFill, simFeeCents } from "@/lib/trading/engine";
import { estimateEntryPriceCents, requiredMarginForCents, sumReservedMarginCents } from "@/lib/trading/margin";
import { fetchLiveQuote } from "@/lib/market/quotes-client";
import { emitToUser, notifyUser } from "@/lib/trading/notify";
import { getKillSwitchState } from "@/lib/trading/kill-switch";
import { onEntryFilled } from "@/lib/trading/legs";
import { ensureMatcher } from "@/lib/trading/matcher";
import { toOrderDTO } from "@/lib/trading/dto";
import type { OrderProduct, PlaceOrderResponse } from "@/lib/types";

// Start the simulated exchange matcher on first import (idempotent via globalThis).
ensureMatcher();

const inr = (cents: number): string => `₹${(cents / 100).toFixed(2)}`;

const bodySchema = z
  .object({
    symbol: z.string().trim().min(1).max(20).toUpperCase(),
    side: z.enum(["BUY", "SELL"]),
    type: z.enum(["MARKET", "LIMIT", "STOP", "STOP_LIMIT", "GTT"]),
    qty: z.number().int().min(1).max(100_000),
    /** CNC (delivery, 1x) | MIS (intraday, 5x margin). Default CNC. */
    product: z.enum(["CNC", "MIS"]).optional(),
    /** CO/BO strategy families — entry type must be MARKET or LIMIT. */
    strategy: z.enum(["CO", "BO"]).optional(),
    /** BO only: target exit price (profit leg). */
    targetCents: z.number().int().positive().optional(),
    limitPriceCents: z.number().int().positive().optional(),
    stopPriceCents: z.number().int().positive().optional(),
    timeInForce: z.enum(["DAY", "GTC"]).optional(),
    /** GTT only: cancel if unfilled by this ISO time. */
    expiresAt: z.string().datetime().optional(),
    /** After-market order: queue until the next simulated session open. */
    amo: z.boolean().optional(),
  })
  .superRefine((v, ctx) => {
    if (v.type === "LIMIT" && !v.limitPriceCents) {
      ctx.addIssue({ code: "custom", message: "LIMIT orders require limitPriceCents", path: ["limitPriceCents"] });
    }
    if (v.type === "STOP" && !v.stopPriceCents) {
      ctx.addIssue({ code: "custom", message: "STOP orders require stopPriceCents", path: ["stopPriceCents"] });
    }
    if (v.type === "STOP_LIMIT" && (!v.stopPriceCents || !v.limitPriceCents)) {
      ctx.addIssue({ code: "custom", message: "STOP_LIMIT orders require stopPriceCents and limitPriceCents", path: ["stopPriceCents"] });
    }
    if (v.type === "GTT" && (!v.stopPriceCents || !v.limitPriceCents)) {
      ctx.addIssue({
        code: "custom",
        message: "GTT orders require stopPriceCents (trigger) and limitPriceCents",
        path: ["stopPriceCents"],
      });
    }
    if (v.type === "GTT" && !v.expiresAt) {
      ctx.addIssue({ code: "custom", message: "GTT orders require expiresAt", path: ["expiresAt"] });
    }
    if (v.expiresAt) {
      const t = new Date(v.expiresAt).getTime();
      const now = Date.now();
      if (!Number.isFinite(t) || t < now + 5 * 60_000 || t > now + 365 * 24 * 60 * 60_000) {
        ctx.addIssue({
          code: "custom",
          message: "expiresAt must be between 5 minutes and 365 days from now",
          path: ["expiresAt"],
        });
      }
    }
    if (v.amo && v.type !== "MARKET" && v.type !== "LIMIT") {
      ctx.addIssue({ code: "custom", message: "AMO is only allowed with MARKET or LIMIT orders", path: ["amo"] });
    }
    if (v.amo && v.type === "GTT") {
      ctx.addIssue({ code: "custom", message: "GTT orders cannot be combined with AMO", path: ["amo"] });
    }
    // ── Strategy (CO/BO) combos — §8b ──
    if (v.strategy) {
      if (v.type !== "MARKET" && v.type !== "LIMIT") {
        ctx.addIssue({
          code: "custom",
          message: "Cover/Bracket entries must be MARKET or LIMIT orders",
          path: ["strategy"],
        });
      }
      if (v.strategy === "CO" && !v.stopPriceCents) {
        ctx.addIssue({ code: "custom", message: "Cover (CO) orders require stopPriceCents (SL trigger)", path: ["stopPriceCents"] });
      }
      if (v.strategy === "BO" && (!v.stopPriceCents || !v.targetCents)) {
        ctx.addIssue({
          code: "custom",
          message: "Bracket (BO) orders require stopPriceCents (SL trigger) and targetCents",
          path: ["targetCents"],
        });
      }
      if (v.expiresAt) {
        ctx.addIssue({ code: "custom", message: "GTT cannot be combined with Cover/Bracket orders", path: ["expiresAt"] });
      }
      if (v.amo) {
        ctx.addIssue({ code: "custom", message: "AMO cannot be combined with Cover/Bracket orders", path: ["amo"] });
      }
    }
  });

export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  const user = auth.user;

  if (!rateLimit(rateKey(req, "orders", user.id), 30, WINDOW.MIN_1)) {
    return fail(429, "Too many orders in a minute.", "RATE_LIMITED");
  }

  const parsed = await parseBody(req, bodySchema);
  if ("response" in parsed) return parsed.response;
  const input = parsed.data;

  // Strategy families are intraday (MIS) — explicit CNC with CO/BO is rejected
  // (§8b); a strategy without an explicit product is forced to MIS below.
  if (input.strategy && input.product === "CNC") {
    return fail(422, "Cover/Bracket orders are intraday (MIS) only.", "INVALID_PRODUCT");
  }
  const product: OrderProduct = input.strategy ? "MIS" : (input.product ?? "CNC");

  // KYC gate — trading only for approved accounts.
  const kyc = await db.kycProfile.findUnique({ where: { userId: user.id } });
  if (kyc?.status !== "APPROVED") {
    return fail(403, "Complete KYC before placing orders.", "KYC_REQUIRED");
  }

  const asset = await db.asset.findUnique({ where: { symbol: input.symbol } });
  if (!asset) return fail(404, "Unknown symbol.", "UNKNOWN_SYMBOL");

  const quote = await fetchLiveQuote(asset.symbol);
  const [position, wallet, openOrders] = await Promise.all([
    db.position.findUnique({ where: { userId_symbol: { userId: user.id, symbol: asset.symbol } } }),
    db.wallet.findUnique({ where: { userId: user.id } }),
    // ALL open orders (any side / type / product) reserve margin against cash —
    // short SELLs included (§8a). Estimation inside margin.ts.
    db.order.findMany({
      where: { userId: user.id, status: { in: ["NEW", "PARTIALLY_FILLED", "QUEUED"] } },
      select: { side: true, product: true, qty: true, filledQty: true, limitPriceCents: true },
    }),
  ]);

  const ks = await getKillSwitchState();
  const decision = assessRisk({
    side: input.side,
    type: input.type,
    qty: input.qty,
    product,
    strategy: input.strategy ?? null,
    targetCents: input.targetCents ?? null,
    limitPriceCents: input.limitPriceCents ?? null,
    stopPriceCents: input.stopPriceCents ?? null,
    assetType: asset.type,
    quote: quote ? { lastPriceCents: quote.lastPriceCents } : null,
    cashAvailableCents: wallet?.cashAvailableCents ?? 0,
    positionQty: position?.qty ?? 0,
    openReservedMarginCents: sumReservedMarginCents(openOrders),
    killSwitchOn: ks.on,
    marketOpen: true, // simulated exchange runs continuously
  });
  if (!decision.ok) {
    await audit("ORDER_REJECTED", req, { userId: user.id, detail: `${decision.code}:${input.symbol}` });
    await notifyUser(user.id, {
      type: "ORDER_REJECTED",
      title: "Order rejected",
      body: `${input.side} ${input.qty} ${input.symbol} — ${decision.message}`,
      refType: "ORDER",
    });
    return fail(422, decision.message, decision.code);
  }
  if (!wallet) return fail(500, "Wallet missing — contact support.", "NO_WALLET");

  // Strategy leg sanity (§8b): SL on the correct side of the estimated entry,
  // BO target beyond it, both inside the ±20% band of LTP → else INVALID_LEG.
  if (input.strategy && quote) {
    const ltp = quote.lastPriceCents;
    const estEntry = estimateEntryPriceCents(input.type, input.side, input.limitPriceCents ?? null, ltp);
    const legIssues: string[] = [];
    const sl = input.stopPriceCents ?? null;
    const tgt = input.strategy === "BO" ? (input.targetCents ?? null) : null;

    if (sl != null) {
      const slOk = input.side === "BUY" ? sl < estEntry : sl > estEntry;
      if (!slOk) {
        legIssues.push(
          input.side === "BUY"
            ? `Stop-loss trigger ${inr(sl)} must be below the estimated entry ${inr(estEntry)} for a BUY.`
            : `Stop-loss trigger ${inr(sl)} must be above the estimated entry ${inr(estEntry)} for a SELL.`
        );
      } else if (Math.abs(sl - ltp) / ltp > PRICE_BAND) {
        legIssues.push(`Stop-loss trigger ${inr(sl)} is more than 20% away from the last traded price.`);
      }
    }
    if (tgt != null) {
      const tgtOk = input.side === "BUY" ? tgt > estEntry : tgt < estEntry;
      if (!tgtOk) {
        legIssues.push(
          input.side === "BUY"
            ? `Target ${inr(tgt)} must be above the estimated entry ${inr(estEntry)} for a BUY bracket.`
            : `Target ${inr(tgt)} must be below the estimated entry ${inr(estEntry)} for a SELL bracket.`
        );
      } else if (Math.abs(tgt - ltp) / ltp > PRICE_BAND) {
        legIssues.push(`Target ${inr(tgt)} is more than 20% away from the last traded price.`);
      }
    }
    if (legIssues.length > 0) {
      await audit("ORDER_REJECTED", req, { userId: user.id, detail: `INVALID_LEG:${input.symbol}` });
      await notifyUser(user.id, {
        type: "ORDER_REJECTED",
        title: "Order rejected",
        body: `${input.side} ${input.qty} ${input.symbol} — ${legIssues.join(" ")}`,
        refType: "ORDER",
      });
      return fail(422, legIssues.join(" "), "INVALID_LEG");
    }
  }

  const entryFields = {
    product,
    strategy: input.strategy ?? null,
    legKind: input.strategy ? ("ENTRY" as const) : null,
    // targetCents is a BO-only field; CO entries do not carry a target.
    targetCents: input.strategy === "BO" ? (input.targetCents ?? null) : null,
  };

  // AMO — queue until the next simulated session open; the matcher releases it.
  if (input.amo) {
    const order = await db.order.create({
      data: {
        userId: user.id,
        symbol: asset.symbol,
        side: input.side,
        type: input.type,
        qty: input.qty,
        limitPriceCents: input.limitPriceCents ?? null,
        stopPriceCents: input.stopPriceCents ?? null,
        timeInForce: input.timeInForce ?? "DAY",
        status: "QUEUED",
        activateAt: nextSessionOpen(new Date()),
        ...entryFields,
      },
    });
    await audit("ORDER_PLACED", req, {
      userId: user.id,
      detail: `AMO ${input.type} ${input.side} ${input.qty} ${asset.symbol}`,
    });
    await emitToUser(user.id, "order-update", { order: toOrderDTO(order) });
    await notifyUser(user.id, {
      type: "ORDER_PLACED",
      title: "AMO queued",
      body: `${input.side} ${input.qty} ${asset.symbol} will release at the next session open.`,
      refType: "ORDER",
      refId: order.id,
    });
    return ok({ order: toOrderDTO(order) }, 201);
  }

  // GTT — resting order with a trigger (stop) + limit + expiry, matched every 2 s.
  if (input.type === "GTT") {
    const order = await db.order.create({
      data: {
        userId: user.id,
        symbol: asset.symbol,
        side: input.side,
        type: input.type,
        qty: input.qty,
        limitPriceCents: input.limitPriceCents ?? null,
        stopPriceCents: input.stopPriceCents ?? null,
        timeInForce: input.timeInForce ?? "DAY",
        status: "NEW",
        expiresAt: input.expiresAt ? new Date(input.expiresAt) : null,
        ...entryFields,
      },
    });
    await audit("ORDER_PLACED", req, {
      userId: user.id,
      detail: `GTT ${input.side} ${input.qty} ${asset.symbol} trigger=${input.stopPriceCents} limit=${input.limitPriceCents}`,
    });
    await notifyUser(user.id, {
      type: "ORDER_PLACED",
      title: "GTT armed",
      body: `${input.side} ${input.qty} ${asset.symbol} will trigger at ${inr(input.stopPriceCents ?? 0)}.`,
      refType: "ORDER",
      refId: order.id,
    });
    return ok({ order: toOrderDTO(order) }, 201);
  }

  // Create the order row first (audit trail), then fill or rest it.
  let order = await db.order.create({
    data: {
      userId: user.id,
      symbol: asset.symbol,
      side: input.side,
      type: input.type,
      qty: input.qty,
      limitPriceCents: input.limitPriceCents ?? null,
      stopPriceCents: input.stopPriceCents ?? null,
      timeInForce: input.timeInForce ?? "DAY",
      status: "NEW",
      ...entryFields,
    },
  });

  if (input.type === "MARKET" && quote) {
    const price = marketFillPrice(input.side, quote.lastPriceCents);
    const fee = simFeeCents(price * input.qty);
    // Margin gate for the actual fill (leverage- and exposure-aware): a pure
    // close/cover releases margin and always passes; new exposure needs its
    // margin plus the fee. CNC keeps full-notional semantics (leverage 1); MIS
    // lets the wallet fund the rest (the ledger debits the full notional —
    // intraday borrowing analog, equity stays coherent).
    const { requiredCents: reqNow, reducingOnly } = requiredMarginForCents(
      product,
      input.side,
      input.qty,
      position?.qty ?? 0,
      price
    );
    const need = reqNow + (input.side === "BUY" ? fee : 0);
    if (!reducingOnly && input.side === "BUY" && wallet.cashAvailableCents < need) {
      await db.order.update({ where: { id: order.id }, data: { status: "REJECTED", rejectReason: "INSUFFICIENT_FUNDS" } });
      await audit("ORDER_REJECTED", req, { userId: user.id, detail: `INSUFFICIENT_FUNDS:${asset.symbol}` });
      await notifyUser(user.id, {
        type: "ORDER_REJECTED",
        title: "Order rejected",
        body: `${input.side} ${input.qty} ${asset.symbol} — not enough ${product === "MIS" ? "margin" : "buying power"} at fill time.`,
        refType: "ORDER",
        refId: order.id,
      });
      return fail(422, "Not enough buying power for this order.", "INSUFFICIENT_FUNDS");
    }
    try {
      const result = await db.$transaction((tx) => executeFill(tx, order, input.qty, price, fee));
      order = result.order;
      await audit("ORDER_FILLED", req, {
        userId: user.id,
        detail: `${input.side} ${input.qty} ${asset.symbol} @ ₹${(price / 100).toFixed(2)}`,
      });
      await emitToUser(user.id, "order-update", { order: toOrderDTO(order) });
      await emitToUser(user.id, "portfolio-nudge", { ts: Date.now() });
      await notifyUser(user.id, {
        type: "ORDER_FILLED",
        title: "Order filled",
        body: `${input.side} ${input.qty} ${asset.symbol} @ ${inr(price)}.`,
        refType: "ORDER",
        refId: order.id,
      });
      // Strategy entry filled inline → arm its legs (CO/BO) before responding.
      if (order.strategy) await onEntryFilled(order);
      const body: PlaceOrderResponse = {
        order: toOrderDTO(order),
        fill: { qty: input.qty, priceCents: price, feeCents: fee },
      };
      return ok(body, 201);
    } catch (e) {
      console.error("[orders] market fill failed:", e);
      await db.order
        .update({ where: { id: order.id }, data: { status: "REJECTED", rejectReason: "EXECUTION_ERROR" } })
        .catch(() => undefined);
      return fail(500, "Order could not be executed — please retry.", "EXECUTION_ERROR");
    }
  }

  await audit("ORDER_PLACED", req, {
    userId: user.id,
    detail: `${input.type} ${input.side} ${input.qty} ${asset.symbol}`,
  });
  await emitToUser(user.id, "order-update", { order: toOrderDTO(order) });
  await notifyUser(user.id, {
    type: "ORDER_PLACED",
    title: "Order placed",
    body: `${input.type} ${input.side} ${input.qty} ${asset.symbol} is resting on the book.`,
    refType: "ORDER",
    refId: order.id,
  });
  return ok({ order: toOrderDTO(order) }, 201);
}

export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  const scope = req.nextUrl.searchParams.get("scope") === "OPEN" ? "OPEN" : "ALL";
  const orders = await db.order.findMany({
    where: {
      userId: auth.user.id,
      ...(scope === "OPEN" ? { status: { in: ["QUEUED", "NEW", "PARTIALLY_FILLED"] } } : {}),
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
  return ok({ orders: orders.map(toOrderDTO) });
}
