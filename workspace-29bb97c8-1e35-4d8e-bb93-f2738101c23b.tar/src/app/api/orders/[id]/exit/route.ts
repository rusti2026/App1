import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { fail, ok, passesOriginGuard, rateKey, requireAuth, isAuthed } from "@/lib/api-utils";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";
import { emitToUser, notifyUser } from "@/lib/trading/notify";
import { toOrderDTO } from "@/lib/trading/dto";
import type { OrderSide } from "@/lib/types";

/**
 * Manual exit for CO/BO strategy entries (§8b): cancels the still-open legs,
 * cancels any still-open entry remainder, and places a MARKET EXIT leg for the
 * unfilled-by-legs quantity — the matcher's MARKET sweep fills it next cycle.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  const user = auth.user;

  if (!rateLimit(rateKey(req, "orders", user.id), 30, WINDOW.MIN_1)) {
    return fail(429, "Too many order actions in a minute.", "RATE_LIMITED");
  }

  const { id } = await params;
  const entry = await db.order.findFirst({ where: { id, userId: user.id } });
  if (!entry) return fail(404, "Order not found.", "ORDER_NOT_FOUND");

  // Only strategy ENTRY orders are exitable (legs are engine-managed, plain
  // orders are just cancelled).
  if (entry.legKind !== "ENTRY" || !entry.strategy) {
    return fail(409, "Only Cover/Bracket entry orders can be exited.", "NOT_EXITABLE");
  }
  if (entry.filledQty <= 0) {
    return fail(409, "Nothing to exit — the entry order has no filled quantity yet.", "NOTHING_TO_EXIT");
  }

  // Quantity already closed by filled (or partially filled) legs.
  const legs = await db.order.findMany({
    where: { parentOrderId: entry.id, legKind: { in: ["TARGET", "STOP", "EXIT"] } },
  });
  const closedQty = legs
    .filter((l) => l.status === "FILLED" || l.status === "PARTIALLY_FILLED")
    .reduce((sum, l) => sum + l.filledQty, 0);
  const exitQty = entry.filledQty - closedQty;
  if (exitQty <= 0) {
    return fail(409, "Nothing to exit — the strategy legs already closed the position.", "NOTHING_TO_EXIT");
  }

  const exitSide: OrderSide = entry.side === "BUY" ? "SELL" : "BUY";

  // Cancel still-open legs (OCO arms down) — rejectReason MANUAL_EXIT.
  const openLegs = legs.filter((l) => l.status === "NEW" || l.status === "PARTIALLY_FILLED");
  for (const leg of openLegs) {
    const canceled = await db.order.update({
      where: { id: leg.id },
      data: { status: "CANCELED", rejectReason: "MANUAL_EXIT" },
    });
    await emitToUser(user.id, "order-update", { order: toOrderDTO(canceled) });
  }

  // Defensive: if the entry is still working (possible only with a partial
  // fill), cancel the remainder so nothing can add exposure after the exit.
  let current = entry;
  if (entry.status === "QUEUED" || entry.status === "NEW" || entry.status === "PARTIALLY_FILLED") {
    current = await db.order.update({
      where: { id: entry.id },
      data: { status: "CANCELED", rejectReason: "MANUAL_EXIT" },
    });
    await emitToUser(user.id, "order-update", { order: toOrderDTO(current) });
  }

  // MARKET EXIT leg — the matcher sweep fills it on the next cycle.
  const exitLeg = await db.order.create({
    data: {
      userId: user.id,
      symbol: entry.symbol,
      side: exitSide,
      type: "MARKET",
      qty: exitQty,
      product: "MIS",
      legKind: "EXIT",
      parentOrderId: entry.id,
      timeInForce: "DAY",
      status: "NEW",
    },
  });

  await audit("ORDER_EXITED", req, {
    userId: user.id,
    detail: `manual exit ${entry.strategy} ${entry.side} ${exitQty} ${entry.symbol} (entry ${entry.id}, exit ${exitLeg.id}, ${openLegs.length} leg(s) cancelled)`,
  });
  await notifyUser(user.id, {
    type: "ORDER_EXITED",
    title: "Exit placed",
    body: `Market exit for ${exitQty} ${entry.symbol} sent — fills on the next exchange sweep.`,
    refType: "ORDER",
    refId: exitLeg.id,
  });

  return ok({ order: toOrderDTO(current), exitOrder: toOrderDTO(exitLeg) }, 201);
}
