import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { fail, ok, passesOriginGuard, requireAuth, isAuthed } from "@/lib/api-utils";
import { audit } from "@/lib/security/audit";
import { emitToUser, notifyUser } from "@/lib/trading/notify";
import { toOrderDTO } from "@/lib/trading/dto";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  const { id } = await params;

  const order = await db.order.findFirst({ where: { id, userId: auth.user.id } });
  if (!order) return fail(404, "Order not found.", "ORDER_NOT_FOUND");

  // CO/BO legs (TARGET/STOP/EXIT) are managed by the engine — the user exits
  // via the parent ENTRY order instead.
  if (order.legKind && order.legKind !== "ENTRY") {
    return fail(409, "Strategy legs cannot be cancelled directly — use exit on the parent order.", "NOT_CANCELLABLE");
  }
  // A filled strategy entry has an armed position — cancellation no longer
  // applies, the user exits through POST /api/orders/{id}/exit.
  if (order.strategy && order.status === "FILLED") {
    return fail(409, "Order filled — use exit to close the position.", "NOT_CANCELLABLE");
  }
  // QUEUED (AMO) orders stay cancellable until the matcher releases them.
  if (order.status !== "QUEUED" && order.status !== "NEW" && order.status !== "PARTIALLY_FILLED") {
    return fail(409, `Order is ${order.status} and can no longer be cancelled.`, "NOT_CANCELLABLE");
  }

  const updated = await db.order.update({ where: { id: order.id }, data: { status: "CANCELED" } });
  await audit("ORDER_CANCELLED", req, { userId: auth.user.id, detail: order.id });
  await emitToUser(auth.user.id, "order-update", { order: toOrderDTO(updated) });
  await notifyUser(auth.user.id, {
    type: "ORDER_CANCELLED",
    title: "Order cancelled",
    body: `${order.side} ${order.qty} ${order.symbol} was cancelled.`,
    refType: "ORDER",
    refId: order.id,
  });
  return ok({ order: toOrderDTO(updated) });
}
