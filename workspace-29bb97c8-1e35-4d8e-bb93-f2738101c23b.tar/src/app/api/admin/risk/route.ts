import { NextRequest } from "next/server";
import { z } from "zod";
import { fail, ok, parseBody, passesOriginGuard, rateKey, requireAdmin, isAuthed } from "@/lib/api-utils";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";
import { getKillSwitchState, setKillSwitch } from "@/lib/trading/kill-switch";
import { notifyUser } from "@/lib/trading/notify";

const bodySchema = z.object({ killSwitch: z.boolean() });

/** Risk console status (§8d) — ADMIN only. */
export async function GET(req: NextRequest) {
  const auth = await requireAdmin(req);
  if (!isAuthed(auth)) return auth;
  const state = await getKillSwitchState();
  return ok({ killSwitch: state.on, source: state.source });
}

/** Runtime kill-switch toggle (§8d) — ADMIN only, audited, notified. */
export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAdmin(req);
  if (!isAuthed(auth)) return auth;
  const admin = auth.user;

  if (!rateLimit(rateKey(req, "admin-risk", admin.id), 30, WINDOW.MIN_1)) {
    return fail(429, "Too many actions in a minute.", "RATE_LIMITED");
  }

  const parsed = await parseBody(req, bodySchema);
  if ("response" in parsed) return parsed.response;
  const { killSwitch } = parsed.data;

  await setKillSwitch(killSwitch);
  await audit(killSwitch ? "RISK_KILL_SWITCH_ON" : "RISK_KILL_SWITCH_OFF", req, {
    userId: admin.id,
    detail: `TRADING_KILL_SWITCH -> ${killSwitch ? "1" : "0"} (runtime toggle)`,
  });
  await notifyUser(admin.id, {
    type: "RISK",
    title: killSwitch ? "Kill switch ON" : "Kill switch OFF",
    body: killSwitch
      ? "Trading is paused — all order actions and matcher fills are suspended."
      : "Trading resumed — order flow and the exchange matcher are live again.",
    refType: "SYSTEM",
  });

  return ok({ killSwitch });
}
