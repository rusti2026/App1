import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { fail, ok, passesOriginGuard, rateKey, requireAuth, isAuthed } from "@/lib/api-utils";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { toNotificationDTO } from "@/lib/trading/dto";

/** Notification feed (§8c) — newest first, unread count for the bell badge. */
export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;

  const limitRaw = Number(req.nextUrl.searchParams.get("limit") ?? "30");
  const limit = Number.isFinite(limitRaw) ? Math.min(100, Math.max(1, Math.floor(limitRaw))) : 30;

  const [notifications, unread] = await Promise.all([
    db.notification.findMany({
      where: { userId: auth.user.id },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: limit,
    }),
    db.notification.count({ where: { userId: auth.user.id, readAt: null } }),
  ]);

  return ok({ notifications: notifications.map(toNotificationDTO), unread });
}

/** Delete notifications: ?id=<id> for one own row, ?all=true to clear the feed. */
export async function DELETE(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;

  if (!rateLimit(rateKey(req, "notifications", auth.user.id), 30, WINDOW.MIN_1)) {
    return fail(429, "Too many actions in a minute.", "RATE_LIMITED");
  }

  const id = req.nextUrl.searchParams.get("id");
  const all = req.nextUrl.searchParams.get("all") === "true";
  if (!id && !all) return fail(400, "Provide ?id=<notificationId> or ?all=true.", "VALIDATION");

  if (all) {
    await db.notification.deleteMany({ where: { userId: auth.user.id } });
  } else if (id) {
    // Owner-scoped delete — ids belonging to other users are silently ignored.
    await db.notification.deleteMany({ where: { id, userId: auth.user.id } });
  }
  return ok({ ok: true });
}
