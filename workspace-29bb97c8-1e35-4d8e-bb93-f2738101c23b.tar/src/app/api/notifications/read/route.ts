import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, parseBody, passesOriginGuard, rateKey, requireAuth, isAuthed } from "@/lib/api-utils";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";

const bodySchema = z
  .object({
    ids: z.array(z.string().min(1)).max(200).optional(),
    all: z.boolean().optional(),
  })
  .refine((v) => v.all === true || (Array.isArray(v.ids) && v.ids.length > 0), {
    message: "Provide ids (array) or all: true",
  });

/** Mark notifications read (§8c): readAt = now for the given ids or all unread. */
export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;

  if (!rateLimit(rateKey(req, "notifications", auth.user.id), 30, WINDOW.MIN_1)) {
    return fail(429, "Too many actions in a minute.", "RATE_LIMITED");
  }

  const parsed = await parseBody(req, bodySchema);
  if ("response" in parsed) return parsed.response;
  const { ids, all } = parsed.data;

  const where = all
    ? { userId: auth.user.id, readAt: null }
    : { userId: auth.user.id, id: { in: ids ?? [] }, readAt: null };
  await db.notification.updateMany({ where, data: { readAt: new Date() } });

  const unread = await db.notification.count({ where: { userId: auth.user.id, readAt: null } });
  return ok({ ok: true, unread });
}
