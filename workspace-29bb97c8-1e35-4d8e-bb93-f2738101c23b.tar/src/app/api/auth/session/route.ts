import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok } from "@/lib/api-utils";
import { settleKycIfDue, toSessionUser } from "@/lib/security/session";

export async function GET(req: NextRequest) {
  const auth = await requireAuthSafe(req);
  if (!auth) return ok({ authenticated: false });
  await settleKycIfDue(auth.id);
  const withKyc = await db.user.findUnique({
    where: { id: auth.id },
    include: { kycProfile: true },
  });
  if (!withKyc || withKyc.status !== "ACTIVE") return ok({ authenticated: false });
  return ok({ authenticated: true, user: toSessionUser(withKyc) });
}

/** Session check for view routing — soft-fails to `authenticated: false`. */
async function requireAuthSafe(req: NextRequest) {
  const { requireAuth, isAuthed } = await import("@/lib/api-utils");
  const auth = await requireAuth(req);
  return isAuthed(auth) ? auth.user : null;
}
