import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, parseBody, passesOriginGuard } from "@/lib/api-utils";
import { verifyToken } from "@/lib/security/jwt";
import { verifyTotp } from "@/lib/security/totp";
import { decryptField } from "@/lib/security/crypto-field";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";
import { createSession } from "@/lib/security/session";

const bodySchema = z.object({
  tempToken: z.string().min(10),
  code: z.string().min(6).max(8),
});

export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");

  const parsed = await parseBody(req, bodySchema);
  if ("response" in parsed) return parsed.response;
  const { tempToken, code } = parsed.data;

  const payload = verifyToken(tempToken, "mfa");
  if (!payload) {
    return fail(401, "This MFA challenge expired. Please sign in again.", "CHALLENGE_EXPIRED");
  }
  if (!rateLimit(`mfa:attempt:${payload.sub}`, 10, WINDOW.MIN_15)) {
    return fail(429, "Too many MFA attempts. Try again shortly.", "RATE_LIMITED");
  }

  const user = await db.user.findUnique({ where: { id: payload.sub } });
  if (!user || !user.mfaEnabled || !user.mfaSecretEnc) {
    return fail(401, "MFA is not configured for this account.", "MFA_NOT_ENABLED");
  }

  const secret = decryptField(user.mfaSecretEnc);
  if (!secret || !verifyTotp(secret, code)) {
    await audit("LOGIN_MFA_FAILED", req, { userId: user.id });
    return fail(401, "Invalid authenticator code.", "BAD_MFA_CODE");
  }

  await audit("LOGIN_MFA_OK", req, { userId: user.id });
  return createSession(user, req);
}
