import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, parseBody, passesOriginGuard, rateKey } from "@/lib/api-utils";
import { verifyPassword } from "@/lib/security/hash";
import { signToken, MFA_CHALLENGE_TTL_SECONDS } from "@/lib/security/jwt";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";
import { createSession } from "@/lib/security/session";

const bodySchema = z.object({
  email: z.string().min(3).max(254),
  password: z.string().min(1).max(128),
});

export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");

  const parsed = await parseBody(req, bodySchema);
  if ("response" in parsed) return parsed.response;
  const email = parsed.data.email.toLowerCase().trim();
  const { password } = parsed.data;

  // Two throttle layers: per-IP burst, per-account targeted attacks.
  if (
    !rateLimit(rateKey(req, "login:ip"), 20, WINDOW.MIN_15) ||
    !rateLimit(`login:acct:${email}`, 8, WINDOW.MIN_15)
  ) {
    return fail(429, "Too many login attempts. Try again in a few minutes.", "RATE_LIMITED");
  }

  const user = await db.user.findUnique({ where: { email } });

  if (!user || !verifyPassword(password, user.passwordHash)) {
    await audit("LOGIN_FAILED", req, { userId: user?.id ?? null, detail: email });
    return fail(401, "Invalid email or password.", "BAD_CREDENTIALS");
  }
  if (user.status !== "ACTIVE") {
    return fail(403, "This account is locked. Contact support.", "ACCOUNT_LOCKED");
  }

  // MFA gate: issue a short-lived, purpose-scoped challenge token (stateless).
  if (user.mfaEnabled) {
    const { token } = signToken(user.id, "mfa", MFA_CHALLENGE_TTL_SECONDS);
    return ok({ status: "mfa_required", tempToken: token });
  }

  await audit("LOGIN_OK", req, { userId: user.id });
  return createSession(user, req);
}
