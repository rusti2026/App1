import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, parseBody, passesOriginGuard, requireAuth, isAuthed } from "@/lib/api-utils";
import { verifyTotp } from "@/lib/security/totp";
import { decryptField } from "@/lib/security/crypto-field";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";

const bodySchema = z.object({ code: z.string().min(6).max(8) });

export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  const user = auth.user;

  const parsed = await parseBody(req, bodySchema);
  if ("response" in parsed) return parsed.response;
  const { code } = parsed.data;

  if (!rateLimit(`mfa:enable:${user.id}`, 8, WINDOW.MIN_15)) {
    return fail(429, "Too many attempts. Try again shortly.", "RATE_LIMITED");
  }

  const secret = decryptField(user.mfaSecretEnc);
  if (!secret) {
    return fail(400, "Run MFA setup first — no enrollment in progress.", "NO_ENROLLMENT");
  }
  if (!verifyTotp(secret, code)) {
    return fail(401, "That code didn't match. Check your authenticator and retry.", "BAD_MFA_CODE");
  }

  await db.user.update({ where: { id: user.id }, data: { mfaEnabled: true } });
  await audit("MFA_ENABLED", req, { userId: user.id });
  return ok({ enabled: true });
}
