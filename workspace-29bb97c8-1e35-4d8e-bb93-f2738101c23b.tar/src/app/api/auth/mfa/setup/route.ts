import { NextRequest } from "next/server";
import QRCode from "qrcode";
import { fail, ok, passesOriginGuard, rateKey, isAuthed, requireAuth } from "@/lib/api-utils";
import { generateBase32Secret, buildOtpauthUri } from "@/lib/security/totp";
import { encryptField } from "@/lib/security/crypto-field";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";
import { db } from "@/lib/db";

/** Generates (and stores, encrypted) a fresh TOTP secret until enrollment completes. */
export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  if (!rateLimit(rateKey(req, "mfa:setup"), 10, WINDOW.MIN_1)) {
    return fail(429, "Too many requests.", "RATE_LIMITED");
  }

  const secret = generateBase32Secret();
  await db.user.update({
    where: { id: auth.user.id },
    data: { mfaSecretEnc: encryptField(secret) },
  });

  const otpauthUri = buildOtpauthUri(secret, auth.user.email);
  let qrDataUrl = "";
  try {
    qrDataUrl = await QRCode.toDataURL(otpauthUri, {
      margin: 1,
      width: 240,
      color: { dark: "#0b0f0e", light: "#f4f7f5" },
    });
  } catch {
    qrDataUrl = ""; // UI falls back to manual secret entry
  }

  await audit("MFA_SETUP", req, { userId: auth.user.id });
  return ok({ secret, otpauthUri, qrDataUrl });
}
