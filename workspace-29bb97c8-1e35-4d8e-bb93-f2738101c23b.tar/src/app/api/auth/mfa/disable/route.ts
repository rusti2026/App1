import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, parseBody, passesOriginGuard, requireAuth, isAuthed } from "@/lib/api-utils";
import { verifyPassword } from "@/lib/security/hash";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";

const bodySchema = z.object({ password: z.string().min(1).max(128) });

export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  const user = auth.user;

  const parsed = await parseBody(req, bodySchema);
  if ("response" in parsed) return parsed.response;

  if (!verifyPassword(parsed.data.password, user.passwordHash)) {
    await audit("MFA_DISABLE_FAILED", req, { userId: user.id });
    return fail(401, "Password incorrect.", "BAD_PASSWORD");
  }

  await db.user.update({
    where: { id: user.id },
    data: { mfaEnabled: false, mfaSecretEnc: null },
  });
  await audit("MFA_DISABLED", req, { userId: user.id });
  return ok({ enabled: false });
}
