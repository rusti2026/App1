import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { fail, ok, passesOriginGuard, SESSION_COOKIE } from "@/lib/api-utils";
import { sha256Hex } from "@/lib/security/hash";
import { verifyToken } from "@/lib/security/jwt";
import { audit } from "@/lib/security/audit";
import { clearSessionCookie } from "@/lib/security/session";

export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");

  const token = req.cookies.get(SESSION_COOKIE)?.value;
  if (token) {
    const payload = verifyToken(token, "session");
    if (payload) {
      await db.session.updateMany({
        where: { id: payload.jti, revokedAt: null },
        data: { revokedAt: new Date() },
      });
      await audit("LOGOUT", req, { userId: payload.sub });
    }
  }
  return clearSessionCookie(ok({ ok: true }));
}
