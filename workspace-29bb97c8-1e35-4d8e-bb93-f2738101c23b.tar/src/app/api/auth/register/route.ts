import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, parseBody, passesOriginGuard, rateKey } from "@/lib/api-utils";
import { hashPassword } from "@/lib/security/hash";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";
import { createSession } from "@/lib/security/session";

const PAPER_FUNDING_CENTS = 100_000_00; // $100,000 simulated paper balance

const bodySchema = z.object({
  email: z.email("Enter a valid email address").max(254),
  password: z
    .string()
    .min(10, "Use at least 10 characters")
    .max(128)
    .regex(/[a-z]/, "Include a lowercase letter")
    .regex(/[A-Z]/, "Include an uppercase letter")
    .regex(/[0-9]/, "Include a digit"),
  name: z.string().trim().min(2, "Name is too short").max(80),
});

export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");

  if (!rateLimit(rateKey(req, "register"), 5, WINDOW.MIN_15)) {
    return fail(429, "Too many signup attempts. Try again shortly.", "RATE_LIMITED");
  }

  const parsed = await parseBody(req, bodySchema);
  if ("response" in parsed) return parsed.response;
  const { email, password, name } = parsed.data;

  const normalizedEmail = email.toLowerCase().trim();
  const existing = await db.user.findUnique({ where: { email: normalizedEmail } });
  if (existing) {
    return fail(409, "An account with this email already exists.", "EMAIL_TAKEN");
  }

  const user = await db.user.create({
    data: {
      email: normalizedEmail,
      name,
      passwordHash: hashPassword(password),
    },
  });

  // Wallet + initial paper-trading funding (double-entry ledger from day one).
  await db.$transaction(async (tx) => {
    const wallet = await tx.wallet.create({ data: { userId: user.id } });
    await tx.ledgerEntry.create({
      data: {
        walletId: wallet.id,
        direction: "CREDIT",
        category: "ADJUSTMENT",
        amountCents: PAPER_FUNDING_CENTS,
        balanceAfterCents: PAPER_FUNDING_CENTS,
        refType: "SYSTEM",
        memo: "Paper trading funding (simulated)",
      },
    });
    await tx.wallet.update({
      where: { id: wallet.id },
      data: { cashAvailableCents: PAPER_FUNDING_CENTS },
    });
  });

  await audit("REGISTER", req, { userId: user.id });
  const res = await createSession(user, req);
  // Body per contract (cookie is set separately by createSession).
  return NextResponse.json(
    { user: { id: user.id, email: user.email, name: user.name, role: user.role } },
    { headers: res.headers }
  );
}
