import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, parseBody, passesOriginGuard } from "@/lib/api-utils";
import { sha256Hex } from "@/lib/security/hash";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";
import { requireAuth, isAuthed } from "@/lib/api-utils";

const bodySchema = z.object({
  challengeId: z.string().min(5),
  code: z.string().min(6).max(6),
});

export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");

  const parsed = await parseBody(req, bodySchema);
  if ("response" in parsed) return parsed.response;
  const { challengeId, code } = parsed.data;

  const challenge = await db.otpChallenge.findUnique({ where: { id: challengeId } });
  if (!challenge || challenge.consumedAt || challenge.expiresAt < new Date()) {
    return fail(410, "This code has expired. Request a new one.", "CODE_EXPIRED");
  }
  if (challenge.attempts >= 5) {
    return fail(429, "Too many incorrect attempts. Request a new code.", "TOO_MANY_ATTEMPTS");
  }
  if (!rateLimit(`otpverify:${challenge.id}`, 8, WINDOW.MIN_15)) {
    return fail(429, "Too many attempts. Request a new code.", "RATE_LIMITED");
  }

  if (challenge.codeHash !== sha256Hex(code)) {
    await db.otpChallenge.update({
      where: { id: challenge.id },
      data: { attempts: { increment: 1 } },
    });
    await audit("OTP_FAILED", req, { detail: challenge.destination });
    return fail(401, "Incorrect code.", "BAD_CODE");
  }

  await db.otpChallenge.update({
    where: { id: challenge.id },
    data: { consumedAt: new Date() },
  });

  // If a session is present, link + verify the destination on the account.
  const auth = await requireAuth(req);
  if (isAuthed(auth)) {
    if (challenge.purpose === "VERIFY_PHONE") {
      await db.user.update({
        where: { id: auth.user.id },
        data: { phone: challenge.destination, phoneVerified: true },
      });
    } else if (challenge.destination === auth.user.email) {
      await db.user.update({
        where: { id: auth.user.id },
        data: { emailVerified: true },
      });
    }
  }

  await audit("OTP_VERIFIED", req, { detail: challenge.destination });
  return ok({ verified: true });
}
