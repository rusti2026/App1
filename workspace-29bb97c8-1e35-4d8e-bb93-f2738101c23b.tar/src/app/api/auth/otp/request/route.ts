import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, parseBody, passesOriginGuard, getClientIp } from "@/lib/api-utils";
import { sha256Hex } from "@/lib/security/hash";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";

const bodySchema = z.object({
  channel: z.enum(["EMAIL", "SMS"]),
  destination: z.string().trim().min(5).max(254),
});

/** 6-digit OTP, hashed at rest, 5-minute TTL, max 5 attempts (sandbox shows the code). */
export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");

  const parsed = await parseBody(req, bodySchema);
  if ("response" in parsed) return parsed.response;
  const { channel, destination } = parsed.data;

  if (!rateLimit(`otp:${getClientIp(req)}:${destination}`, 3, WINDOW.MIN_15)) {
    return fail(429, "Too many codes requested. Try again in a few minutes.", "RATE_LIMITED");
  }

  const code = String(cryptoRandomInt(0, 1_000_000)).padStart(6, "0");
  const expiresAt = new Date(Date.now() + 5 * 60_000);

  const challenge = await db.otpChallenge.create({
    data: {
      channel,
      destination: destination.toLowerCase(),
      purpose: channel === "SMS" ? "VERIFY_PHONE" : "VERIFY_EMAIL",
      codeHash: sha256Hex(code),
      expiresAt,
    },
  });

  await audit("OTP_REQUEST", req, { detail: `${channel}:${destination}` });

  return ok({
    challengeId: challenge.id,
    expiresAt: expiresAt.toISOString(),
    // Sandbox: no SMS/email gateway wired — surface the code for the demo flow.
    devCode: code,
  });
}

function cryptoRandomInt(min: number, max: number): number {
  const range = max - min;
  if (range <= 0) return min;
  const bytes = new Uint32Array(1);
  crypto.getRandomValues(bytes);
  return min + (bytes[0] % range);
}
