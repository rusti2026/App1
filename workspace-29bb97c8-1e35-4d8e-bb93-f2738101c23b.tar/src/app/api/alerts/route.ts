import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, parseBody, passesOriginGuard, rateKey, requireAuth, isAuthed } from "@/lib/api-utils";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";
import { fetchLiveQuote } from "@/lib/market/quotes-client";
import { ensureMatcher } from "@/lib/trading/matcher";
import { toAlertDTO } from "@/lib/trading/dto";

// Evaluate alerts even before the first order is placed (idempotent).
ensureMatcher();

const MAX_ACTIVE_ALERTS = 30;

const postSchema = z.object({
  symbol: z.string().trim().min(1).max(20).toUpperCase(),
  condition: z.enum(["ABOVE", "BELOW"]),
  targetCents: z.number().int().positive(),
});

export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;

  const alerts = await db.priceAlert.findMany({
    where: { userId: auth.user.id },
    orderBy: { createdAt: "desc" },
    take: 50,
    include: { asset: { select: { name: true } } },
  });
  return ok({ alerts: alerts.map(toAlertDTO) });
}

export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  const user = auth.user;

  if (!rateLimit(rateKey(req, "alerts", user.id), 30, WINDOW.MIN_1)) {
    return fail(429, "Too many alerts in a minute.", "RATE_LIMITED");
  }

  const parsed = await parseBody(req, postSchema);
  if ("response" in parsed) return parsed.response;
  const input = parsed.data;

  const asset = await db.asset.findUnique({ where: { symbol: input.symbol } });
  if (!asset) return fail(404, `Unknown symbol ${input.symbol}.`, "UNKNOWN_SYMBOL");

  // Alerts need a live price to be meaningful — reject when the feed is down.
  const quote = await fetchLiveQuote(input.symbol);
  if (!quote) return fail(503, "Live price unavailable — please try again.", "FEED_UNAVAILABLE");

  const activeCount = await db.priceAlert.count({
    where: { userId: user.id, status: "ACTIVE" },
  });
  if (activeCount >= MAX_ACTIVE_ALERTS) {
    return fail(422, `Maximum ${MAX_ACTIVE_ALERTS} active alerts reached — cancel one first.`, "ALERT_LIMIT");
  }

  const alert = await db.priceAlert.create({
    data: {
      userId: user.id,
      symbol: input.symbol,
      condition: input.condition,
      targetCents: input.targetCents,
      status: "ACTIVE",
    },
    include: { asset: { select: { name: true } } },
  });
  await audit("ALERT_CREATED", req, {
    userId: user.id,
    detail: `${input.condition} ${input.symbol} target=${input.targetCents}`,
  });
  return ok({ alert: toAlertDTO(alert) }, 201);
}

export async function DELETE(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;

  const id = req.nextUrl.searchParams.get("id");
  if (!id) return fail(400, "id query param required.", "MISSING_ID");

  const alert = await db.priceAlert.findFirst({ where: { id, userId: auth.user.id } });
  if (!alert) return fail(404, "Alert not found.", "ALERT_NOT_FOUND");

  if (alert.status === "TRIGGERED") {
    return fail(422, "Triggered alerts cannot be canceled.", "INVALID_STATE");
  }
  if (alert.status === "ACTIVE") {
    await db.priceAlert.update({ where: { id: alert.id }, data: { status: "CANCELED" } });
    await audit("ALERT_CANCELED", req, { userId: auth.user.id, detail: alert.id });
  }
  return ok({ ok: true });
}
