import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { fail, ok, parseBody, passesOriginGuard, rateKey, requireAuth, isAuthed } from "@/lib/api-utils";
import { encryptField } from "@/lib/security/crypto-field";
import { rateLimit, WINDOW } from "@/lib/security/rate-limit";
import { audit } from "@/lib/security/audit";

const bodySchema = z.object({
  legalFirstName: z.string().trim().min(1).max(60),
  legalLastName: z.string().trim().min(1).max(60),
  dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD"),
  country: z.string().trim().min(2).max(56),
  address1: z.string().trim().min(4).max(120),
  address2: z.string().trim().max(120).optional(),
  city: z.string().trim().min(2).max(80),
  region: z.string().trim().min(2).max(80),
  postalCode: z.string().trim().min(3).max(10),
  taxIdLast4: z.string().regex(/^\d{4}$/, "Last 4 digits only"),
  docType: z.enum(["PAN", "AADHAAR", "PASSPORT", "DRIVERS_LICENSE"]),
  docNumber: z.string().trim().min(4).max(40),
  pep: z.boolean(),
});

export async function POST(req: NextRequest) {
  if (!passesOriginGuard(req)) return fail(403, "Cross-origin request rejected", "CSRF");
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  const user = auth.user;

  if (!rateLimit(rateKey(req, "kyc"), 6, WINDOW.MIN_15)) {
    return fail(429, "Too many submissions. Try again shortly.", "RATE_LIMITED");
  }

  const parsed = await parseBody(req, bodySchema);
  if ("response" in parsed) return parsed.response;
  const data = parsed.data;

  // Simulated AML screening: PEP flags high risk; DOB sanity check (18+).
  const dob = new Date(`${data.dateOfBirth}T00:00:00Z`);
  const age = (Date.now() - dob.getTime()) / (365.25 * 24 * 3600 * 1000);
  if (Number.isNaN(age) || age < 18) {
    return fail(400, "You must be at least 18 years old to open an account.", "AGE_MIN");
  }
  const riskRating = data.pep ? "HIGH" : "LOW";

  const existing = await db.kycProfile.findUnique({ where: { userId: user.id } });
  const payload = {
    legalFirstName: data.legalFirstName,
    legalLastName: data.legalLastName,
    dateOfBirth: data.dateOfBirth,
    country: data.country,
    address1: data.address1,
    address2: data.address2 ?? null,
    city: data.city,
    region: data.region,
    postalCode: data.postalCode,
    taxIdLast4Enc: encryptField(data.taxIdLast4),
    docType: data.docType,
    docNumberEnc: encryptField(data.docNumber),
    pep: data.pep,
    status: "PENDING",
    riskRating,
    submittedAt: new Date(),
    reviewedAt: null,
    reviewNote: null,
  };

  if (existing) {
    await db.kycProfile.update({ where: { id: existing.id }, data: payload });
  } else {
    await db.kycProfile.create({ data: { userId: user.id, ...payload } });
  }

  await audit("KYC_SUBMITTED", req, { userId: user.id, detail: `risk=${riskRating}` });
  return ok({ status: "PENDING" });
}
