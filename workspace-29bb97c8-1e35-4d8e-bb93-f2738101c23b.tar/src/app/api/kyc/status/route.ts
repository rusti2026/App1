import { NextRequest } from "next/server";
import { fail, ok, requireAuth, isAuthed } from "@/lib/api-utils";
import { settleKycIfDue } from "@/lib/security/session";

export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;

  const profile = await settleKycIfDue(auth.user.id);
  const status = profile?.status ?? "UNSUBMITTED";
  return ok({
    status,
    onboardingDone: status === "APPROVED",
  });
}
