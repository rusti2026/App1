import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok } from "@/lib/api-utils";
import { fetchLiveQuotes } from "@/lib/market/quotes-client";
import type { MarketQuote } from "@/lib/types";

/**
 * Market screener — Phase 3: live quotes for EVERY listed asset, falling back
 * to seeded DB prices when the feed is down. Public (same as overview).
 */
export async function GET(_req: NextRequest) {
  const assets = await db.asset.findMany({
    orderBy: { symbol: "asc" },
    select: {
      symbol: true,
      name: true,
      type: true,
      exchange: true,
      lastPriceCents: true,
      prevCloseCents: true,
      volume: true,
    },
  });
  const live = await fetchLiveQuotes();

  const quotes: MarketQuote[] = assets.map((a) => {
    const q = live?.get(a.symbol);
    const last = q?.lastPriceCents ?? a.lastPriceCents;
    const prevClose = q?.prevCloseCents ?? a.prevCloseCents;
    const change = last - prevClose;
    return {
      symbol: a.symbol,
      name: a.name,
      type: a.type as MarketQuote["type"],
      exchange: a.exchange,
      lastPriceCents: last,
      prevCloseCents: prevClose,
      changeCents: change,
      changePct: prevClose > 0 ? Number(((change / prevClose) * 100).toFixed(2)) : 0,
      volume: q?.volume ?? a.volume,
    };
  });

  return ok({ quotes });
}
