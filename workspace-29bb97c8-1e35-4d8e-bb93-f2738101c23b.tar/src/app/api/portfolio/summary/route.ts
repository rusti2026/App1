import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { fail, ok, requireAuth, isAuthed } from "@/lib/api-utils";
import { fetchLiveQuotes } from "@/lib/market/quotes-client";
import type { PortfolioSummary, PositionDetail } from "@/lib/types";

/** Portfolio service (holdings · P&L · ledger) — live mark-to-market from the feed. */
export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  const userId = auth.user.id;

  const wallet = await db.wallet.findUnique({ where: { userId } });
  if (!wallet) return fail(500, "Wallet missing — contact support.", "NO_WALLET");

  const [holdings, ledger] = await Promise.all([
    db.position.findMany({
      // qty may be NEGATIVE (MIS/CO/BO shorts) — include both directions;
      // qty=0 rows only linger for their realized PnL.
      where: { userId, OR: [{ qty: { not: 0 } }, { realizedPnlCents: { not: 0 } }] },
    }),
    db.ledgerEntry.findMany({
      where: { walletId: wallet.id },
      orderBy: { createdAt: "desc" },
      take: 10,
    }),
  ]);

  const symbols = holdings.map((p) => p.symbol);
  const assets = symbols.length
    ? await db.asset.findMany({ where: { symbol: { in: symbols } }, select: { symbol: true, name: true } })
    : [];
  const nameBySymbol = new Map(assets.map((a) => [a.symbol, a.name]));
  const live = symbols.length ? await fetchLiveQuotes(symbols) : null;

  const positions: PositionDetail[] = holdings.map((p) => {
    const q = live?.get(p.symbol);
    const last = q?.lastPriceCents ?? p.avgCostCents;
    const prevClose = q?.prevCloseCents ?? last;
    const mktValueCents = p.qty * last; // signed — negative for shorts
    const costBasis = p.qty * p.avgCostCents;
    // PnL is direction-aware via the signed qty: long gains when price rises,
    // short gains when it falls. (LTP − avg) × qty is correct for both.
    const unrealizedPnlCents = (last - p.avgCostCents) * p.qty;
    const dayPnlCents = (last - prevClose) * p.qty;
    return {
      symbol: p.symbol,
      name: nameBySymbol.get(p.symbol) ?? p.symbol,
      qty: p.qty,
      avgCostCents: p.avgCostCents,
      lastPriceCents: last,
      mktValueCents,
      unrealizedPnlCents,
      dayPnlCents,
      // Percentage against the |cost basis| (short cost basis is negative).
      dayPnlPct: costBasis !== 0 ? Number(((dayPnlCents / Math.abs(costBasis)) * 100).toFixed(2)) : 0,
    };
  });

  const positionsValueCents = positions.reduce((s, p) => s + p.mktValueCents, 0);
  const totalEquityCents = wallet.cashAvailableCents + positionsValueCents;
  const dayPnlCents = positions.reduce((s, p) => s + p.dayPnlCents, 0);
  const dayStartEquity = totalEquityCents - dayPnlCents;
  const dayPnlPct = dayStartEquity > 0 ? Number(((dayPnlCents / dayStartEquity) * 100).toFixed(2)) : 0;

  const summary: PortfolioSummary = {
    cashAvailableCents: wallet.cashAvailableCents,
    cashPendingCents: wallet.cashPendingCents,
    positionsValueCents,
    totalEquityCents,
    dayPnlCents,
    dayPnlPct,
    positions,
    ledger: ledger.map((e) => ({
      id: e.id,
      direction: e.direction as "CREDIT" | "DEBIT",
      category: e.category,
      memo: e.memo ?? undefined,
      amountCents: e.amountCents,
      balanceAfterCents: e.balanceAfterCents,
      createdAt: e.createdAt.toISOString(),
      refType: e.refType ?? undefined,
      refId: e.refId ?? undefined,
    })),
  };

  return ok(summary);
}
