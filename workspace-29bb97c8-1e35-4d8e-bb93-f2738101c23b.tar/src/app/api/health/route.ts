import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok } from "@/lib/api-utils";

export async function GET(_req: NextRequest) {
  try {
    await db.$queryRaw`SELECT 1`;
    return ok({ ok: true, time: new Date().toISOString(), db: true });
  } catch {
    return ok({ ok: true, time: new Date().toISOString(), db: false });
  }
}
