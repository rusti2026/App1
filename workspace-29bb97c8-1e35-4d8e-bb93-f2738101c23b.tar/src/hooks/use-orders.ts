"use client";

/**
 * Trading REST hooks (§6b + §8b): orders list, place order, cancel order,
 * exit CO/BO entries.
 * Cancel removes the order optimistically and rolls back on failure.
 * Place-order surfaces risk rejects (422 { error, code }) to the caller via
 * the mutation error (ApiError), so the ticket can render them inline.
 */

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiFetch } from "@/lib/api-client";
import type {
  OrderDTO,
  OrdersResponse,
  PlaceOrderPayload,
  PlaceOrderResponse,
} from "@/lib/types";

export const ORDERS_KEY = ["orders"] as const;

/** Order history — newest first (≤50). Polls gently so resting orders stay fresh. */
export function useOrders() {
  return useQuery<OrdersResponse>({
    queryKey: ORDERS_KEY,
    queryFn: () => apiFetch<OrdersResponse>("/api/orders"),
    refetchInterval: 15_000,
  });
}

export function usePlaceOrder() {
  const queryClient = useQueryClient();
  return useMutation<PlaceOrderResponse, Error, PlaceOrderPayload>({
    mutationFn: (payload) =>
      apiFetch<PlaceOrderResponse>("/api/orders", { method: "POST", json: payload }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["portfolio"] });
      void queryClient.invalidateQueries({ queryKey: ORDERS_KEY });
    },
  });
}

/** Cancel a NEW/PARTIALLY_FILLED order — optimistic removal + rollback. */
export function useCancelOrder() {
  const queryClient = useQueryClient();
  return useMutation<
    { order: OrderDTO },
    Error,
    string,
    { previous?: OrdersResponse }
  >({
    mutationFn: (orderId) =>
      apiFetch<{ order: OrderDTO }>(`/api/orders/${encodeURIComponent(orderId)}/cancel`, {
        method: "POST",
      }),
    onMutate: async (orderId) => {
      await queryClient.cancelQueries({ queryKey: ORDERS_KEY });
      const previous = queryClient.getQueryData<OrdersResponse>(ORDERS_KEY);
      if (previous) {
        queryClient.setQueryData<OrdersResponse>(ORDERS_KEY, {
          orders: previous.orders.filter((o) => o.id !== orderId),
        });
      }
      return { previous };
    },
    onError: (error, _orderId, context) => {
      if (context?.previous) {
        queryClient.setQueryData(ORDERS_KEY, context.previous);
      }
      toast.error("Could not cancel order", {
        description: error instanceof Error ? error.message : undefined,
      });
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ORDERS_KEY });
      void queryClient.invalidateQueries({ queryKey: ["portfolio"] });
    },
  });
}

/**
 * Exit a CO/BO entry (§8b): cancels any open legs (MANUAL_EXIT) and creates
 * a MARKET square-off leg for the filled quantity. The backend answers 409
 * NOTHING_TO_EXIT when already flat and NOT_CANCELLABLE for non-strategy
 * orders — both surface through the error toast.
 */
export function useExitOrder() {
  const queryClient = useQueryClient();
  return useMutation<{ order: OrderDTO }, Error, string>({
    mutationFn: (orderId) =>
      apiFetch<{ order: OrderDTO }>(
        `/api/orders/${encodeURIComponent(orderId)}/exit`,
        { method: "POST" }
      ),
    onSuccess: () => {
      toast.success("Exit order placed — market square-off incoming");
      void queryClient.invalidateQueries({ queryKey: ["portfolio"] });
      void queryClient.invalidateQueries({ queryKey: ORDERS_KEY });
    },
    onError: (error) => {
      toast.error("Could not exit position", {
        description: error instanceof Error ? error.message : undefined,
      });
    },
  });
}
