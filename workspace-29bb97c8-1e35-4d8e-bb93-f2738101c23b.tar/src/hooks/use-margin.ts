"use client";

/**
 * Margin-estimator hook (Phase 4 §8a) — GET /api/margin for the live order
 * ticket. Read-only: the endpoint never places anything.
 *
 * The ticket re-renders on every keystroke, so the request is debounced
 * (~400ms) inside the hook: the serialized query string only settles — and
 * the query only fires — after the payload stops changing. While a newer
 * request is in flight the previous MarginResponse stays on screen
 * (keepPreviousData), so the margin line never flickers to a skeleton.
 *
 * Enabled only for CO/BO/MIS tickets (CNC keeps the plain order-value line)
 * to keep the endpoint light.
 */

import { useEffect, useState } from "react";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api-client";
import type { MarginRequest, MarginResponse } from "@/lib/types";

export const MARGIN_KEY = ["margin"] as const;

/** Serialize a MarginRequest into the §8a query-string shape. */
export function marginQueryString(request: MarginRequest): string {
  const params = new URLSearchParams();
  params.set("symbol", request.symbol);
  params.set("side", request.side);
  params.set("type", request.type);
  params.set("qty", String(request.qty));
  if (request.product) params.set("product", request.product);
  if (request.strategy) params.set("strategy", request.strategy);
  if (request.limitPriceCents !== undefined)
    params.set("limitPriceCents", String(request.limitPriceCents));
  if (request.stopPriceCents !== undefined)
    params.set("stopPriceCents", String(request.stopPriceCents));
  if (request.targetCents !== undefined)
    params.set("targetCents", String(request.targetCents));
  return params.toString();
}

/**
 * Live margin estimate for the current ticket payload. Pass `null` to
 * disable (non-margin kinds / invalid payload). Returns the last known
 * MarginResponse while a refetch is pending.
 */
export function useMargin(request: MarginRequest | null) {
  const queryString = request ? marginQueryString(request) : null;

  // Debounce the serialized request: only after ~400ms without changes does
  // the query key (and therefore the fetch) settle.
  const [settledQs, setSettledQs] = useState<string | null>(queryString);
  useEffect(() => {
    const timer = setTimeout(() => setSettledQs(queryString), 400);
    return () => clearTimeout(timer);
  }, [queryString]);

  return useQuery<MarginResponse>({
    queryKey: [MARGIN_KEY, settledQs],
    queryFn: () => apiFetch<MarginResponse>(`/api/margin?${settledQs ?? ""}`),
    enabled: settledQs !== null,
    placeholderData: keepPreviousData,
    staleTime: 3_000,
  });
}
