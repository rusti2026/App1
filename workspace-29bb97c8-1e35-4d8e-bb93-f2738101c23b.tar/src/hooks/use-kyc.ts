"use client";

import { useMutation, useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api-client";
import type { KycStatusResponse, KycSubmitPayload, KycSubmitResponse } from "@/lib/types";

export const KYC_STATUS_KEY = ["kyc", "status"] as const;

/** Poll the simulated KYC reviewer every 2s while a submission is under review. */
export function useKycStatus(enabled: boolean) {
  return useQuery<KycStatusResponse>({
    queryKey: KYC_STATUS_KEY,
    queryFn: () => apiFetch<KycStatusResponse>("/api/kyc/status"),
    refetchInterval: 2_000,
    enabled,
  });
}

export function useKycSubmit() {
  return useMutation({
    mutationFn: (payload: KycSubmitPayload) =>
      apiFetch<KycSubmitResponse>("/api/kyc/submit", {
        method: "POST",
        json: payload,
      }),
  });
}
