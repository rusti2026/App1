"use client";

/**
 * Screener query — the full instrument universe from GET /api/market/screener.
 * Polled every 5s; the consumer joins live WS quotes on top (see screener-card).
 */

import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api-client";
import type { MarketQuote } from "@/lib/types";

export const SCREENER_KEY = ["market", "screener"] as const;

export interface ScreenerResponse {
  quotes: MarketQuote[];
}

export function useScreener() {
  return useQuery<ScreenerResponse>({
    queryKey: SCREENER_KEY,
    queryFn: () => apiFetch<ScreenerResponse>("/api/market/screener"),
    refetchInterval: 5_000,
  });
}
