"use client";

import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api-client";
import type { PortfolioSummary } from "@/lib/types";

export const PORTFOLIO_SUMMARY_KEY = ["portfolio", "summary"] as const;

export function usePortfolioSummary() {
  return useQuery<PortfolioSummary>({
    queryKey: PORTFOLIO_SUMMARY_KEY,
    queryFn: () => apiFetch<PortfolioSummary>("/api/portfolio/summary"),
    refetchInterval: 15_000,
  });
}
