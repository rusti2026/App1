"use client";

import { useMutation } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api-client";
import type {
  LoginMfaPayload,
  LoginMfaResponse,
  LoginPayload,
  LoginResponse,
  MfaDisablePayload,
  MfaDisableResponse,
  MfaEnablePayload,
  MfaEnableResponse,
  MfaSetupResponse,
  OtpRequestPayload,
  OtpRequestResponse,
  OtpVerifyPayload,
  OtpVerifyResponse,
  RegisterPayload,
  RegisterResponse,
} from "@/lib/types";

export function useRegister() {
  return useMutation({
    mutationFn: (payload: RegisterPayload) =>
      apiFetch<RegisterResponse>("/api/auth/register", {
        method: "POST",
        json: payload,
      }),
  });
}

export function useLogin() {
  return useMutation({
    mutationFn: (payload: LoginPayload) =>
      apiFetch<LoginResponse>("/api/auth/login", {
        method: "POST",
        json: payload,
      }),
  });
}

export function useLoginMfa() {
  return useMutation({
    mutationFn: (payload: LoginMfaPayload) =>
      apiFetch<LoginMfaResponse>("/api/auth/login/mfa", {
        method: "POST",
        json: payload,
      }),
  });
}

export function useOtpRequest() {
  return useMutation({
    mutationFn: (payload: OtpRequestPayload) =>
      apiFetch<OtpRequestResponse>("/api/auth/otp/request", {
        method: "POST",
        json: payload,
      }),
  });
}

export function useOtpVerify() {
  return useMutation({
    mutationFn: (payload: OtpVerifyPayload) =>
      apiFetch<OtpVerifyResponse>("/api/auth/otp/verify", {
        method: "POST",
        json: payload,
      }),
  });
}

export function useMfaSetup() {
  return useMutation({
    mutationFn: () =>
      apiFetch<MfaSetupResponse>("/api/auth/mfa/setup", { method: "POST" }),
  });
}

export function useMfaEnable() {
  return useMutation({
    mutationFn: (payload: MfaEnablePayload) =>
      apiFetch<MfaEnableResponse>("/api/auth/mfa/enable", {
        method: "POST",
        json: payload,
      }),
  });
}

export function useMfaDisable() {
  return useMutation({
    mutationFn: (payload: MfaDisablePayload) =>
      apiFetch<MfaDisableResponse>("/api/auth/mfa/disable", {
        method: "POST",
        json: payload,
      }),
  });
}
