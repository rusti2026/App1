"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiFetch } from "@/lib/api-client";
import type { MarketOverview, WatchlistResponse } from "@/lib/types";

export const MARKET_OVERVIEW_KEY = ["market", "overview"] as const;
export const WATCHLIST_KEY = ["watchlist"] as const;

/** Market overview — shared by the landing ticker, hero card and dashboard movers. */
export function useMarketOverview() {
  return useQuery<MarketOverview>({
    queryKey: MARKET_OVERVIEW_KEY,
    queryFn: () => apiFetch<MarketOverview>("/api/market/overview"),
    staleTime: 15_000,
    refetchInterval: 20_000,
  });
}

export function useWatchlist() {
  return useQuery<WatchlistResponse>({
    queryKey: WATCHLIST_KEY,
    queryFn: () => apiFetch<WatchlistResponse>("/api/watchlist"),
  });
}

export function useAddToWatchlist() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (symbol: string) =>
      apiFetch<WatchlistResponse>("/api/watchlist", {
        method: "POST",
        json: { symbol },
      }),
    onMutate: async (symbol) => {
      await queryClient.cancelQueries({ queryKey: WATCHLIST_KEY });
      const previous =
        queryClient.getQueryData<WatchlistResponse>(WATCHLIST_KEY);
      if (previous && !previous.items.some((i) => i.symbol === symbol)) {
        queryClient.setQueryData<WatchlistResponse>(WATCHLIST_KEY, {
          items: [...previous.items, { symbol }],
        });
      }
      return { previous };
    },
    onError: (error, _symbol, context) => {
      if (context?.previous) {
        queryClient.setQueryData(WATCHLIST_KEY, context.previous);
      }
      toast.error("Could not add to watchlist", {
        description: error instanceof Error ? error.message : undefined,
      });
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: WATCHLIST_KEY });
    },
  });
}

export function useRemoveFromWatchlist() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (symbol: string) =>
      apiFetch<WatchlistResponse>(
        `/api/watchlist?symbol=${encodeURIComponent(symbol)}`,
        { method: "DELETE" }
      ),
    onMutate: async (symbol) => {
      await queryClient.cancelQueries({ queryKey: WATCHLIST_KEY });
      const previous =
        queryClient.getQueryData<WatchlistResponse>(WATCHLIST_KEY);
      if (previous) {
        queryClient.setQueryData<WatchlistResponse>(WATCHLIST_KEY, {
          items: previous.items.filter((i) => i.symbol !== symbol),
        });
      }
      return { previous };
    },
    onError: (error, _symbol, context) => {
      if (context?.previous) {
        queryClient.setQueryData(WATCHLIST_KEY, context.previous);
      }
      toast.error("Could not remove from watchlist", {
        description: error instanceof Error ? error.message : undefined,
      });
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: WATCHLIST_KEY });
    },
  });
}
