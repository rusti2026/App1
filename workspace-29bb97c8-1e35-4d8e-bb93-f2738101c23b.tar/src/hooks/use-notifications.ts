"use client";

/**
 * Notification REST hooks (Phase 4 §8c): list, mark read, delete.
 * - List polls gently (15s) so the unread count stays fresh even without WS.
 * - WS `notification` events (use-quotes) toast + invalidate this same cache,
 *   so the bell updates instantly while the poll is the safety net.
 * - Delete removes the notification optimistically and rolls back on failure
 *   (same pattern as useCancelOrder / useCancelAlert).
 */

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiFetch } from "@/lib/api-client";
import type {
  MarkNotificationsReadPayload,
  NotificationsResponse,
} from "@/lib/types";

export const NOTIFICATIONS_KEY = ["notifications"] as const;

/** Newest-first notification feed (≤30 rows) + server-side unread count. */
export function useNotifications() {
  return useQuery<NotificationsResponse>({
    queryKey: NOTIFICATIONS_KEY,
    queryFn: () => apiFetch<NotificationsResponse>("/api/notifications"),
    refetchInterval: 15_000,
  });
}

/**
 * POST /api/notifications/read — `{ ids?: string[], all?: boolean }`.
 * Server returns the fresh unread count; the feed is invalidated so the
 * unread dots/badge settle to the server truth.
 */
export function useMarkNotificationsRead() {
  const queryClient = useQueryClient();
  return useMutation<{ ok: true; unread: number }, Error, MarkNotificationsReadPayload>({
    mutationFn: (payload) =>
      apiFetch<{ ok: true; unread: number }>("/api/notifications/read", {
        method: "POST",
        json: payload,
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: NOTIFICATIONS_KEY });
    },
    onError: (error) => {
      toast.error("Could not update notifications", {
        description: error instanceof Error ? error.message : undefined,
      });
    },
  });
}

/** DELETE /api/notifications?id=… — optimistic removal + rollback. */
export function useDeleteNotification() {
  const queryClient = useQueryClient();
  return useMutation<
    { ok: true },
    Error,
    string,
    { previous?: NotificationsResponse }
  >({
    mutationFn: (notificationId) =>
      apiFetch<{ ok: true }>(
        `/api/notifications?id=${encodeURIComponent(notificationId)}`,
        { method: "DELETE" }
      ),
    onMutate: async (notificationId) => {
      await queryClient.cancelQueries({ queryKey: NOTIFICATIONS_KEY });
      const previous = queryClient.getQueryData<NotificationsResponse>(
        NOTIFICATIONS_KEY
      );
      if (previous) {
        const removed = previous.notifications.find((n) => n.id === notificationId);
        queryClient.setQueryData<NotificationsResponse>(NOTIFICATIONS_KEY, {
          notifications: previous.notifications.filter(
            (n) => n.id !== notificationId
          ),
          // The unread total is server-side; only decrement when the removed
          // row was actually unread.
          unread: Math.max(
            0,
            previous.unread - (removed && !removed.readAt ? 1 : 0)
          ),
        });
      }
      return { previous };
    },
    onError: (error, _notificationId, context) => {
      if (context?.previous) {
        queryClient.setQueryData(NOTIFICATIONS_KEY, context.previous);
      }
      toast.error("Could not delete notification", {
        description: error instanceof Error ? error.message : undefined,
      });
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: NOTIFICATIONS_KEY });
    },
  });
}
