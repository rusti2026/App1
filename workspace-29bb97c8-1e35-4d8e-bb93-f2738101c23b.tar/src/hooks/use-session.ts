"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api-client";
import type { LogoutResponse, SessionResponse } from "@/lib/types";

export const SESSION_KEY = ["session"] as const;

/**
 * Source of truth for the SPA state machine — the httpOnly session cookie
 * decides whether the user is authenticated; the server never lies.
 */
export function useSession() {
  return useQuery<SessionResponse>({
    queryKey: SESSION_KEY,
    queryFn: () => apiFetch<SessionResponse>("/api/auth/session"),
    staleTime: 30_000,
    retry: 1,
  });
}

export function useLogout() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () =>
      apiFetch<LogoutResponse>("/api/auth/logout", { method: "POST" }),
    onSuccess: () => {
      // Explicitly flip the session (the state machine reacts immediately),
      // then drop every other cached query (portfolio, watchlist, market…).
      queryClient.setQueryData<SessionResponse>(SESSION_KEY, {
        authenticated: false,
      });
      queryClient.removeQueries({
        predicate: (q) => q.queryKey[0] !== "session",
      });
    },
  });
}
