"use client";

/**
 * MERIDIAN — live market-data socket layer (ARCHITECTURE.md §6a).
 *
 * ONE shared socket.io connection (module-level singleton via getSocket())
 * serves every consumer: indices strip, ticker tape, watchlist, movers,
 * holdings, instrument detail and the footer status chip. Subscriptions are
 * ref-counted per symbol so mounting/unmounting consumers never starve or
 * leak rooms on the shared connection.
 *
 * Connection URL: the sandbox spec is the Caddy-proxied relative route
 * `/?XTransformPort=3003` (see examples/websocket/frontend.tsx). When the app
 * is served directly by the Next dev server (local dev) that route answers
 * HTML instead of an engine.io handshake, so a one-time probe falls back to
 * the market-data service on the same host — the proxied route stays the
 * default and works unchanged behind Caddy.
 *
 * Tick payloads arrive ~500ms per symbol; state is batched at ~10Hz (100ms
 * interval) to avoid re-render storms. RTT is measured with a ping/pong
 * heartbeat every 5s (shared, module-level).
 */

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { io, type Socket } from "socket.io-client";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useReducedMotion } from "framer-motion";

import { apiFetch } from "@/lib/api-client";
import { formatInr } from "@/components/meridian/format";
import { ALERTS_KEY } from "@/hooks/use-alerts";
import { NOTIFICATIONS_KEY } from "@/hooks/use-notifications";
import type {
  AlertEventPayload,
  DepthSnapshot,
  NotificationEventPayload,
  OrderDTO,
  TickQuote,
  WsTicketResponse,
} from "@/lib/types";

/* ------------------------------------------------------------------ */
/* constants                                                           */
/* ------------------------------------------------------------------ */

/** The 3 benchmark indices (§6a universe). */
export const INDEX_SYMBOLS = ["NIFTY50", "BANKNIFTY", "SENSEX"] as const;

/** The full 21-instrument NSE/BSE universe (mirrors instruments.json). */
export const ALL_SYMBOLS = [
  "RELIANCE",
  "TCS",
  "HDFCBANK",
  "INFY",
  "ICICIBANK",
  "SBIN",
  "TATAMOTORS",
  "BHARTIARTL",
  "LT",
  "ADANIENT",
  "WIPRO",
  "IRFC",
  "ZOMATO",
  "HINDUNILVR",
  "MARUTI",
  "TITAN",
  "NIFTYBEES",
  "GOLDBEES",
  ...INDEX_SYMBOLS,
] as const;

const WS_PATH = "/?XTransformPort=3003";

/* ------------------------------------------------------------------ */
/* singleton socket + module-level dispatchers                         */
/* ------------------------------------------------------------------ */

let socketPromise: Promise<Socket> | null = null;
let socketRef: Socket | null = null;
let heartbeatStarted = false;

/** symbol → number of active consumers on the shared socket. */
const symbolCounts = new Map<string, number>();
/** symbols with an open depth room (re-established on reconnect). */
const depthSymbols = new Set<string>();

type SnapshotPayload = { quotes: TickQuote[] };
const snapshotListeners = new Set<(payload: SnapshotPayload) => void>();
const tickListeners = new Set<(quote: TickQuote) => void>();
const depthListeners = new Set<(snapshot: DepthSnapshot) => void>();
const orderListeners = new Set<(payload: { order: OrderDTO }) => void>();
const alertListeners = new Set<(payload: AlertEventPayload) => void>();
const notificationListeners = new Set<
  (payload: NotificationEventPayload) => void
>();
const nudgeListeners = new Set<() => void>();
const connectListeners = new Set<() => void>();

/** Emit only while connected — rooms are re-established on `connect`. */
function emitWhenConnected(event: string, payload: unknown) {
  if (socketRef?.connected) socketRef.emit(event, payload);
}

async function resolveSocketUrl(): Promise<string> {
  const spec = WS_PATH; // Caddy-proxied route — the documented sandbox default
  if (typeof window === "undefined") return spec;
  try {
    const res = await fetch(`${spec}&EIO=4&transport=polling&t=${Date.now()}`, {
      cache: "no-store",
    });
    const head = (await res.text()).trimStart().slice(0, 1);
    if (res.ok && head === "0") return spec; // engine.io handshake → proxy works
  } catch {
    /* probe failed — fall through to the direct service */
  }
  return `${window.location.protocol}//${window.location.hostname}:3003${WS_PATH}`;
}

/**
 * Shared socket singleton. The returned promise resolves once, at first use;
 * every consumer awaits the same connection.
 */
export function getSocket(): Promise<Socket> {
  if (!socketPromise) socketPromise = createSocket();
  return socketPromise;
}

async function createSocket(): Promise<Socket> {
  const url = await resolveSocketUrl();
  // NOTE: never set the `path` option — the ?XTransformPort query is how
  // Caddy routes to the market-data service (§6a / examples pattern).
  const sock = io(url, {
    transports: ["websocket", "polling"],
    forceNew: true,
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelay: 1000,
    timeout: 10000,
  });
  socketRef = sock;

  sock.on("connect", () => {
    setStatus({ connected: true });
    // Fresh server-side rooms after every (re)connect — re-establish all.
    const symbols = Array.from(symbolCounts.keys());
    if (symbols.length > 0) sock.emit("subscribe", { symbols });
    for (const symbol of depthSymbols) sock.emit("watch-depth", { symbol });
    for (const listener of connectListeners) listener();
  });

  sock.on("disconnect", () => {
    setStatus({ connected: false });
  });

  sock.on("snapshot", (payload: SnapshotPayload) => {
    for (const listener of snapshotListeners) listener(payload);
  });
  sock.on("tick", (quote: TickQuote) => {
    for (const listener of tickListeners) listener(quote);
  });
  sock.on("depth", (snapshot: DepthSnapshot) => {
    for (const listener of depthListeners) listener(snapshot);
  });
  sock.on("order-update", (payload: { order: OrderDTO }) => {
    for (const listener of orderListeners) listener(payload);
  });
  sock.on("alert", (payload: AlertEventPayload) => {
    for (const listener of alertListeners) listener(payload);
  });
  sock.on("notification", (payload: NotificationEventPayload) => {
    for (const listener of notificationListeners) listener(payload);
  });
  sock.on("portfolio-nudge", () => {
    for (const listener of nudgeListeners) listener();
  });

  if (!heartbeatStarted) {
    heartbeatStarted = true;
    startHeartbeat(sock);
  }
  return sock;
}

/** ping {t} every 5s → pong {t}; RTT = now − t, clamped to 999ms. */
function startHeartbeat(sock: Socket) {
  setInterval(() => {
    if (!sock.connected) return;
    const t = Date.now();
    sock.once("pong", (payload: { t: number }) => {
      const rtt = Math.min(999, Math.max(0, Date.now() - (payload?.t ?? t)));
      setStatus({ rttMs: rtt });
    });
    sock.emit("ping", { t });
  }, 5_000);
}

/* ------------------------------------------------------------------ */
/* shared connection status (footer + every hook)                      */
/* ------------------------------------------------------------------ */

export interface WsStatus {
  connected: boolean;
  rttMs: number | null;
}

let status: WsStatus = { connected: false, rttMs: null };
const statusListeners = new Set<() => void>();

function setStatus(patch: Partial<WsStatus>) {
  status = { ...status, ...patch };
  for (const listener of statusListeners) listener();
}

/** Connection + RTT for the footer chip and any status UI. */
export function useSocketStatus(): WsStatus {
  return useSyncExternalStore(
    subscribeStatus,
    getStatusSnapshot,
    getStatusSnapshot
  );
}

function subscribeStatus(listener: () => void) {
  statusListeners.add(listener);
  return () => {
    statusListeners.delete(listener);
  };
}

function getStatusSnapshot(): WsStatus {
  return status;
}

/* ------------------------------------------------------------------ */
/* ref-counted subscriptions                                           */
/* ------------------------------------------------------------------ */

function acquire(symbols: readonly string[]) {
  for (const symbol of symbols) {
    const count = symbolCounts.get(symbol) ?? 0;
    symbolCounts.set(symbol, count + 1);
    // Always (re)emit so the caller gets a fresh snapshot seed even when the
    // room was already open for another consumer (idempotent server-side).
    emitWhenConnected("subscribe", { symbols: [symbol] });
  }
}

function release(symbols: readonly string[]) {
  for (const symbol of symbols) {
    const count = symbolCounts.get(symbol) ?? 0;
    if (count <= 1) {
      symbolCounts.delete(symbol);
      emitWhenConnected("unsubscribe", { symbols: [symbol] });
    } else {
      symbolCounts.set(symbol, count - 1);
    }
  }
}

/**
 * Live quotes for `symbols`. The list is keyed by its joined content, so
 * callers may pass inline arrays — only the actual symbol set drives
 * subscribe/unsubscribe diffing.
 */
export function useQuoteSocket(symbols: readonly string[]): {
  quotes: Record<string, TickQuote>;
  connected: boolean;
  rttMs: number | null;
} {
  const [quotes, setQuotes] = useState<Record<string, TickQuote>>({});
  const { connected, rttMs } = useSocketStatus();

  const symbolKey = symbols.join(",");
  const pending = useRef<Map<string, TickQuote>>(new Map());
  const wantedRef = useRef<readonly string[]>([]);

  // Listeners + ~10Hz batch flush (mounted once per consumer).
  useEffect(() => {
    void getSocket(); // ensure the shared connection is being established
    const onSnapshot = (payload: SnapshotPayload) => {
      for (const q of payload.quotes ?? []) pending.current.set(q.symbol, q);
    };
    const onTick = (q: TickQuote) => {
      pending.current.set(q.symbol, q);
    };
    snapshotListeners.add(onSnapshot);
    tickListeners.add(onTick);

    // Batch merge at ~10Hz — coalesces the 500ms tick storm into
    // at most one re-render per interval per consumer.
    const iv = setInterval(() => {
      if (pending.current.size === 0) return;
      const wanted = new Set(wantedRef.current);
      const batch = Array.from(pending.current.values()).filter((q) =>
        wanted.has(q.symbol)
      );
      pending.current.clear();
      if (batch.length === 0) return;
      setQuotes((prev) => {
        let changed = false;
        const next = { ...prev };
        for (const q of batch) {
          const existing = next[q.symbol];
          if (
            !existing ||
            existing.lastPriceCents !== q.lastPriceCents ||
            existing.ts !== q.ts
          ) {
            next[q.symbol] = q;
            changed = true;
          }
        }
        return changed ? next : prev;
      });
    }, 100);

    return () => {
      snapshotListeners.delete(onSnapshot);
      tickListeners.delete(onTick);
      clearInterval(iv);
    };
  }, []);

  // Subscribe/unsubscribe diffing — keyed by joined symbol content.
  useEffect(() => {
    const nextSymbols = symbolKey.length > 0 ? symbolKey.split(",") : [];
    const previous = wantedRef.current;

    const previousSet = new Set(previous);
    const nextSet = new Set(nextSymbols);
    const added = nextSymbols.filter((s) => !previousSet.has(s));
    const removed = previous.filter((s) => !nextSet.has(s));

    acquire(added);
    release(removed);
    wantedRef.current = nextSymbols;

    return () => {
      // Final teardown (StrictMode-safe): release exactly what this run acquired.
      release(wantedRef.current);
      wantedRef.current = [];
    };
  }, [symbolKey]);

  return { quotes, connected, rttMs };
}

/* ------------------------------------------------------------------ */
/* useUserEvents — authed user room: orders, alerts, portfolio nudges  */
/* ------------------------------------------------------------------ */

/**
 * Joins the `user:{id}` room while `enabled` (authed + approved user):
 * fetches a short-lived WS ticket, emits `auth-user`, re-auths on reconnect
 * and every 100s (ticket TTL is 120s). Handles order-update toasts, price
 * alert toasts, notification toasts (Phase 4 bell) and portfolio/order/
 * alert/notification cache invalidation.
 */
export function useUserEvents(enabled: boolean) {
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!enabled) return;
    let disposed = false;
    let sock: Socket | null = null;

    const invalidateTradingCaches = () => {
      void queryClient.invalidateQueries({ queryKey: ["portfolio"] });
      void queryClient.invalidateQueries({ queryKey: ["orders"] });
    };

    const authenticate = async () => {
      try {
        const { ticket } = await apiFetch<WsTicketResponse>("/api/ws-ticket");
        if (!disposed && sock?.connected) {
          sock.emit("auth-user", { token: ticket });
        }
      } catch {
        // 401/offline — retried by the interval and on the next reconnect.
      }
    };

    const onOrderUpdate = (payload: { order: OrderDTO }) => {
      const order = payload?.order;
      if (!order) return;
      if (order.status === "FILLED") {
        toast.success(
          `Order filled · ${order.side} ${order.filledQty} ${order.symbol} @ ${formatInr(order.avgFillPriceCents)}`
        );
      } else if (order.status === "REJECTED") {
        toast.error(
          `Order rejected — ${order.rejectReason ?? "risk check failed"}`
        );
      } else if (order.status === "CANCELED") {
        toast.info("Order cancelled");
      } else {
        return; // NEW / PARTIALLY_FILLED confirmations are silent
      }
      invalidateTradingCaches();
    };

    const onAlert = (payload: AlertEventPayload) => {
      const alert = payload?.alert;
      if (!alert) return;
      toast.info(`Price alert · ${alert.symbol}`, {
        description: `Crossed ${alert.condition} ${formatInr(alert.targetCents)}`,
      });
      void queryClient.invalidateQueries({ queryKey: ALERTS_KEY });
    };

    // Phase 4 §8c — every lifecycle event lands here; the bell badge updates
    // instantly and the toast mirrors the notification body.
    const onNotification = (payload: NotificationEventPayload) => {
      const notification = payload?.notification;
      if (!notification) return;
      toast.info(notification.title, {
        description: notification.body,
      });
      void queryClient.invalidateQueries({ queryKey: NOTIFICATIONS_KEY });
    };

    const onPortfolioNudge = () => invalidateTradingCaches();
    const onConnect = () => void authenticate();

    orderListeners.add(onOrderUpdate);
    alertListeners.add(onAlert);
    notificationListeners.add(onNotification);
    nudgeListeners.add(onPortfolioNudge);
    connectListeners.add(onConnect);

    void getSocket().then((s) => {
      if (disposed) return;
      sock = s;
      if (s.connected) void authenticate();
    });

    // Ticket TTL is 120s — re-fetch and re-auth every 100s while enabled.
    const iv = setInterval(() => {
      void authenticate();
    }, 100_000);

    return () => {
      disposed = true;
      orderListeners.delete(onOrderUpdate);
      alertListeners.delete(onAlert);
      notificationListeners.delete(onNotification);
      nudgeListeners.delete(onPortfolioNudge);
      connectListeners.delete(onConnect);
      clearInterval(iv);
    };
  }, [enabled, queryClient]);
}

/* ------------------------------------------------------------------ */
/* useDepth — order-book depth for one symbol (instrument detail)      */
/* ------------------------------------------------------------------ */

/**
 * Watches the depth room for `symbol` while it is non-null (dialog open).
 * Returns the latest 5×5 DepthSnapshot (~1s cadence).
 */
export function useDepth(symbol: string | null): DepthSnapshot | null {
  // Snapshot is stored with the symbol it belongs to so the return value is
  // derived — no setState needed when the watched symbol is cleared.
  const [latest, setLatest] = useState<{
    symbol: string;
    snapshot: DepthSnapshot;
  } | null>(null);

  useEffect(() => {
    if (!symbol) return;
    void getSocket(); // ensure the shared connection exists
    const onDepth = (snapshot: DepthSnapshot) => {
      if (snapshot?.symbol === symbol) setLatest({ symbol, snapshot });
    };
    depthListeners.add(onDepth);
    depthSymbols.add(symbol);
    emitWhenConnected("watch-depth", { symbol });

    return () => {
      depthListeners.delete(onDepth);
      depthSymbols.delete(symbol);
      emitWhenConnected("unwatch-depth", { symbol });
    };
  }, [symbol]);

  return latest && latest.symbol === symbol ? latest.snapshot : null;
}

/* ------------------------------------------------------------------ */
/* useFlash — brief green/red flash when a price changes               */
/* ------------------------------------------------------------------ */

export type FlashDirection = "up" | "down" | null;

/**
 * Returns "up"/"down" for ~400ms after `value` changes (sign of the delta),
 * then null. Class-swap friendly: `<span className={cn(flash === "up" && "bg-profit/15")}>`.
 * Disabled entirely when the user prefers reduced motion.
 */
export function useFlash(value: number | undefined, ms = 400): FlashDirection {
  const reducedMotion = useReducedMotion();
  const [direction, setDirection] = useState<FlashDirection>(null);
  const previous = useRef<number | undefined>(undefined);

  useEffect(() => {
    if (value === undefined) return;
    const before = previous.current;
    previous.current = value;
    if (before === undefined || before === value || reducedMotion) return;
    const next = value > before ? "up" : "down";
    // rAF/timeout callbacks keep setState out of the effect body itself.
    const raf = requestAnimationFrame(() => setDirection(next));
    const timer = setTimeout(() => setDirection(null), ms);
    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(timer);
    };
  }, [value, ms, reducedMotion]);

  return direction;
}
