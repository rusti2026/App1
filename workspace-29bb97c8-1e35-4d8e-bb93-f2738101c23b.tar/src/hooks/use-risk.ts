"use client";

/**
 * Risk-console hooks (Phase 4 §8d, ADMIN only): kill-switch status + toggle.
 * - Status polls gently (15s) so a toggle from another admin session shows up.
 * - Toggle POSTs `{ killSwitch }` (audited server-side), toasts the outcome
 *   and invalidates the status cache.
 * The endpoints answer 403 ROLE_REQUIRED for non-admins — the UI only mounts
 * them for ADMIN users, and status polling disables retry to stay quiet.
 */

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiFetch } from "@/lib/api-client";
import type { RiskStatusResponse, RiskToggleResponse } from "@/lib/types";

export const RISK_KEY = ["risk"] as const;

/** Kill-switch status — `enabled` gate lets the dashboard poll only for admins. */
export function useRiskStatus(enabled = true) {
  return useQuery<RiskStatusResponse>({
    queryKey: RISK_KEY,
    queryFn: () => apiFetch<RiskStatusResponse>("/api/admin/risk"),
    refetchInterval: 15_000,
    retry: false,
    enabled,
  });
}

/** POST /api/admin/risk — `{ killSwitch: boolean }`. Toasts + invalidates. */
export function useToggleKillSwitch() {
  const queryClient = useQueryClient();
  return useMutation<RiskToggleResponse, Error, boolean>({
    mutationFn: (killSwitch) =>
      apiFetch<RiskToggleResponse>("/api/admin/risk", {
        method: "POST",
        json: { killSwitch },
      }),
    onSuccess: (data) => {
      toast.success(
        data.killSwitch
          ? "Trading paused — kill switch is ON"
          : "Trading resumed — kill switch is OFF"
      );
      void queryClient.invalidateQueries({ queryKey: RISK_KEY });
    },
    onError: (error) => {
      toast.error("Could not update the kill switch", {
        description: error instanceof Error ? error.message : undefined,
      });
    },
  });
}
