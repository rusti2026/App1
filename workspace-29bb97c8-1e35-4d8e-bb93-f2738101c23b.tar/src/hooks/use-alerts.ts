"use client";

/**
 * Price-alert REST hooks (Phase 3): list, create, cancel.
 * - List polls gently (15s) so TRIGGERED flips show up even without WS.
 * - WS `alert` events (use-quotes) invalidate the same ["alerts"] cache.
 * - Cancel removes the alert optimistically and rolls back on failure.
 */

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiFetch } from "@/lib/api-client";
import type { AlertsResponse, CreateAlertPayload } from "@/lib/types";

export const ALERTS_KEY = ["alerts"] as const;

/** Active + triggered alerts for the signed-in user. */
export function useAlerts() {
  return useQuery<AlertsResponse>({
    queryKey: ALERTS_KEY,
    queryFn: () => apiFetch<AlertsResponse>("/api/alerts"),
    refetchInterval: 15_000,
  });
}

/** POST /api/alerts — success toast + cache invalidation; error surfaces to the caller. */
export function useCreateAlert() {
  const queryClient = useQueryClient();
  return useMutation<unknown, Error, CreateAlertPayload>({
    mutationFn: (payload) =>
      apiFetch<unknown>("/api/alerts", { method: "POST", json: payload }),
    onSuccess: (_data, variables) => {
      toast.success(`Alert set for ${variables.symbol}`);
      void queryClient.invalidateQueries({ queryKey: ALERTS_KEY });
    },
  });
}

/** DELETE /api/alerts?id=… — optimistic removal + rollback. */
export function useCancelAlert() {
  const queryClient = useQueryClient();
  return useMutation<
    unknown,
    Error,
    string,
    { previous?: AlertsResponse }
  >({
    mutationFn: (alertId) =>
      apiFetch<unknown>(`/api/alerts?id=${encodeURIComponent(alertId)}`, {
        method: "DELETE",
      }),
    onMutate: async (alertId) => {
      await queryClient.cancelQueries({ queryKey: ALERTS_KEY });
      const previous = queryClient.getQueryData<AlertsResponse>(ALERTS_KEY);
      if (previous) {
        queryClient.setQueryData<AlertsResponse>(ALERTS_KEY, {
          alerts: previous.alerts.filter((a) => a.id !== alertId),
        });
      }
      return { previous };
    },
    onError: (error, _alertId, context) => {
      if (context?.previous) {
        queryClient.setQueryData(ALERTS_KEY, context.previous);
      }
      toast.error("Could not cancel alert", {
        description: error instanceof Error ? error.message : undefined,
      });
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ALERTS_KEY });
    },
  });
}
