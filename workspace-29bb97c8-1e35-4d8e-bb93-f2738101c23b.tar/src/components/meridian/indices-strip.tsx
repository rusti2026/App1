"use client";

/**
 * Live index strip — NIFTY 50 · BANK NIFTY · SENSEX chips fed by the shared
 * quote socket (§6a). Rendered as a second row inside the sticky header.
 * Collapses to a horizontally scrollable row on small screens.
 */

import { INDEX_SYMBOLS, useQuoteSocket, useSocketStatus } from "@/hooks/use-quotes";
import { formatPts, formatSignedPct, trendGlyph } from "@/components/meridian/format";
import { cn } from "@/lib/utils";

const INDEX_LABELS: Record<string, string> = {
  NIFTY50: "NIFTY 50",
  BANKNIFTY: "BANK NIFTY",
  SENSEX: "SENSEX",
};

export function IndicesStrip() {
  const { quotes } = useQuoteSocket(INDEX_SYMBOLS);
  const { connected } = useSocketStatus();

  return (
    <div
      className="border-t border-border/60 bg-card/40"
      role="status"
      aria-label="Live index quotes"
    >
      <ul className="thin-scroll mx-auto flex w-full max-w-6xl items-center gap-2 overflow-x-auto px-4 py-1.5 md:gap-3">
        {INDEX_SYMBOLS.map((symbol) => {
          const quote = quotes[symbol];
          const pct = quote?.changePct ?? 0;
          return (
            <li
              key={symbol}
              className="flex shrink-0 items-center gap-2 rounded-md border border-border/60 bg-background/60 px-2.5 py-1"
            >
              <span
                aria-hidden="true"
                className={cn(
                  "relative flex size-1.5",
                  connected ? "" : "opacity-40"
                )}
              >
                {connected ? (
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-profit opacity-60 motion-reduce:animate-none" />
                ) : null}
                <span
                  className={cn(
                    "relative inline-flex size-1.5 rounded-full",
                    connected ? "bg-profit" : "bg-loss"
                  )}
                />
              </span>
              <span className="font-mono text-[11px] font-semibold tracking-wider text-foreground">
                {INDEX_LABELS[symbol] ?? symbol}
              </span>
              <span className="font-mono text-[11px] tabular-nums text-muted-foreground">
                {quote ? formatPts(quote.lastPriceCents) : "—"}
              </span>
              <span
                className={cn(
                  "font-mono text-[11px] tabular-nums",
                  pct > 0 ? "text-profit" : pct < 0 ? "text-loss" : "text-muted-foreground"
                )}
              >
                {quote ? `${trendGlyph(pct)} ${formatSignedPct(pct)}` : "—"}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
