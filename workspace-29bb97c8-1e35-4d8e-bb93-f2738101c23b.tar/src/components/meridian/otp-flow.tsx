"use client";

import { useEffect, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowLeft, Copy } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { FormField } from "@/components/meridian/form-field";
import { useOtpRequest, useOtpVerify } from "@/hooks/use-auth";
import type { OtpChannel, OtpRequestResponse } from "@/lib/types";

/**
 * One-time-code flow (request → verify), reused by:
 *  - the auth view ("Sign in with a one-time code")
 *  - the dashboard security center (phone verification dialog)
 * The sandbox exposes `devCode` directly — shown in an amber banner.
 */
export function OtpFlow({
  onVerified,
  onCancel,
}: {
  onVerified: (result: { channel: OtpChannel; destination: string }) => void;
  onCancel?: () => void;
}) {
  const reducedMotion = useReducedMotion();
  const otpRequest = useOtpRequest();
  const otpVerify = useOtpVerify();

  const [step, setStep] = useState<"request" | "verify">("request");
  const [channel, setChannel] = useState<OtpChannel>("EMAIL");
  const [destination, setDestination] = useState("");
  const [destinationError, setDestinationError] = useState<string | undefined>();
  const [challenge, setChallenge] = useState<OtpRequestResponse | null>(null);
  const [code, setCode] = useState("");
  const [verifyError, setVerifyError] = useState<string | null>(null);
  const [attempts, setAttempts] = useState(0);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const secondsLeft = challenge
    ? Math.max(0, Math.floor((Date.parse(challenge.expiresAt) - now) / 1000))
    : 0;
  const expired = challenge !== null && secondsLeft <= 0;

  const destinationValid =
    channel === "EMAIL"
      ? /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(destination.trim())
      : /^\+?[\d\s().-]{7,20}$/.test(destination.trim());

  const handleRequest = (event: React.FormEvent) => {
    event.preventDefault();
    if (!destinationValid) {
      setDestinationError(
        channel === "EMAIL"
          ? "Enter a valid email address."
          : "Enter a valid phone number (e.g. +1 555 000 1234)."
      );
      return;
    }
    setDestinationError(undefined);
    otpRequest.mutate(
      { channel, destination: destination.trim() },
      {
        onSuccess: (res) => {
          setChallenge(res);
          setCode("");
          setVerifyError(null);
          setAttempts(0);
          setStep("verify");
        },
        onError: (error) => {
          toast.error("Could not send code", {
            description: error instanceof Error ? error.message : undefined,
          });
        },
      }
    );
  };

  const handleVerify = () => {
    if (!challenge || code.length !== 6) return;
    otpVerify.mutate(
      { challengeId: challenge.challengeId, code },
      {
        onSuccess: () => {
          toast.success(channel === "SMS" ? "Phone verified" : "Email verified");
          onVerified({ channel, destination: destination.trim() });
        },
        onError: (error) => {
          setAttempts((a) => a + 1);
          setVerifyError(
            error instanceof Error ? error.message : "That code didn't match."
          );
          setCode("");
        },
      }
    );
  };

  if (step === "request") {
    return (
      <form onSubmit={handleRequest} className="space-y-4" noValidate>
        <div className="space-y-1.5">
          <p className="text-sm font-medium">Sign in with a one-time code</p>
          <p className="text-xs text-muted-foreground">
            We&apos;ll send a 6-digit code to verify your identity. In this
            sandbox the code is shown on screen.
          </p>
        </div>

        <FormField id="otp-channel" label="Channel">
          <Select
            value={channel}
            onValueChange={(value) => setChannel(value as OtpChannel)}
          >
            <SelectTrigger id="otp-channel" className="h-11 w-full" aria-label="Delivery channel">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="EMAIL">Email</SelectItem>
              <SelectItem value="SMS">SMS</SelectItem>
            </SelectContent>
          </Select>
        </FormField>

        <FormField
          id="otp-destination"
          label={channel === "EMAIL" ? "Email address" : "Phone number"}
          error={destinationError}
        >
          <Input
            id="otp-destination"
            className="h-11"
            type={channel === "EMAIL" ? "email" : "tel"}
            inputMode={channel === "EMAIL" ? "email" : "tel"}
            autoComplete={channel === "EMAIL" ? "email" : "tel"}
            placeholder={channel === "EMAIL" ? "you@example.com" : "+1 555 000 1234"}
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            aria-invalid={!!destinationError}
          />
        </FormField>

        <div className="flex flex-col gap-2 pt-1 sm:flex-row">
          <Button
            type="submit"
            className="h-11 flex-1"
            disabled={otpRequest.isPending}
            aria-label="Send one-time code"
          >
            {otpRequest.isPending ? "Sending…" : "Send code"}
          </Button>
          {onCancel ? (
            <Button
              type="button"
              variant="ghost"
              className="h-11"
              onClick={onCancel}
            >
              Cancel
            </Button>
          ) : null}
        </div>
      </form>
    );
  }

  return (
    <div className="space-y-4">
      <div className="space-y-1.5">
        <p className="text-sm font-medium">Enter your 6-digit code</p>
        <p className="text-xs text-muted-foreground">
          Sent via {channel === "EMAIL" ? "email" : "SMS"} to{" "}
          <span className="font-mono">{destination}</span>
        </p>
      </div>

      {challenge?.devCode ? (
        <div className="flex items-center justify-between gap-3 rounded-md border border-terminal/40 bg-terminal/10 px-3 py-2.5">
          <p className="text-xs text-foreground">
            <span className="font-semibold uppercase tracking-wide text-terminal">
              Dev mode:
            </span>{" "}
            your code is{" "}
            <code className="font-mono text-sm font-bold text-terminal">
              {challenge.devCode}
            </code>
          </p>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="size-9 shrink-0"
            aria-label="Copy code to clipboard"
            onClick={() => {
              void navigator.clipboard
                .writeText(challenge.devCode)
                .then(() => toast.success("Code copied"))
                .catch(() => toast.error("Copy failed"));
            }}
          >
            <Copy className="size-4" aria-hidden="true" />
          </Button>
        </div>
      ) : null}

      <motion.div
        key={attempts}
        animate={
          !reducedMotion && attempts > 0
            ? { x: [0, -10, 10, -6, 6, -2, 0] }
            : undefined
        }
        transition={{ duration: 0.4 }}
        className="flex justify-center py-1"
      >
        <InputOTP
          maxLength={6}
          value={code}
          onChange={(value) => {
            setCode(value);
            setVerifyError(null);
          }}
          aria-label="6-digit verification code"
        >
          <InputOTPGroup>
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <InputOTPSlot key={i} index={i} className="size-11 text-base" />
            ))}
          </InputOTPGroup>
        </InputOTP>
      </motion.div>

      {verifyError ? (
        <p role="alert" className="text-center text-xs font-medium text-loss">
          {verifyError}
        </p>
      ) : null}

      <p className="text-center font-mono text-xs tabular-nums text-muted-foreground">
        {expired
          ? "Code expired — send a new one."
          : `Expires in ${String(Math.floor(secondsLeft / 60)).padStart(2, "0")}:${String(secondsLeft % 60).padStart(2, "0")}`}
      </p>

      <div className="flex flex-col gap-2 sm:flex-row">
        <Button
          type="button"
          className="h-11 flex-1"
          disabled={otpVerify.isPending || code.length !== 6 || expired}
          onClick={handleVerify}
          aria-label="Verify code"
        >
          {otpVerify.isPending ? "Verifying…" : "Verify"}
        </Button>
        <Button
          type="button"
          variant="ghost"
          className="h-11"
          onClick={() => {
            setStep("request");
            setChallenge(null);
            setCode("");
            setVerifyError(null);
          }}
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Change destination
        </Button>
      </div>
    </div>
  );
}
