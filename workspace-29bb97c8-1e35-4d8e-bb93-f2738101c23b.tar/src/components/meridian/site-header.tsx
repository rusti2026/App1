"use client";

import { useState } from "react";
import {
  ArrowUpRight,
  Bell,
  BellRing,
  GitBranch,
  Info,
  LogOut,
  Menu,
  ShieldAlert,
  Split,
  X,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";

import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useMarkNotificationsRead,
  useNotifications,
} from "@/hooks/use-notifications";
import { useLogout } from "@/hooks/use-session";
import { Logo } from "@/components/meridian/logo";
import { ThemeToggle } from "@/components/meridian/theme-toggle";
import { IndicesStrip } from "@/components/meridian/indices-strip";
import { initialsOf, relativeTime } from "@/components/meridian/format";
import { useAppStore } from "@/store/app-store";
import { cn } from "@/lib/utils";
import type { NotificationType, SessionUser } from "@/lib/types";

export function SiteHeader({ user }: { user?: SessionUser | null }) {
  const openAuth = useAppStore((s) => s.openAuth);
  const setView = useAppStore((s) => s.setView);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-2 px-4">
        <button
          type="button"
          aria-label="MERIDIAN home"
          className="rounded-md outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
          onClick={() => setView(user ? "dashboard" : "landing")}
        >
          <Logo />
        </button>

        <div className="flex items-center gap-1.5 md:gap-2">
          <ThemeToggle />

          {user ? <NotificationBell /> : null}

          {user ? (
            <UserMenu user={user} />
          ) : (
            <>
              {/* Desktop CTAs */}
              <div className="hidden items-center gap-2 sm:flex">
                <Button
                  variant="ghost"
                  className="h-10 px-4"
                  onClick={() => openAuth("login")}
                >
                  Log in
                </Button>
                <Button className="h-10 px-4" onClick={() => openAuth("signup")}>
                  Get started
                </Button>
              </div>

              {/* Mobile menu */}
              <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
                <SheetTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-11 sm:hidden"
                    aria-label="Open menu"
                  >
                    <Menu className="size-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-72">
                  <SheetHeader>
                    <SheetTitle>
                      <Logo />
                    </SheetTitle>
                  </SheetHeader>
                  <div className="flex flex-col gap-2 px-4">
                    <Button
                      variant="outline"
                      className="h-11"
                      onClick={() => {
                        setMenuOpen(false);
                        openAuth("login");
                      }}
                    >
                      Log in
                    </Button>
                    <Button
                      className="h-11"
                      onClick={() => {
                        setMenuOpen(false);
                        openAuth("signup");
                      }}
                    >
                      Get started
                    </Button>
                    <p className="mt-4 text-xs text-muted-foreground">
                      Paper-trading simulation — not investment advice.
                    </p>
                  </div>
                </SheetContent>
              </Sheet>
            </>
          )}
        </div>
      </div>

      <IndicesStrip />
    </header>
  );
}

/* ---------------- notification bell (Phase 4 §8c) ---------------- */

function NotificationBell() {
  const { data, isPending, isError } = useNotifications();
  const markRead = useMarkNotificationsRead();
  const [open, setOpen] = useState(false);

  const notifications = data?.notifications ?? [];
  const unread = data?.unread ?? 0;

  // Opening the panel with unread items marks everything read — the badge
  // clears as soon as the user has seen the feed (per-item clicks still mark
  // individual rows for notifications that arrive while the panel is open).
  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next && unread > 0) markRead.mutate({ all: true });
  };

  return (
    <Popover open={open} onOpenChange={handleOpenChange}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative size-11 md:size-10"
          aria-label={`Notifications${unread > 0 ? ` — ${unread} unread` : ""}`}
        >
          <Bell className="size-4" aria-hidden="true" />
          {unread > 0 ? (
            <span
              className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-loss px-1 font-mono text-[9px] font-semibold leading-none text-white"
              aria-hidden="true"
            >
              {unread > 9 ? "9+" : unread}
            </span>
          ) : null}
        </Button>
      </PopoverTrigger>
      <PopoverContent
        align="end"
        className="w-80 p-0 sm:w-88"
        aria-label="Notifications"
      >
        <div className="flex items-center justify-between gap-2 border-b border-border/60 px-4 py-3">
          <p className="text-sm font-semibold">Notifications</p>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 px-2 text-xs text-muted-foreground"
            disabled={unread === 0 || markRead.isPending}
            onClick={() => markRead.mutate({ all: true })}
          >
            Mark all read
          </Button>
        </div>

        {isPending ? (
          <div className="space-y-3 p-4" aria-hidden="true">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex gap-2.5">
                <Skeleton className="size-4 shrink-0 rounded-full" />
                <div className="min-w-0 flex-1 space-y-1.5">
                  <Skeleton className="h-3.5 w-3/4" />
                  <Skeleton className="h-3 w-full" />
                  <Skeleton className="h-3 w-1/3" />
                </div>
              </div>
            ))}
          </div>
        ) : isError ? (
          <p role="alert" className="px-4 py-8 text-sm text-loss">
            Couldn&apos;t load notifications — retrying…
          </p>
        ) : notifications.length === 0 ? (
          <div className="flex flex-col items-center gap-1.5 px-4 py-10 text-center">
            <Bell className="size-5 text-muted-foreground/50" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">
              No notifications yet — order updates and alerts land here.
            </p>
          </div>
        ) : (
          <ul
            className="thin-scroll max-h-96 divide-y divide-border/60 overflow-y-auto"
            aria-label="Notification list"
          >
            {notifications.map((notification) => {
              const { Icon, className } = notificationIcon(notification.type);
              const isUnread = !notification.readAt;
              return (
                <li key={notification.id}>
                  <button
                    type="button"
                    className={cn(
                      "flex w-full items-start gap-2.5 px-4 py-3 text-left transition-colors focus-visible:bg-accent/50 focus-visible:outline-none",
                      isUnread ? "bg-muted/40 hover:bg-accent/50" : "hover:bg-accent/50"
                    )}
                    onClick={() => {
                      if (isUnread) markRead.mutate({ ids: [notification.id] });
                    }}
                    aria-label={`${notification.title}${isUnread ? " — mark as read" : ""}`}
                  >
                    <Icon
                      className={cn("mt-0.5 size-4 shrink-0", className)}
                      aria-hidden="true"
                    />
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-2">
                        <span
                          className={cn(
                            "min-w-0 flex-1 truncate text-sm",
                            isUnread ? "font-medium" : "text-muted-foreground"
                          )}
                        >
                          {notification.title}
                        </span>
                        {isUnread ? (
                          <span
                            aria-hidden="true"
                            className="size-1.5 shrink-0 rounded-full bg-terminal"
                          />
                        ) : null}
                      </span>
                      <span className="mt-0.5 line-clamp-2 block text-xs text-muted-foreground">
                        {notification.body}
                      </span>
                      <span className="mt-1 block font-mono text-[10px] text-muted-foreground">
                        {relativeTime(notification.createdAt)}
                      </span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </PopoverContent>
    </Popover>
  );
}

/** Type → icon + token color (profit/loss/terminal only — never cool hues). */
function notificationIcon(type: NotificationType): {
  Icon: LucideIcon;
  className: string;
} {
  switch (type) {
    case "ORDER_FILLED":
      return { Icon: ArrowUpRight, className: "text-profit" };
    case "ORDER_REJECTED":
    case "ORDER_CANCELLED":
      return { Icon: X, className: "text-loss" };
    case "LEG_CREATED":
      return { Icon: GitBranch, className: "text-muted-foreground" };
    case "OCO_COMPLETED":
      return { Icon: Split, className: "text-muted-foreground" };
    case "ALERT_TRIGGERED":
      return { Icon: BellRing, className: "text-terminal" };
    case "RISK":
      return { Icon: ShieldAlert, className: "text-loss" };
    default:
      return { Icon: Info, className: "text-muted-foreground" };
  }
}

function UserMenu({ user }: { user: SessionUser }) {
  const resetToLanding = useAppStore((s) => s.resetToLanding);
  const logout = useLogout();

  const handleSignOut = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        resetToLanding();
        toast.success("Signed out");
      },
      onError: (error) => {
        // Even on failure, drop the local session view — server is the truth.
        resetToLanding();
        toast.error("Sign out failed", {
          description: error instanceof Error ? error.message : undefined,
        });
      },
    });
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className="size-11 rounded-full p-0 md:size-10"
          aria-label="Account menu"
        >
          <Avatar className="size-8">
            <AvatarFallback className="bg-secondary text-xs font-semibold">
              {initialsOf(user.name || user.email)}
            </AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <DropdownMenuLabel className="flex flex-col gap-1">
          <span className="truncate text-sm font-medium">{user.email}</span>
          <span className="flex items-center gap-2">
            <Badge
              variant="outline"
              className={
                user.role === "ADMIN"
                  ? "border-terminal/40 bg-terminal/10 text-terminal"
                  : "text-muted-foreground"
              }
            >
              {user.role}
            </Badge>
            {user.mfaEnabled ? (
              <Badge variant="outline" className="border-profit/40 bg-profit/10 text-profit">
                MFA
              </Badge>
            ) : null}
          </span>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          variant="destructive"
          className="h-11"
          disabled={logout.isPending}
          onSelect={handleSignOut}
        >
          <LogOut className="size-4" aria-hidden="true" />
          Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
