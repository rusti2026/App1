/**
 * MERIDIAN — display formatters. All money is integer minor units over the wire
 * (paise for INR wallets). Formatters are deterministic (explicit en-IN locale)
 * and only ever render inside client-fetched data views, so there are no
 * hydration hazards.
 */

import { formatDistanceToNow, parseISO } from "date-fns";

const inr = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const inNum = new Intl.NumberFormat("en-IN", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

/** 295120 → "₹2,951.20" (Indian digit grouping) · -12345 → "-₹123.45" */
export function formatInr(paise: number): string {
  return inr.format(paise / 100);
}

/** 295120 → "+₹2,951.20" · -12345 → "−₹123.45" (U+2212 minus for mono alignment) */
export function formatSignedInr(paise: number): string {
  if (paise > 0) return `+${inr.format(paise / 100)}`;
  if (paise < 0) return `\u2212${inr.format(Math.abs(paise) / 100)}`;
  return inr.format(0);
}

/** Index points: 2485055 → "24,850.55" (no currency symbol) */
export function formatPts(paise: number): string {
  return inNum.format(paise / 100);
}

/** 2485055 → "+24,850.55" · negative → "−..." */
export function formatSignedPts(paise: number): string {
  if (paise > 0) return `+${inNum.format(paise / 100)}`;
  if (paise < 0) return `\u2212${inNum.format(Math.abs(paise) / 100)}`;
  return inNum.format(0);
}

/** 1.24 → "+1.24%" · -0.87 → "−0.87%" */
export function formatSignedPct(pct: number): string {
  const abs = Math.abs(pct).toFixed(2);
  if (pct > 0) return `+${abs}%`;
  if (pct < 0) return `\u2212${abs}%`;
  return "0.00%";
}

/** ▲ for non-negative, ▼ for negative. */
export function trendGlyph(value: number): string {
  return value >= 0 ? "\u25B2" : "\u25BC";
}

/** Compact volume: 1_234_567 → "1.23M" · 45_200 → "45.2K". */
export function formatVolume(volume: number): string {
  if (volume >= 1_000_000) return `${(volume / 1_000_000).toFixed(2)}M`;
  if (volume >= 1_000) return `${(volume / 1_000).toFixed(1)}K`;
  return String(volume);
}

/** Relative time like "3 minutes ago"; empty string when missing/invalid. */
export function relativeTime(iso: string | undefined): string {
  if (!iso) return "";
  try {
    const date = parseISO(iso);
    if (Number.isNaN(date.getTime())) return "";
    return formatDistanceToNow(date, { addSuffix: true });
  } catch {
    return "";
  }
}

/** ISO → "14:00" (local 24h clock). Empty string when missing/invalid. */
export function formatTimeHM(iso: string | undefined | null): string {
  if (!iso) return "";
  try {
    const date = parseISO(iso);
    if (Number.isNaN(date.getTime())) return "";
    return new Intl.DateTimeFormat("en-IN", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(date);
  } catch {
    return "";
  }
}

/** ISO → "12 May" (local day + short month). Empty string when missing/invalid. */
export function formatDateShort(iso: string | undefined | null): string {
  if (!iso) return "";
  try {
    const date = parseISO(iso);
    if (Number.isNaN(date.getTime())) return "";
    return new Intl.DateTimeFormat("en-IN", {
      day: "numeric",
      month: "short",
    }).format(date);
  } catch {
    return "";
  }
}

/** "jane@acme.com" → "JA" (avatar fallback initials). */
export function initialsOf(nameOrEmail: string): string {
  const source = nameOrEmail.trim();
  if (!source) return "·";
  const parts = source.split(/[\s@._-]+/).filter(Boolean);
  const first = parts[0]?.[0] ?? source[0];
  const second = parts[1]?.[0];
  return (second ? `${first}${second}` : `${first}${source[1] ?? ""}`).toUpperCase();
}
