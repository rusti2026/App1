import { cn } from "@/lib/utils";

/**
 * MERIDIAN wordmark: square glyph with ▲ tick motif + letterspaced caps.
 * The square uses foreground/background so it inverts correctly per theme.
 */
export function Logo({
  className,
  markClassName,
  showWordmark = true,
}: {
  className?: string;
  markClassName?: string;
  showWordmark?: boolean;
}) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <span
        aria-hidden="true"
        className={cn(
          "flex size-8 items-center justify-center rounded-md bg-foreground text-background shadow-sm",
          markClassName
        )}
      >
        <svg viewBox="0 0 12 12" className="size-3 fill-current" role="img">
          <path d="M6 1.2 11.2 10.4H0.8Z" />
        </svg>
      </span>
      {showWordmark ? (
        <span className="text-sm font-semibold uppercase tracking-[0.35em]">
          MERIDIAN
        </span>
      ) : null}
    </span>
  );
}
