"use client";

import { useSocketStatus } from "@/hooks/use-quotes";
import { cn } from "@/lib/utils";

export function SiteFooter() {
  const { connected, rttMs } = useSocketStatus();

  return (
    <footer className="mt-auto border-t border-border/60">
      <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-3 px-4 py-6 pb-[max(env(safe-area-inset-bottom),1rem)] sm:flex-row">
        <p className="text-center text-xs text-muted-foreground sm:text-left">
          © 2025 MERIDIAN (demo). Paper-trading simulation — not investment
          advice.
        </p>

        <div className="flex flex-col items-center gap-3 sm:flex-row sm:items-center">
          <p
            role="status"
            aria-label="Market data connection status"
            className="flex items-center gap-2 font-mono text-[11px] tabular-nums text-muted-foreground"
          >
            <span aria-hidden="true" className="relative flex size-2">
              {connected ? (
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-profit opacity-60 motion-reduce:animate-none" />
              ) : null}
              <span
                className={cn(
                  "relative inline-flex size-2 rounded-full",
                  connected ? "bg-profit" : "bg-loss"
                )}
              />
            </span>
            <span>{connected ? `${rttMs ?? "—"} ms` : "offline"}</span>
            <span className="hidden md:inline">· Simulated NSE feed</span>
          </p>

          <nav aria-label="Legal">
            <ul className="flex items-center gap-4 text-xs text-muted-foreground">
              <li>
                <a href="#" className="transition-colors hover:text-foreground">
                  Privacy
                </a>
              </li>
              <li>
                <a href="#" className="transition-colors hover:text-foreground">
                  Terms
                </a>
              </li>
              <li>
                <a href="#" className="transition-colors hover:text-foreground">
                  Disclosures
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </footer>
  );
}

export default SiteFooter;
