"use client";

import { useEffect, useMemo, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Plus, ShieldAlert } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertsCard } from "@/components/meridian/dashboard/alerts-card";
import { LedgerCard } from "@/components/meridian/dashboard/ledger-card";
import { InstrumentDetailDialog } from "@/components/meridian/dashboard/instrument-detail";
import { MarketMoversCard } from "@/components/meridian/dashboard/market-movers-card";
import { OrdersCard } from "@/components/meridian/dashboard/orders-card";
import { PositionsCard } from "@/components/meridian/dashboard/positions-card";
import { RiskConsoleCard } from "@/components/meridian/dashboard/risk-console-card";
import { ScreenerCard } from "@/components/meridian/dashboard/screener-card";
import { SecurityCard } from "@/components/meridian/dashboard/security-card";
import { SummaryCards } from "@/components/meridian/dashboard/summary-cards";
import { WatchlistCard } from "@/components/meridian/dashboard/watchlist-card";
import { useRiskStatus } from "@/hooks/use-risk";
import { useUserEvents, useSocketStatus } from "@/hooks/use-quotes";
import { cn } from "@/lib/utils";
import type { SessionUser } from "@/lib/types";

/** Default target for the "New trade" shortcut. */
const DEFAULT_TRADE_SYMBOL = "RELIANCE";

export function DashboardView({ user }: { user: SessionUser }) {
  const reducedMotion = useReducedMotion();
  const [detailSymbol, setDetailSymbol] = useState<string | null>(null);
  const isAdmin = user.role === "ADMIN";

  // Order confirmations + portfolio nudges over WS (authed user room, §6a).
  useUserEvents(user.kycStatus === "APPROVED");

  // Kill-switch status — ADMIN only (§8d); drives the top banner + console.
  const { data: riskStatus } = useRiskStatus(isAdmin);
  const killSwitchOn = isAdmin && riskStatus?.killSwitch === true;

  return (
    <motion.section
      initial={reducedMotion ? undefined : { opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: "easeOut" }}
      aria-label="Trading dashboard"
      className="mx-auto w-full max-w-6xl flex-1 space-y-5 px-4 py-8"
    >
      {killSwitchOn ? <KillSwitchBanner /> : null}

      {user.kycStatus !== "APPROVED" ? <KycPendingBanner status={user.kycStatus} /> : null}

      <GreetingRow user={user} onNewTrade={() => setDetailSymbol(DEFAULT_TRADE_SYMBOL)} />

      <SummaryCards />

      <Tabs defaultValue="overview" className="gap-4">
        <TabsList aria-label="Dashboard sections" className="h-11 w-full sm:h-9 sm:w-auto">
          <TabsTrigger value="overview" className="px-5 font-mono uppercase tracking-wider">
            Overview
          </TabsTrigger>
          <TabsTrigger value="screener" className="px-5 font-mono uppercase tracking-wider">
            Screener
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-0 space-y-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div className="md:col-span-2">
              <WatchlistCard onOpen={setDetailSymbol} />
            </div>
            <PositionsCard onOpen={setDetailSymbol} />
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            <MarketMoversCard onOpen={setDetailSymbol} />
            <OrdersCard />
            <AlertsCard />
          </div>

          <LedgerCard />
        </TabsContent>

        <TabsContent value="screener" className="mt-0">
          <ScreenerCard onOpen={setDetailSymbol} />
        </TabsContent>
      </Tabs>

      <SecurityCard user={user} />

      {isAdmin ? <RiskConsoleCard /> : null}

      <InstrumentDetailDialog
        symbol={detailSymbol}
        onClose={() => setDetailSymbol(null)}
      />
    </motion.section>
  );
}

/* ---------------- greeting ---------------- */

function GreetingRow({
  user,
  onNewTrade,
}: {
  user: SessionUser;
  onNewTrade: () => void;
}) {
  const [greeting, setGreeting] = useState("Welcome back");
  const [dateLabel, setDateLabel] = useState("");
  const { connected } = useSocketStatus();

  // Client-only clock — avoids SSR/CSR mismatch entirely.
  useEffect(() => {
    const update = () => {
      const now = new Date();
      const hour = now.getHours();
      setGreeting(
        hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening"
      );
      setDateLabel(
        new Intl.DateTimeFormat("en-US", {
          weekday: "long",
          month: "long",
          day: "numeric",
        }).format(now)
      );
    };
    update();
    const timer = setInterval(update, 60_000);
    return () => clearInterval(timer);
  }, []);

  const firstName = useMemo(
    () => user.name.split(" ")[0] || user.email,
    [user.name, user.email]
  );

  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">
          {greeting}, {firstName}
        </h1>
        <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-xs text-muted-foreground">
          <span>{dateLabel.toUpperCase()} · PAPER ACCOUNT · INR</span>
          <span
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest",
              connected
                ? "border-profit/40 bg-profit/10 text-profit"
                : "border-loss/40 bg-loss/10 text-loss"
            )}
            role="status"
          >
            <span
              aria-hidden="true"
              className={cn(
                "relative flex size-1.5",
                connected ? "" : "opacity-70"
              )}
            >
              {connected ? (
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-profit opacity-60 motion-reduce:animate-none" />
              ) : null}
              <span
                className={cn(
                  "relative inline-flex size-1.5 rounded-full",
                  connected ? "bg-profit" : "bg-loss"
                )}
              />
            </span>
            {connected ? "Live · simulated feed" : "Feed offline"}
          </span>
        </p>
      </div>

      <Button className="h-11 px-5" onClick={onNewTrade}>
        <Plus className="size-4" aria-hidden="true" />
        New trade
      </Button>
    </div>
  );
}

/* ---------------- kill-switch banner (ADMIN, §8d) ---------------- */

function KillSwitchBanner() {
  return (
    <div
      role="alert"
      className="flex items-start gap-2.5 rounded-md border border-loss/40 bg-loss/10 px-3.5 py-2.5 text-sm"
    >
      <ShieldAlert className="mt-0.5 size-4 shrink-0 text-loss" aria-hidden="true" />
      <p className="text-loss">
        <span className="font-semibold">Kill switch is ON</span> — order
        placement is blocked by the risk desk.
      </p>
    </div>
  );
}

/* ---------------- KYC pending banner ---------------- */

function KycPendingBanner({ status }: { status: SessionUser["kycStatus"] }) {
  const pending = status === "PENDING";
  return (
    <div
      role="status"
      aria-live="polite"
      className="flex items-start gap-2.5 rounded-md border border-terminal/40 bg-terminal/10 px-3.5 py-3 text-sm"
    >
      <span
        aria-hidden="true"
        className={
          pending
            ? "relative mt-1 flex size-2 shrink-0"
            : "hidden"
        }
      >
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-terminal opacity-60 motion-reduce:animate-none" />
        <span className="relative inline-flex size-2 rounded-full bg-terminal" />
      </span>
      <p>
        {pending ? (
          <>
            <span className="font-semibold">Identity review in progress.</span>{" "}
            Markets are live now — trading and funding unlock once your KYC is
            approved.
          </>
        ) : (
          <>
            <span className="font-semibold">Identity verification required.</span>{" "}
            Complete the onboarding steps to unlock trading and funding.
          </>
        )}
      </p>
    </div>
  );
}
