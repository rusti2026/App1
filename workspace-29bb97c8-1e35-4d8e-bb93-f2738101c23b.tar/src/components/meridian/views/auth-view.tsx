"use client";

import { useMemo, useState } from "react";
import { z } from "zod";
import { motion, useReducedMotion } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { FormField } from "@/components/meridian/form-field";
import { Logo } from "@/components/meridian/logo";
import { OtpFlow } from "@/components/meridian/otp-flow";
import { ApiError } from "@/lib/api-client";
import {
  useLogin,
  useLoginMfa,
  useRegister,
} from "@/hooks/use-auth";
import { SESSION_KEY } from "@/hooks/use-session";
import { useAppStore, type AuthMode } from "@/store/app-store";
import { cn } from "@/lib/utils";

/* ---------------- zod schemas ---------------- */

const loginSchema = z.object({
  email: z.email("Enter a valid email address."),
  password: z.string().min(1, "Password is required."),
});

const signupSchema = z.object({
  name: z.string().trim().min(1, "Name is required.").max(80, "Name is too long."),
  email: z.email("Enter a valid email address."),
  password: z
    .string()
    .min(10, "Use at least 10 characters.")
    .regex(/[A-Z]/, "Add an uppercase letter.")
    .regex(/[a-z]/, "Add a lowercase letter.")
    .regex(/[0-9]/, "Add a digit."),
});

type FieldErrors = Record<string, string>;

function fieldErrorsOf(error: z.ZodError): FieldErrors {
  const out: FieldErrors = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? "form");
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}

/* ---------------- view ---------------- */

export function AuthView() {
  const authMode = useAppStore((s) => s.authMode);
  const authStep = useAppStore((s) => s.authStep);
  const setAuthMode = useAppStore((s) => s.setAuthMode);
  const setAuthStep = useAppStore((s) => s.setAuthStep);

  const handleOtpVerified = () => {
    // Simulated OTP verification — user now proceeds to a normal login.
    setAuthStep("credentials");
  };

  return (
    <section
      aria-label="Authentication"
      className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center gap-6 px-4 py-10 md:py-14"
    >
      <div className="flex justify-center">
        <Logo />
      </div>

      <Card className="bg-card/80 shadow-lg">
        <CardHeader className="pb-4">
          <CardTitle className="text-xl">
            {authStep === "mfa"
              ? "Two-factor verification"
              : authStep === "otp"
                ? "One-time code"
                : authMode === "login"
                  ? "Welcome back"
                  : "Open your account"}
          </CardTitle>
          <CardDescription>
            {authStep === "mfa"
              ? "Enter the 6-digit code from your authenticator app."
              : authStep === "otp"
                ? "Verify with a code — no password needed yet."
                : "Bank-grade security. Paper-first risk."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {authStep === "otp" ? (
            <OtpFlow
              onVerified={handleOtpVerified}
              onCancel={() => setAuthStep("credentials")}
            />
          ) : (
            <div className="space-y-5">
              {authStep === "credentials" ? (
                <Tabs
                  value={authMode}
                  onValueChange={(value) => setAuthMode(value as AuthMode)}
                >
                  <TabsList className="grid h-11 w-full grid-cols-2">
                    <TabsTrigger value="login" className="h-full">
                      Log in
                    </TabsTrigger>
                    <TabsTrigger value="signup" className="h-full">
                      Sign up
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
              ) : null}

              {authStep === "mfa" ? (
                <MfaStep />
              ) : authMode === "login" ? (
                <LoginForm />
              ) : (
                <SignupForm />
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <p className="text-center font-mono text-xs text-muted-foreground">
        Protected by scrypt hashing, rate limiting and audit logging.
      </p>
    </section>
  );
}

/* ---------------- login ---------------- */

function LoginForm() {
  const setAuthStep = useAppStore((s) => s.setAuthStep);
  const setTempToken = useAppStore((s) => s.setTempToken);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<FieldErrors>({});
  const login = useLogin();
  const queryClient = useQueryClient();

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const parsed = loginSchema.safeParse({ email, password });
    if (!parsed.success) {
      setErrors(fieldErrorsOf(parsed.error));
      return;
    }
    setErrors({});
    login.mutate(parsed.data, {
      onSuccess: async (res) => {
        if (res.status === "mfa_required") {
          setTempToken(res.tempToken);
          setAuthStep("mfa");
          return;
        }
        toast.success("Welcome back.");
        await queryClient.invalidateQueries({ queryKey: SESSION_KEY });
      },
      onError: (error) => {
        if (error instanceof ApiError && error.status === 401) {
          setErrors({ password: "Invalid email or password." });
        } else {
          setErrors({
            form: error instanceof Error ? error.message : "Sign in failed.",
          });
        }
      },
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4" noValidate>
      <FormField id="login-email" label="Email" error={errors.email}>
        <Input
          id="login-email"
          className="h-11"
          type="email"
          inputMode="email"
          autoComplete="email"
          placeholder="you@example.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          aria-invalid={!!errors.email}
          aria-describedby={errors.email ? "login-email-error" : undefined}
        />
      </FormField>

      <FormField
        id="login-password"
        label="Password"
        error={errors.password}
      >
        <Input
          id="login-password"
          className="h-11"
          type="password"
          autoComplete="current-password"
          placeholder="••••••••••"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          aria-invalid={!!errors.password}
          aria-describedby={errors.password ? "login-password-error" : undefined}
        />
      </FormField>

      {errors.form ? (
        <p role="alert" className="text-xs font-medium text-loss">
          {errors.form}
        </p>
      ) : null}

      <Button
        type="submit"
        className="h-11 w-full"
        disabled={login.isPending}
        aria-label="Log in"
      >
        {login.isPending ? "Signing in…" : "Log in"}
      </Button>

      <button
        type="button"
        className="w-full text-center text-xs font-medium text-terminal underline-offset-4 transition-colors hover:underline"
        onClick={() => setAuthStep("otp")}
      >
        Sign in with a one-time code instead
      </button>
    </form>
  );
}

/* ---------------- signup ---------------- */

function passwordChecks(password: string) {
  return {
    length: password.length >= 10,
    upper: /[A-Z]/.test(password),
    lower: /[a-z]/.test(password),
    digit: /[0-9]/.test(password),
  };
}

function SignupForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<FieldErrors>({});
  const register = useRegister();
  const queryClient = useQueryClient();

  const checks = useMemo(() => passwordChecks(password), [password]);
  const score = Object.values(checks).filter(Boolean).length;
  const missing = (
    [
      ["length", "10+ chars"],
      ["upper", "uppercase"],
      ["lower", "lowercase"],
      ["digit", "digit"],
    ] as const
  )
    .filter(([key]) => !checks[key])
    .map(([, label]) => label);

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const parsed = signupSchema.safeParse({ name, email, password });
    if (!parsed.success) {
      setErrors(fieldErrorsOf(parsed.error));
      return;
    }
    setErrors({});
    register.mutate(parsed.data, {
      onSuccess: async () => {
        toast.success("Account created — welcome to MERIDIAN.");
        await queryClient.invalidateQueries({ queryKey: SESSION_KEY });
      },
      onError: (error) => {
        if (error instanceof ApiError && error.status === 409) {
          setErrors({ email: "Email already registered." });
          toast.error("Email already registered", {
            description: "Try logging in instead.",
          });
        } else {
          setErrors({
            form: error instanceof Error ? error.message : "Registration failed.",
          });
        }
      },
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4" noValidate>
      <FormField id="signup-name" label="Full name" error={errors.name}>
        <Input
          id="signup-name"
          className="h-11"
          autoComplete="name"
          placeholder="Jane Sterling"
          value={name}
          onChange={(e) => setName(e.target.value)}
          aria-invalid={!!errors.name}
        />
      </FormField>

      <FormField id="signup-email" label="Email" error={errors.email}>
        <Input
          id="signup-email"
          className="h-11"
          type="email"
          inputMode="email"
          autoComplete="email"
          placeholder="you@example.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          aria-invalid={!!errors.email}
        />
      </FormField>

      <FormField
        id="signup-password"
        label="Password"
        error={errors.password}
        hint={
          password.length === 0
            ? "At least 10 characters with upper, lower and a digit."
            : undefined
        }
      >
        <Input
          id="signup-password"
          className="h-11"
          type="password"
          autoComplete="new-password"
          placeholder="••••••••••"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          aria-invalid={!!errors.password}
        />
      </FormField>

      {/* live strength meter */}
      <div className="space-y-1.5" aria-live="polite">
        <div className="flex gap-1.5" aria-hidden="true">
          {[0, 1, 2, 3].map((i) => (
            <span
              key={i}
              className={cn(
                "h-1.5 flex-1 rounded-full transition-colors",
                score > i
                  ? score <= 1
                    ? "bg-loss"
                    : score === 2
                      ? "bg-terminal"
                      : "bg-profit"
                  : "bg-muted"
              )}
            />
          ))}
        </div>
        <p className="font-mono text-xs text-muted-foreground">
          {password.length === 0
            ? null
            : score === 4
              ? "Strong password."
              : `Missing: ${missing.join(", ")}`}
        </p>
      </div>

      {errors.form ? (
        <p role="alert" className="text-xs font-medium text-loss">
          {errors.form}
        </p>
      ) : null}

      <Button
        type="submit"
        className="h-11 w-full"
        disabled={register.isPending}
        aria-label="Create account"
      >
        {register.isPending ? "Creating account…" : "Create account"}
      </Button>
    </form>
  );
}

/* ---------------- MFA step ---------------- */

function MfaStep() {
  const setAuthStep = useAppStore((s) => s.setAuthStep);
  const setTempToken = useAppStore((s) => s.setTempToken);
  const tempToken = useAppStore((s) => s.tempToken);
  const queryClient = useQueryClient();
  const reducedMotion = useReducedMotion();
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [attempts, setAttempts] = useState(0);
  const loginMfa = useLoginMfa();

  const handleVerify = () => {
    if (!tempToken || code.length !== 6) return;
    loginMfa.mutate(
      { tempToken, code },
      {
        onSuccess: async () => {
          toast.success("Identity confirmed.");
          await queryClient.invalidateQueries({ queryKey: SESSION_KEY });
        },
        onError: (err) => {
          setAttempts((a) => a + 1);
          setError(
            err instanceof Error ? err.message : "That code didn't match."
          );
          setCode("");
        },
      }
    );
  };

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        handleVerify();
      }}
      className="space-y-4"
      noValidate
    >
      <motion.div
        key={attempts}
        animate={
          !reducedMotion && attempts > 0
            ? { x: [0, -10, 10, -6, 6, -2, 0] }
            : undefined
        }
        transition={{ duration: 0.4 }}
        className="flex justify-center py-1"
      >
        <InputOTP
          maxLength={6}
          value={code}
          onChange={(value) => {
            setCode(value);
            setError(null);
          }}
          aria-label="6-digit authenticator code"
        >
          <InputOTPGroup>
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <InputOTPSlot key={i} index={i} className="size-11 text-base" />
            ))}
          </InputOTPGroup>
        </InputOTP>
      </motion.div>

      {error ? (
        <p role="alert" className="text-center text-xs font-medium text-loss">
          {error}
        </p>
      ) : null}

      <Button
        type="submit"
        className="h-11 w-full"
        disabled={loginMfa.isPending || code.length !== 6}
        aria-label="Verify code and log in"
      >
        {loginMfa.isPending ? "Verifying…" : "Verify & log in"}
      </Button>

      <button
        type="button"
        className="mx-auto flex items-center gap-1.5 text-xs font-medium text-muted-foreground underline-offset-4 transition-colors hover:text-foreground hover:underline"
        onClick={() => {
          setAuthStep("credentials");
          setTempToken(null);
        }}
      >
        Back to login
      </button>
    </form>
  );
}
