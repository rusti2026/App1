"use client";

import { useEffect, useState } from "react";
import { z } from "zod";
import { motion, useReducedMotion } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, CheckCircle2, Loader2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FormField } from "@/components/meridian/form-field";
import { useKycStatus, useKycSubmit } from "@/hooks/use-kyc";
import { SESSION_KEY } from "@/hooks/use-session";
import type { DocType, KycSubmitPayload, SessionUser } from "@/lib/types";

const COUNTRIES = [
  "India",
  "United States",
  "United Kingdom",
  "Canada",
  "Germany",
  "France",
  "Switzerland",
  "Singapore",
  "Japan",
  "Australia",
  "United Arab Emirates",
] as const;

const DOC_TYPES: Array<{ value: DocType; label: string }> = [
  { value: "PAN", label: "PAN" },
  { value: "AADHAAR", label: "Aadhaar" },
  { value: "PASSPORT", label: "Passport" },
  { value: "DRIVERS_LICENSE", label: "Driving License" },
];

/* ---------------- zod (per step) ---------------- */

const step1Schema = z.object({
  legalFirstName: z.string().trim().min(1, "Legal first name is required."),
  legalLastName: z.string().trim().min(1, "Legal last name is required."),
  dateOfBirth: z
    .string()
    .min(1, "Date of birth is required.")
    .refine((v) => !Number.isNaN(Date.parse(v)), "Enter a valid date.")
    .refine((v) => {
      const dob = new Date(v);
      const now = new Date();
      const age =
        now.getFullYear() -
        dob.getFullYear() -
        (now < new Date(now.getFullYear(), dob.getMonth(), dob.getDate()) ? 1 : 0);
      return age >= 18;
    }, "You must be at least 18 years old."),
  country: z.string().min(1, "Select your country of residence."),
  taxIdLast4: z.string().regex(/^\d{4}$/, "Enter exactly 4 digits."),
});

const step2Schema = z.object({
  address1: z.string().trim().min(1, "Street address is required."),
  address2: z.string().trim().optional(),
  city: z.string().trim().min(1, "City is required."),
  region: z.string().trim().min(1, "State / region is required."),
  postalCode: z.string().trim().min(3, "Postal code looks too short."),
});

const step3Schema = z.object({
  docType: z.enum(["PAN", "AADHAAR", "PASSPORT", "DRIVERS_LICENSE"], {
    message: "Select a document type.",
  }),
  docNumber: z.string().trim().min(1, "Document number is required."),
  attest18: z.boolean().refine((v) => v === true, {
    message: "You must confirm you are 18 or older.",
  }),
  attestTruth: z.boolean().refine((v) => v === true, {
    message: "You must confirm the information is accurate.",
  }),
});

type FieldErrors = Record<string, string>;

function fieldErrorsOf(error: z.ZodError): FieldErrors {
  const out: FieldErrors = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? "form");
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}

/* ---------------- view ---------------- */

type Phase = "wizard" | "review" | "approved";

interface KycForm {
  legalFirstName: string;
  legalLastName: string;
  dateOfBirth: string;
  country: string;
  taxIdLast4: string;
  address1: string;
  address2: string;
  city: string;
  region: string;
  postalCode: string;
  docType: string;
  docNumber: string;
  pep: boolean;
  attest18: boolean;
  attestTruth: boolean;
}

const EMPTY_FORM: KycForm = {
  legalFirstName: "",
  legalLastName: "",
  dateOfBirth: "",
  country: "",
  taxIdLast4: "",
  address1: "",
  address2: "",
  city: "",
  region: "",
  postalCode: "",
  docType: "",
  docNumber: "",
  pep: false,
  attest18: false,
  attestTruth: false,
};

export function OnboardingView({ user }: { user: SessionUser }) {
  const queryClient = useQueryClient();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState<KycForm>(EMPTY_FORM);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [submitted, setSubmitted] = useState(false);

  // A submission exists if the user just submitted, or the server says onboarding
  // was already completed (e.g. mid-review reload) — in that case skip the wizard.
  const hasSubmission = submitted || user.onboardingDone;
  const kycStatus = useKycStatus(hasSubmission);
  const pollStatus = kycStatus.data?.status;

  // Fully derived — no sync effects needed:
  const phase: Phase =
    user.kycStatus === "APPROVED" || pollStatus === "APPROVED"
      ? "approved"
      : pollStatus === "REJECTED"
        ? "wizard"
        : hasSubmission
          ? "review"
          : "wizard";

  const kycSubmit = useKycSubmit();

  // Approved → brief success screen → dashboard.
  useEffect(() => {
    if (phase !== "approved") return;
    const timer = setTimeout(() => {
      void queryClient.invalidateQueries({ queryKey: SESSION_KEY });
    }, 1200);
    return () => clearTimeout(timer);
  }, [phase, queryClient]);

  const setField = <K extends keyof KycForm>(key: K, value: KycForm[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => {
      if (!prev[key as string]) return prev;
      const next = { ...prev };
      delete next[key as string];
      return next;
    });
  };

  /** Validates a step; returns true when valid. Populates `errors` when invalid. */
  const validateStep = (current: 1 | 2 | 3): boolean => {
    if (current === 1) {
      const parsed = step1Schema.safeParse(form);
      if (!parsed.success) {
        setErrors(fieldErrorsOf(parsed.error));
        return false;
      }
      setErrors({});
      return true;
    }
    if (current === 2) {
      const parsed = step2Schema.safeParse(form);
      if (!parsed.success) {
        setErrors(fieldErrorsOf(parsed.error));
        return false;
      }
      setErrors({});
      return true;
    }
    const parsed = step3Schema.safeParse(form);
    if (!parsed.success) {
      setErrors(fieldErrorsOf(parsed.error));
      return false;
    }
    setErrors({});
    return true;
  };

  const buildPayload = (): KycSubmitPayload => ({
    legalFirstName: form.legalFirstName.trim(),
    legalLastName: form.legalLastName.trim(),
    dateOfBirth: form.dateOfBirth,
    country: form.country,
    address1: form.address1.trim(),
    address2: form.address2.trim() || undefined,
    city: form.city.trim(),
    region: form.region.trim(),
    postalCode: form.postalCode.trim(),
    taxIdLast4: form.taxIdLast4,
    docType: form.docType as KycSubmitPayload["docType"],
    docNumber: form.docNumber.trim(),
    pep: form.pep,
  });

  const handleContinue = () => {
    if (validateStep(step as 1 | 2)) {
      setStep((s) => Math.min(3, s + 1));
    }
  };

  const handleSubmit = () => {
    if (!validateStep(3)) return;
    const payload = buildPayload();
    kycSubmit.mutate(payload, {
      onSuccess: () => {
        setSubmitted(true);
        toast.success("Submission received", {
          description: "Our automated reviewer is on it.",
        });
      },
      onError: (error) => {
        toast.error("KYC submission failed", {
          description: error instanceof Error ? error.message : undefined,
        });
      },
    });
  };

  /* ---------- phases ---------- */

  if (phase === "approved") {
    return <ApprovedScreen />;
  }

  if (phase === "review") {
    return <UnderReviewScreen />;
  }

  return (
    <section
      aria-label="Account onboarding"
      className="mx-auto w-full max-w-2xl flex-1 px-4 py-10 md:py-14"
    >
      <div className="mb-6 flex flex-col gap-1.5">
        <p className="font-mono text-xs font-semibold uppercase tracking-[0.3em] text-terminal">
          ACCOUNT SETUP
        </p>
        <h1 className="text-2xl font-semibold tracking-tight md:text-3xl">
          Verify your identity
        </h1>
        <p className="text-sm text-muted-foreground">
          A short KYC check keeps the marketplace clean. Your data is encrypted
          at rest and never shared.
        </p>
      </div>

      {pollStatus === "REJECTED" && phase === "wizard" ? (
        <div
          role="alert"
          className="mb-4 flex items-start gap-2.5 rounded-md border border-loss/40 bg-loss/10 px-3.5 py-3 text-sm"
        >
          <AlertTriangle className="mt-0.5 size-4 shrink-0 text-loss" aria-hidden="true" />
          <span>
            Your previous submission was rejected. Please review your details
            and resubmit.
          </span>
        </div>
      ) : null}

      <div className="mb-4 flex items-center justify-between gap-4">
        <p className="font-mono text-xs tabular-nums text-muted-foreground">
          STEP {step} OF 3
        </p>
        <Progress value={(step / 3) * 100} className="h-1.5 w-40" aria-label={`Step ${step} of 3`} />
      </div>

      <Card className="bg-card/80 shadow-lg">
        <CardHeader>
          <CardTitle className="text-lg">
            {step === 1
              ? "Identity"
              : step === 2
                ? "Residential address"
                : "Declarations"}
          </CardTitle>
          <CardDescription>
            {step === 1
              ? "Exactly as it appears on your government ID."
              : step === 2
                ? "Where you currently reside."
                : "Final attestation before submission."}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {step === 1 ? (
            <Step1Fields form={form} errors={errors} setField={setField} />
          ) : step === 2 ? (
            <Step2Fields form={form} errors={errors} setField={setField} />
          ) : (
            <Step3Fields form={form} errors={errors} setField={setField} />
          )}

          <div className="flex items-center justify-between gap-3 pt-2">
            {step > 1 ? (
              <Button
                type="button"
                variant="ghost"
                className="h-11"
                onClick={() => setStep((s) => s - 1)}
              >
                Back
              </Button>
            ) : (
              <span />
            )}
            {step < 3 ? (
              <Button
                type="button"
                className="h-11 px-6"
                onClick={handleContinue}
              >
                Continue
              </Button>
            ) : (
              <Button
                type="button"
                className="h-11 px-6"
                onClick={handleSubmit}
                disabled={kycSubmit.isPending}
              >
                {kycSubmit.isPending ? "Submitting…" : "Submit for review"}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <p className="mt-4 text-center font-mono text-xs text-muted-foreground">
        SIMULATED REVIEWER · APPROVAL IN SECONDS
      </p>
    </section>
  );
}

/* ---------------- step fields ---------------- */

type SetField = <K extends keyof KycForm>(key: K, value: KycForm[K]) => void;

function Step1Fields({
  form,
  errors,
  setField,
}: {
  form: KycForm;
  errors: FieldErrors;
  setField: SetField;
}) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <FormField id="kyc-first" label="Legal first name" error={errors.legalFirstName}>
        <Input
          id="kyc-first"
          className="h-11"
          autoComplete="given-name"
          value={form.legalFirstName}
          onChange={(e) => setField("legalFirstName", e.target.value)}
          aria-invalid={!!errors.legalFirstName}
        />
      </FormField>
      <FormField id="kyc-last" label="Legal last name" error={errors.legalLastName}>
        <Input
          id="kyc-last"
          className="h-11"
          autoComplete="family-name"
          value={form.legalLastName}
          onChange={(e) => setField("legalLastName", e.target.value)}
          aria-invalid={!!errors.legalLastName}
        />
      </FormField>
      <FormField id="kyc-dob" label="Date of birth" error={errors.dateOfBirth}>
        <Input
          id="kyc-dob"
          className="h-11"
          type="date"
          value={form.dateOfBirth}
          onChange={(e) => setField("dateOfBirth", e.target.value)}
          aria-invalid={!!errors.dateOfBirth}
        />
      </FormField>
      <FormField id="kyc-country" label="Country of residence" error={errors.country}>
        <Select
          value={form.country}
          onValueChange={(value) => setField("country", value)}
        >
          <SelectTrigger id="kyc-country" className="h-11 w-full" aria-invalid={!!errors.country}>
            <SelectValue placeholder="Select a country" />
          </SelectTrigger>
          <SelectContent className="max-h-72">
            {COUNTRIES.map((country) => (
              <SelectItem key={country} value={country}>
                {country}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </FormField>
      <FormField
        id="kyc-tax"
        label="PAN (last 4 characters)"
        error={errors.taxIdLast4}
        className="sm:max-w-[200px]"
      >
        <Input
          id="kyc-tax"
          className="h-11 font-mono"
          inputMode="numeric"
          maxLength={4}
          placeholder="1234"
          value={form.taxIdLast4}
          onChange={(e) =>
            setField("taxIdLast4", e.target.value.replace(/\D/g, "").slice(0, 4))
          }
          aria-invalid={!!errors.taxIdLast4}
        />
      </FormField>
    </div>
  );
}

function Step2Fields({
  form,
  errors,
  setField,
}: {
  form: KycForm;
  errors: FieldErrors;
  setField: SetField;
}) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <FormField
        id="kyc-address1"
        label="Address line 1"
        error={errors.address1}
        className="sm:col-span-2"
      >
        <Input
          id="kyc-address1"
          className="h-11"
          autoComplete="address-line1"
          placeholder="100 Meridian Ave"
          value={form.address1}
          onChange={(e) => setField("address1", e.target.value)}
          aria-invalid={!!errors.address1}
        />
      </FormField>
      <FormField
        id="kyc-address2"
        label="Address line 2 (optional)"
        className="sm:col-span-2"
      >
        <Input
          id="kyc-address2"
          className="h-11"
          autoComplete="address-line2"
          placeholder="Apt, suite, unit"
          value={form.address2}
          onChange={(e) => setField("address2", e.target.value)}
        />
      </FormField>
      <FormField id="kyc-city" label="City" error={errors.city}>
        <Input
          id="kyc-city"
          className="h-11"
          autoComplete="address-level2"
          value={form.city}
          onChange={(e) => setField("city", e.target.value)}
          aria-invalid={!!errors.city}
        />
      </FormField>
      <FormField id="kyc-region" label="State / region" error={errors.region}>
        <Input
          id="kyc-region"
          className="h-11"
          autoComplete="address-level1"
          value={form.region}
          onChange={(e) => setField("region", e.target.value)}
          aria-invalid={!!errors.region}
        />
      </FormField>
      <FormField id="kyc-postal" label="Postal code" error={errors.postalCode}>
        <Input
          id="kyc-postal"
          className="h-11 font-mono"
          autoComplete="postal-code"
          value={form.postalCode}
          onChange={(e) => setField("postalCode", e.target.value)}
          aria-invalid={!!errors.postalCode}
        />
      </FormField>
    </div>
  );
}

function Step3Fields({
  form,
  errors,
  setField,
}: {
  form: KycForm;
  errors: FieldErrors;
  setField: SetField;
}) {
  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField
          id="kyc-doctype"
          label="Document type (PAN / Aadhaar / Passport / DL)"
          error={errors.docType}
        >
          <Select
            value={form.docType}
            onValueChange={(value) => setField("docType", value)}
          >
            <SelectTrigger id="kyc-doctype" className="h-11 w-full" aria-invalid={!!errors.docType}>
              <SelectValue placeholder="Select document type" />
            </SelectTrigger>
            <SelectContent>
              {DOC_TYPES.map((doc) => (
                <SelectItem key={doc.value} value={doc.value}>
                  {doc.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </FormField>
        <FormField id="kyc-docnum" label="Document number" error={errors.docNumber}>
          <Input
            id="kyc-docnum"
            className="h-11 font-mono"
            value={form.docNumber}
            onChange={(e) => setField("docNumber", e.target.value)}
            aria-invalid={!!errors.docNumber}
          />
        </FormField>
      </div>
      <p className="-mt-2 font-mono text-[11px] text-muted-foreground">
        Verified via DigiLocker (simulated) · AES-256 encrypted at rest
      </p>

      <div className="flex items-start gap-3 rounded-md border border-border/60 p-3.5">
        <Checkbox
          id="kyc-pep"
          checked={form.pep}
          onCheckedChange={(checked) => setField("pep", checked === true)}
          className="mt-0.5"
        />
        <Label
          htmlFor="kyc-pep"
          className="text-sm font-normal leading-relaxed text-muted-foreground"
        >
          I am a politically exposed person (PEP), or a close associate or
          family member of one.
        </Label>
      </div>

      <div className="flex items-start gap-3 rounded-md border border-border/60 p-3.5">
        <Checkbox
          id="kyc-attest-18"
          checked={form.attest18}
          onCheckedChange={(checked) => setField("attest18", checked === true)}
          className="mt-0.5"
          aria-invalid={!!errors.attest18}
        />
        <Label
          htmlFor="kyc-attest-18"
          className="text-sm font-normal leading-relaxed text-muted-foreground"
        >
          I confirm I am at least 18 years old and legally permitted to open a
          trading account under the{" "}
          <a href="#" className="underline underline-offset-2 hover:text-foreground">
            Terms of Service
          </a>
          .
        </Label>
      </div>
      {errors.attest18 ? (
        <p role="alert" className="-mt-2 text-xs font-medium text-loss">
          {errors.attest18}
        </p>
      ) : null}

      <div className="flex items-start gap-3 rounded-md border border-border/60 p-3.5">
        <Checkbox
          id="kyc-attest-truth"
          checked={form.attestTruth}
          onCheckedChange={(checked) => setField("attestTruth", checked === true)}
          className="mt-0.5"
          aria-invalid={!!errors.attestTruth}
        />
        <Label
          htmlFor="kyc-attest-truth"
          className="text-sm font-normal leading-relaxed text-muted-foreground"
        >
          I attest that the information provided is true, complete and
          accurate, consistent with our{" "}
          <a href="#" className="underline underline-offset-2 hover:text-foreground">
            Privacy Policy
          </a>
          .
        </Label>
      </div>
      {errors.attestTruth ? (
        <p role="alert" className="-mt-2 text-xs font-medium text-loss">
          {errors.attestTruth}
        </p>
      ) : null}
    </div>
  );
}

/* ---------------- review / approved ---------------- */

function UnderReviewScreen() {
  return (
    <section
      aria-label="KYC under review"
      className="mx-auto flex w-full max-w-md flex-1 flex-col items-center justify-center px-4 py-16 text-center"
    >
      <Badge
        variant="outline"
        className="animate-pulse border-terminal/40 bg-terminal/10 px-4 py-1.5 font-mono text-xs font-semibold uppercase tracking-widest text-terminal"
      >
        UNDER REVIEW
      </Badge>
      <h1 className="mt-6 text-2xl font-semibold tracking-tight">
        Checking your submission…
      </h1>
      <p className="mt-3 max-w-sm text-sm leading-relaxed text-muted-foreground">
        Our automated reviewer is validating your identity and declarations.
        This usually takes a few seconds — this page updates automatically.
      </p>
      <Loader2 className="mt-8 size-6 animate-spin text-terminal" aria-hidden="true" />
      <p className="mt-8 font-mono text-xs text-muted-foreground">
        KYC.REVIEW · POLL 2s · AES-256 AT REST
      </p>
    </section>
  );
}

function ApprovedScreen() {
  const reducedMotion = useReducedMotion();
  return (
    <motion.section
      initial={reducedMotion ? undefined : { opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.2, ease: "easeOut" }}
      aria-label="Account approved"
      className="mx-auto flex w-full max-w-md flex-1 flex-col items-center justify-center px-4 py-16 text-center"
    >
      <span className="flex size-16 items-center justify-center rounded-full border border-profit/40 bg-profit/10">
        <ShieldCheck className="size-8 text-profit" aria-hidden="true" />
      </span>
      <h1 className="mt-6 flex items-center justify-center gap-2 text-2xl font-semibold tracking-tight">
        Account approved
        <CheckCircle2 className="size-5 text-profit" aria-hidden="true" />
      </h1>
      <p className="mt-3 max-w-sm text-sm leading-relaxed text-muted-foreground">
        Your identity is verified and your paper wallet is provisioned.
        Taking you to your terminal…
      </p>
    </motion.section>
  );
}
