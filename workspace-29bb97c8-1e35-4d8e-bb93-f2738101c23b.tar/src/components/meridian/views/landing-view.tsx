"use client";

import { motion, useReducedMotion } from "framer-motion";
import { Activity, ArrowRight, Layers, ShieldCheck } from "lucide-react";
import { useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useMarketOverview } from "@/hooks/use-market";
import { useFlash, useQuoteSocket } from "@/hooks/use-quotes";
import { TickerTape } from "@/components/meridian/ticker-tape";
import {
  formatInr,
  formatSignedPct,
  formatVolume,
  trendGlyph,
} from "@/components/meridian/format";
import { useAppStore } from "@/store/app-store";
import { cn } from "@/lib/utils";
import type { MarketQuote, TickQuote } from "@/lib/types";

const STATS = [
  { value: "<50ms", label: "tick latency" },
  { value: "AES-256", label: "encryption at rest" },
  { value: "SOC2-track", label: "immutable audit log" },
  { value: "10k+", label: "WS connections" },
] as const;

const FEATURES = [
  {
    icon: Activity,
    title: "Real-time market data",
    body: "Streaming quotes for equities, ETFs and crypto — normalized ticks, sub-50ms fan-out, watchlists that never sit still.",
  },
  {
    icon: ShieldCheck,
    title: "Bank-grade security",
    body: "Scrypt-hashed credentials, AES-256-GCM secrets at rest, TOTP multi-factor, revocable sessions and a full audit trail.",
  },
  {
    icon: Layers,
    title: "Transparent ledger",
    body: "A double-entry, append-only ledger. Every deposit, trade and fee is reconcilable to the cent — no floating money.",
  },
] as const;

const STEPS = [
  {
    n: "01",
    title: "Create your account",
    body: "Email, password, done. Your paper wallet is provisioned instantly.",
  },
  {
    n: "02",
    title: "Verify your identity",
    body: "A short KYC wizard keeps the marketplace clean. Review takes seconds.",
  },
  {
    n: "03",
    title: "Explore with paper funds",
    body: "Real market data, zero real risk. Trade the tape before you trade capital.",
  },
] as const;

export function LandingView() {
  const openAuth = useAppStore((s) => s.openAuth);
  const heroMotion = useReducedMotionSafe();

  return (
    <div className="flex flex-col">
      {/* ---------- Hero ---------- */}
      <section
        aria-labelledby="hero-heading"
        className="relative overflow-hidden"
      >
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_50%_at_50%_0%,oklch(0.75_0.17_160/8%),transparent_70%)]"
        />
        <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 py-14 md:py-20 lg:grid-cols-2 lg:items-center lg:gap-14">
          <motion.div
            initial={heroMotion.initial}
            animate={heroMotion.animate}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="flex flex-col items-start gap-6"
          >
            <p className="font-mono text-xs font-semibold uppercase tracking-[0.3em] text-terminal">
              MERIDIAN TERMINAL v1.0
            </p>
            <h1
              id="hero-heading"
              className="text-4xl font-semibold tracking-tight text-balance md:text-5xl lg:text-6xl"
            >
              Markets, in motion.
            </h1>
            <p className="max-w-md text-base text-muted-foreground md:text-lg">
              Real-time NSE · BSE quotes on a simulated live feed,
              institutional-grade tooling, paper-first execution. Trade the
              tape before you trade capital.
            </p>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Button
                size="lg"
                className="h-11 px-6 text-base"
                onClick={() => openAuth("signup")}
              >
                Create account
                <ArrowRight className="size-4" aria-hidden="true" />
              </Button>
              <Button
                size="lg"
                variant="ghost"
                className="h-11 px-6 text-base"
                onClick={() => openAuth("login")}
              >
                Sign in
              </Button>
            </div>
            <p className="font-mono text-xs text-muted-foreground">
              No credit card. Simulated ₹ funds. Real market behavior.
            </p>
          </motion.div>

          <HeroTerminalCard />
        </div>
      </section>

      {/* ---------- Live ticker tape ---------- */}
      <TickerTape />

      {/* ---------- Stats band ---------- */}
      <section
        aria-label="Platform stats"
        className="border-b border-border/60"
      >
        <dl className="mx-auto grid w-full max-w-6xl grid-cols-2 gap-6 px-4 py-10 md:grid-cols-4">
          {STATS.map((stat) => (
            <div key={stat.label} className="flex flex-col gap-1">
              <dd className="font-mono text-2xl font-semibold tabular-nums text-terminal">
                {stat.value}
              </dd>
              <dt className="font-mono text-xs uppercase tracking-wider text-muted-foreground">
                {stat.label}
              </dt>
            </div>
          ))}
        </dl>
      </section>

      {/* ---------- Feature grid ---------- */}
      <section aria-labelledby="features-heading" id="features">
        <div className="mx-auto w-full max-w-6xl px-4 py-16">
          <p className="font-mono text-xs font-semibold uppercase tracking-[0.3em] text-terminal">
            WHY MERIDIAN
          </p>
          <h2
            id="features-heading"
            className="mt-3 text-2xl font-semibold tracking-tight md:text-3xl"
          >
            Built like an institution. Priced like paper.
          </h2>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {FEATURES.map((feature) => (
              <Card key={feature.title} className="bg-card/60">
                <CardContent className="flex flex-col gap-3 p-6">
                  <span className="flex size-11 items-center justify-center rounded-md border border-terminal/30 bg-terminal/10 text-terminal">
                    <feature.icon className="size-5" aria-hidden="true" />
                  </span>
                  <h3 className="text-base font-semibold">{feature.title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    {feature.body}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- How it works ---------- */}
      <section
        aria-labelledby="how-heading"
        id="how"
        className="border-y border-border/60 bg-card/30"
      >
        <div className="mx-auto w-full max-w-6xl px-4 py-16">
          <p className="font-mono text-xs font-semibold uppercase tracking-[0.3em] text-terminal">
            HOW IT WORKS
          </p>
          <h2
            id="how-heading"
            className="mt-3 text-2xl font-semibold tracking-tight md:text-3xl"
          >
            Three steps to the tape.
          </h2>
          <ol className="mt-8 grid gap-4 md:grid-cols-3">
            {STEPS.map((step) => (
              <li key={step.n}>
                <Card className="h-full bg-card/60">
                  <CardContent className="flex h-full flex-col gap-3 p-6">
                    <span className="font-mono text-sm font-semibold text-terminal">
                      {step.n}
                    </span>
                    <h3 className="text-base font-semibold">{step.title}</h3>
                    <p className="text-sm leading-relaxed text-muted-foreground">
                      {step.body}
                    </p>
                  </CardContent>
                </Card>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* ---------- CTA banner ---------- */}
      <section aria-labelledby="cta-heading">
        <div className="mx-auto w-full max-w-6xl px-4 py-16">
          <div className="relative overflow-hidden rounded-xl border border-terminal/30 bg-terminal/5 p-8 md:p-12">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 bg-[radial-gradient(50%_80%_at_80%_20%,oklch(0.80_0.14_80/10%),transparent_70%)]"
            />
            <div className="relative flex flex-col items-start gap-5 md:flex-row md:items-center md:justify-between">
              <div>
                <h2
                  id="cta-heading"
                  className="text-2xl font-semibold tracking-tight"
                >
                  Open your paper account in minutes.
                </h2>
                <p className="mt-2 max-w-lg text-sm text-muted-foreground">
                  KYC verified. Ledger transparent. MFA optional but strongly
                  encouraged — it&apos;s your capital, simulated or not.
                </p>
              </div>
              <Button
                size="lg"
                className="h-11 px-6"
                onClick={() => openAuth("signup")}
              >
                Get started
                <ArrowRight className="size-4" aria-hidden="true" />
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

/** Decorative-but-live movers panel for the hero's right column (WS-driven). */
function HeroTerminalCard() {
  const { data, isPending } = useMarketOverview();
  const movers = useMemo(() => data?.movers.slice(0, 4) ?? [], [data?.movers]);
  const symbols = useMemo(() => movers.map((m) => m.symbol), [movers]);
  const { quotes: live } = useQuoteSocket(symbols);

  return (
    <Card className="overflow-hidden border-border/80 bg-card/80 shadow-lg">
      <div className="flex items-center justify-between border-b border-border/60 px-4 py-2.5">
        <span className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
          <span className="relative flex size-2" aria-hidden="true">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-profit opacity-60 motion-reduce:animate-none" />
            <span className="relative inline-flex size-2 rounded-full bg-profit" />
          </span>
          Live · NSE · BSE · simulated feed
        </span>
        <span className="font-mono text-[11px] uppercase tracking-widest text-terminal">
          TOP MOVERS
        </span>
      </div>
      <CardContent className="p-0">
        {isPending ? (
          <div className="divide-y divide-border/60" aria-hidden="true">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between px-4 py-3.5">
                <div className="space-y-1.5">
                  <Skeleton className="h-4 w-16" />
                  <Skeleton className="h-3 w-28" />
                </div>
                <Skeleton className="h-4 w-20" />
              </div>
            ))}
          </div>
        ) : movers.length === 0 ? (
          <p className="px-4 py-10 text-center font-mono text-xs text-muted-foreground">
            AWAITING FEED…
          </p>
        ) : (
          <ul className="divide-y divide-border/60">
            {movers.map((q) => (
              <HeroMoverRow key={q.symbol} quote={q} live={live[q.symbol]} />
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

/** One hero row — flash on price change via the sign of the latest tick. */
function HeroMoverRow({
  quote,
  live,
}: {
  quote: MarketQuote;
  live?: TickQuote;
}) {
  const lastPrice = live?.lastPriceCents ?? quote.lastPriceCents;
  const changePct = live?.changePct ?? quote.changePct;
  const volume = live?.volume ?? quote.volume;
  const flash = useFlash(lastPrice);

  return (
    <li className="flex items-center justify-between gap-3 px-4 py-3.5">
      <div className="min-w-0">
        <p className="flex items-center gap-2">
          <span className="font-mono text-sm font-semibold">{quote.symbol}</span>
          <Badge
            variant="outline"
            className="px-1.5 py-0 text-[10px] text-muted-foreground"
          >
            {quote.type}
          </Badge>
        </p>
        <p className="truncate text-xs text-muted-foreground">{quote.name}</p>
      </div>
      <div className="text-right">
        <p
          className={cn(
            "font-mono text-sm tabular-nums transition-colors duration-500",
            flash === "up" && "bg-profit/15 text-profit",
            flash === "down" && "bg-loss/15 text-loss"
          )}
        >
          {formatInr(lastPrice)}
        </p>
        <p
          className={cn(
            "font-mono text-xs tabular-nums",
            changePct >= 0 ? "text-profit" : "text-loss"
          )}
        >
          {trendGlyph(changePct)} {formatSignedPct(changePct)} · {formatVolume(volume)}
        </p>
      </div>
    </li>
  );
}

/** Small helper so the hero animation respects reduced motion without branching JSX. */
function useReducedMotionSafe() {
  const reduced = useReducedMotion();
  return reduced
    ? { initial: undefined, animate: undefined }
    : { initial: { opacity: 0, y: 12 }, animate: { opacity: 1, y: 0 } };
}
