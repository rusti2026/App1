"use client";

import { motion, useReducedMotion } from "framer-motion";
import { Logo } from "@/components/meridian/logo";

/** Branded splash shown while the session query bootstraps the state machine. */
export function SplashScreen() {
  const reducedMotion = useReducedMotion();

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-8 bg-background px-4">
      <motion.div
        animate={
          reducedMotion ? undefined : { opacity: [0.75, 1, 0.75], scale: [1, 1.03, 1] }
        }
        transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
      >
        <Logo markClassName="size-14 rounded-xl" showWordmark={false} />
      </motion.div>
      <div className="flex flex-col items-center gap-3" role="status" aria-live="polite">
        <p className="text-sm font-semibold uppercase tracking-[0.4em]">MERIDIAN</p>
        <p className="font-mono text-xs text-muted-foreground">
          CONNECTING TO TERMINAL…
        </p>
        <div className="h-0.5 w-40 overflow-hidden rounded-full bg-muted">
          <motion.div
            className="h-full w-1/3 rounded-full bg-terminal"
            animate={reducedMotion ? undefined : { x: ["-120%", "340%"] }}
            transition={{ duration: 1.1, repeat: Infinity, ease: "easeInOut" }}
          />
        </div>
      </div>
      <p className="sr-only">Loading MERIDIAN, checking your session.</p>
    </div>
  );
}
