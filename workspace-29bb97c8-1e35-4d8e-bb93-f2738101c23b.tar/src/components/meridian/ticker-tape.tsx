"use client";

/**
 * Live ticker tape — WS-driven (§6a) over the full 21-symbol universe with a
 * /api/market/overview fallback while the socket warms up. CSS marquee via a
 * duplicated track; pauses on hover; static when the user prefers reduced
 * motion. Indices render as points, everything else as ₹.
 */

import { useMemo } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";
import { useMarketOverview } from "@/hooks/use-market";
import { ALL_SYMBOLS, useQuoteSocket } from "@/hooks/use-quotes";
import { formatInr, formatPts, formatSignedPct, trendGlyph } from "@/components/meridian/format";
import { cn } from "@/lib/utils";
import type { MarketQuote, TickQuote } from "@/lib/types";

export function TickerTape() {
  const reducedMotion = useReducedMotion();
  const { data: overview, isPending } = useMarketOverview();
  const { quotes: live } = useQuoteSocket(ALL_SYMBOLS);

  /** live quote when present, else the REST overview snapshot. */
  const quotes = useMemo<TickQuote[]>(() => {
    const fallback = new Map<string, MarketQuote>();
    for (const q of [...(overview?.movers ?? []), ...(overview?.indices ?? [])]) {
      fallback.set(q.symbol, q);
    }
    const rows: TickQuote[] = [];
    for (const symbol of ALL_SYMBOLS) {
      const liveQuote = live[symbol];
      if (liveQuote) {
        rows.push(liveQuote);
        continue;
      }
      const restQuote = fallback.get(symbol);
      if (restQuote) {
        rows.push({
          symbol: restQuote.symbol,
          name: restQuote.name,
          type: restQuote.type,
          exchange: restQuote.exchange ?? "NSE",
          lastPriceCents: restQuote.lastPriceCents,
          prevCloseCents: restQuote.prevCloseCents ?? restQuote.lastPriceCents,
          openCents: restQuote.lastPriceCents,
          highCents: restQuote.lastPriceCents,
          lowCents: restQuote.lastPriceCents,
          changeCents: restQuote.changeCents,
          changePct: restQuote.changePct,
          volume: restQuote.volume,
          ts: 0,
        });
      }
    }
    return rows;
  }, [overview?.movers, overview?.indices, live]);

  if (isPending && Object.keys(live).length === 0) {
    return (
      <div
        className="flex gap-3 overflow-hidden border-y border-border/60 bg-card/40 px-4 py-3"
        aria-hidden="true"
      >
        {Array.from({ length: 8 }).map((_, i) => (
          <Skeleton key={i} className="h-6 w-28 shrink-0 rounded-md" />
        ))}
      </div>
    );
  }

  if (quotes.length === 0) return null;

  return (
    <div
      className="ticker-mask group relative overflow-hidden border-y border-border/60 bg-card/40"
      role="marquee"
      aria-label="Live market prices"
    >
      <div
        className={cn(
          "flex w-max items-stretch",
          !reducedMotion && "animate-[marquee_48s_linear_infinite] group-hover:[animation-play-state:paused]"
        )}
      >
        {[0, 1].map((copy) => (
          <ul
            key={copy}
            aria-hidden={copy === 1 ? "true" : undefined}
            className="flex items-center gap-8 px-4 py-2.5 pr-8"
          >
            {quotes.map((q) => (
              <li key={`${copy}-${q.symbol}`} className="flex items-center gap-2">
                <span className="font-mono text-xs font-semibold tracking-widest text-terminal">
                  {q.symbol}
                </span>
                <span className="font-mono text-xs tabular-nums">
                  {q.type === "INDEX" ? formatPts(q.lastPriceCents) : formatInr(q.lastPriceCents)}
                </span>
                <span
                  className={cn(
                    "font-mono text-xs tabular-nums",
                    q.changePct >= 0 ? "text-profit" : "text-loss"
                  )}
                >
                  {trendGlyph(q.changePct)} {formatSignedPct(q.changePct)}
                </span>
              </li>
            ))}
          </ul>
        ))}
      </div>
    </div>
  );
}
