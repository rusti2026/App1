"use client";

/**
 * Screener — sortable, filterable table over the full instrument universe.
 * Data: GET /api/market/screener (5s poll) with a live WS join on top so
 * LTP/Chg%/Volume tick in real time and High/Low come from the tape.
 * Row click opens the instrument detail dialog (same onOpen flow as the
 * watchlist/movers cards).
 */

import { useMemo, useState } from "react";
import { ArrowDown, ArrowUp, ChevronsUpDown, Search } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useScreener } from "@/hooks/use-screener";
import { useQuoteSocket } from "@/hooks/use-quotes";
import {
  formatInr,
  formatPts,
  formatSignedPct,
  formatVolume,
  trendGlyph,
} from "@/components/meridian/format";
import { cn } from "@/lib/utils";
import type { AssetType, MarketQuote, TickQuote } from "@/lib/types";

type FilterChip = "ALL" | "GAINERS" | "LOSERS" | "ACTIVE";

type SortKey = "symbol" | "ltp" | "chgPct" | "volume" | "high" | "low";
type SortDir = "asc" | "desc";

const FILTER_CHIPS: Array<{ value: FilterChip; label: string }> = [
  { value: "ALL", label: "All" },
  { value: "GAINERS", label: "Gainers" },
  { value: "LOSERS", label: "Losers" },
  { value: "ACTIVE", label: "Most Active" },
];

const COLUMNS: Array<{
  key: SortKey;
  label: string;
  align: "left" | "right";
}> = [
  { key: "symbol", label: "Symbol", align: "left" },
  { key: "ltp", label: "LTP", align: "right" },
  { key: "chgPct", label: "Chg %", align: "right" },
  { key: "volume", label: "Volume", align: "right" },
  { key: "high", label: "High", align: "right" },
  { key: "low", label: "Low", align: "right" },
];

interface ScreenerRow {
  symbol: string;
  name: string;
  type: AssetType;
  lastPriceCents: number;
  changePct: number;
  volume: number;
  /** Live WS join (TickQuote) — the frozen screener contract has no high/low. */
  highCents?: number;
  lowCents?: number;
}

function sortValue(row: ScreenerRow, key: SortKey): number | string {
  switch (key) {
    case "symbol":
      return row.symbol;
    case "ltp":
      return row.lastPriceCents;
    case "chgPct":
      return row.changePct;
    case "volume":
      return row.volume;
    case "high":
      return row.highCents ?? Number.NEGATIVE_INFINITY;
    case "low":
      return row.lowCents ?? Number.NEGATIVE_INFINITY;
  }
}

export function ScreenerCard({ onOpen }: { onOpen?: (symbol: string) => void }) {
  const { data, isPending, isError } = useScreener();
  const base = useMemo(() => data?.quotes ?? [], [data?.quotes]);
  const symbols = useMemo(() => base.map((q) => q.symbol), [base]);
  const { quotes: live } = useQuoteSocket(symbols);

  const [chip, setChip] = useState<FilterChip>("ALL");
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("volume");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  // REST snapshot joined with live WS quotes (WS wins when present).
  const rows = useMemo<ScreenerRow[]>(() => {
    return base.map((q: MarketQuote) => {
      const lq: TickQuote | undefined = live[q.symbol];
      return {
        symbol: q.symbol,
        name: q.name,
        type: q.type,
        lastPriceCents: lq?.lastPriceCents ?? q.lastPriceCents,
        changePct: lq?.changePct ?? q.changePct,
        volume: lq?.volume ?? q.volume,
        highCents: lq?.highCents,
        lowCents: lq?.lowCents,
      };
    });
  }, [base, live]);

  const visible = useMemo(() => {
    const needle = search.trim().toUpperCase();
    let out = rows;
    if (chip === "GAINERS") out = out.filter((r) => r.changePct > 0);
    else if (chip === "LOSERS") out = out.filter((r) => r.changePct < 0);
    if (needle) {
      out = out.filter(
        (r) => r.symbol.includes(needle) || r.name.toUpperCase().includes(needle)
      );
    }
    const dir = sortDir === "asc" ? 1 : -1;
    return [...out].sort((a, b) => {
      const va = sortValue(a, sortKey);
      const vb = sortValue(b, sortKey);
      if (typeof va === "string" || typeof vb === "string") {
        return String(va).localeCompare(String(vb)) * dir;
      }
      return (va - vb) * dir;
    });
  }, [rows, chip, search, sortKey, sortDir]);

  const applyChip = (next: FilterChip) => {
    setChip(next);
    // Each lens opens with its natural sort: top movers by |chg| / volume.
    if (next === "GAINERS") {
      setSortKey("chgPct");
      setSortDir("desc");
    } else if (next === "LOSERS") {
      setSortKey("chgPct");
      setSortDir("asc");
    } else {
      setSortKey("volume");
      setSortDir("desc");
    }
  };

  const toggleSort = (key: SortKey) => {
    if (key === sortKey) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir(key === "symbol" ? "asc" : "desc");
    }
  };

  const fmtPrice = (row: ScreenerRow, paise: number) =>
    row.type === "INDEX" ? formatPts(paise) : formatInr(paise);

  return (
    <Card className="bg-card/60">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div className="space-y-1">
            <CardTitle className="text-base">Screener</CardTitle>
            <CardDescription className="text-xs">
              Full universe · sortable, live · refreshes every 5s
            </CardDescription>
          </div>
          <span className="font-mono text-[11px] uppercase tracking-widest text-terminal">
            SCAN
          </span>
        </div>
      </CardHeader>
      <CardContent className="space-y-3 p-4 sm:p-6">
        <div className="flex flex-wrap items-center gap-2">
          {FILTER_CHIPS.map((c) => (
            <button
              key={c.value}
              type="button"
              aria-pressed={chip === c.value}
              className={cn(
                "min-h-[36px] rounded-full border px-3 py-1.5 font-mono text-[11px] uppercase tracking-wider transition-colors",
                chip === c.value
                  ? "border-terminal/50 bg-terminal/10 text-terminal"
                  : "border-border/60 text-muted-foreground hover:bg-accent/50 hover:text-foreground"
              )}
              onClick={() => applyChip(c.value)}
            >
              {c.label}
            </button>
          ))}
          <div className="relative ml-auto w-full sm:w-56">
            <Search
              className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              className="h-11 pl-8 font-mono uppercase sm:h-9"
              placeholder="Filter symbol / name"
              aria-label="Filter instruments by symbol or name"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        {isPending ? (
          <div className="space-y-2" aria-hidden="true">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : isError ? (
          <p role="alert" className="py-8 text-sm text-loss">
            Couldn&apos;t load the screener — retrying…
          </p>
        ) : visible.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-10 text-center">
            <Search className="size-6 text-muted-foreground/50" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">
              No instruments match your filters.
            </p>
            <p className="text-xs text-muted-foreground">
              Clear the search or try a different lens.
            </p>
          </div>
        ) : (
          <div className="thin-scroll max-h-[420px] overflow-y-auto">
            <Table className="min-w-[560px]">
              <TableHeader className="sticky top-0 z-10 bg-card">
                <TableRow className="hover:bg-transparent">
                  {COLUMNS.map((col) => {
                    const activeSort = sortKey === col.key;
                    return (
                      <TableHead
                        key={col.key}
                        aria-sort={
                          activeSort
                            ? sortDir === "asc"
                              ? "ascending"
                              : "descending"
                            : "none"
                        }
                        className={cn(
                          "font-mono text-[10px] uppercase tracking-widest",
                          col.align === "right" ? "text-right" : "text-left"
                        )}
                      >
                        <button
                          type="button"
                          className={cn(
                            "inline-flex items-center gap-1 transition-colors",
                            col.align === "right" && "flex-row-reverse",
                            activeSort
                              ? "text-terminal"
                              : "text-muted-foreground hover:text-foreground"
                          )}
                          onClick={() => toggleSort(col.key)}
                          aria-label={`Sort by ${col.label}`}
                        >
                          {col.label}
                          {activeSort ? (
                            sortDir === "asc" ? (
                              <ArrowUp className="size-3" aria-hidden="true" />
                            ) : (
                              <ArrowDown className="size-3" aria-hidden="true" />
                            )
                          ) : (
                            <ChevronsUpDown
                              className="size-3 opacity-40"
                              aria-hidden="true"
                            />
                          )}
                        </button>
                      </TableHead>
                    );
                  })}
                </TableRow>
              </TableHeader>
              <TableBody>
                {visible.map((row) => (
                  <TableRow
                    key={row.symbol}
                    className="cursor-pointer"
                    onClick={() => onOpen?.(row.symbol)}
                  >
                    <TableCell className="py-2">
                      <button
                        type="button"
                        className="block max-w-[190px] text-left focus-visible:outline-none"
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpen?.(row.symbol);
                        }}
                        aria-label={`Open ${row.symbol} details`}
                      >
                        <span className="flex items-center gap-2">
                          <span className="font-mono text-sm font-semibold">
                            {row.symbol}
                          </span>
                          <Badge
                            variant="outline"
                            className="px-1.5 py-0 text-[10px] text-muted-foreground"
                          >
                            {row.type}
                          </Badge>
                        </span>
                        <span className="block truncate text-xs text-muted-foreground">
                          {row.name}
                        </span>
                      </button>
                    </TableCell>
                    <TableCell className="py-2 text-right font-mono text-sm tabular-nums">
                      {fmtPrice(row, row.lastPriceCents)}
                    </TableCell>
                    <TableCell
                      className={cn(
                        "py-2 text-right font-mono text-sm tabular-nums",
                        row.changePct > 0
                          ? "text-profit"
                          : row.changePct < 0
                            ? "text-loss"
                            : "text-muted-foreground"
                      )}
                    >
                      {trendGlyph(row.changePct)} {formatSignedPct(row.changePct)}
                    </TableCell>
                    <TableCell className="py-2 text-right font-mono text-sm tabular-nums text-muted-foreground">
                      {formatVolume(row.volume)}
                    </TableCell>
                    <TableCell className="py-2 text-right font-mono text-sm tabular-nums text-muted-foreground">
                      {row.highCents !== undefined ? fmtPrice(row, row.highCents) : "—"}
                    </TableCell>
                    <TableCell className="py-2 text-right font-mono text-sm tabular-nums text-muted-foreground">
                      {row.lowCents !== undefined ? fmtPrice(row, row.lowCents) : "—"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
