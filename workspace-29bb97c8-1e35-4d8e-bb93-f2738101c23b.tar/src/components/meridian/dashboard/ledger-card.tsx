"use client";

import { ArrowDownLeft, ArrowUpRight, ReceiptText } from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { usePortfolioSummary } from "@/hooks/use-portfolio";
import { formatInr, formatSignedInr, relativeTime } from "@/components/meridian/format";
import { cn } from "@/lib/utils";
import type { LedgerEntry } from "@/lib/types";

/** Append-only ledger feed — CREDIT in (green, down-left), DEBIT out (red, up-right). */
export function LedgerCard({ ledger }: { ledger?: LedgerEntry[] }) {
  const { data, isPending, isError } = usePortfolioSummary();

  const entries = ledger ?? data?.ledger ?? [];

  return (
    <Card className="bg-card/60">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div className="space-y-1">
            <CardTitle className="text-base">Recent ledger activity</CardTitle>
            <CardDescription className="text-xs">
              Double-entry, append-only — every cent accounted for
            </CardDescription>
          </div>
          <span className="font-mono text-[11px] uppercase tracking-widest text-terminal">
            LEDGER
          </span>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {isPending && ledger === undefined ? (
          <div className="divide-y divide-border/60" aria-hidden="true">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 px-6 py-3">
                <Skeleton className="size-9 rounded-full" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3.5 w-28" />
                  <Skeleton className="h-3 w-20" />
                </div>
                <Skeleton className="h-3.5 w-16" />
              </div>
            ))}
          </div>
        ) : isError && entries.length === 0 ? (
          <p role="alert" className="px-6 py-8 text-sm text-loss">
            Couldn&apos;t load ledger activity — retrying…
          </p>
        ) : entries.length === 0 ? (
          <div className="flex flex-col items-center gap-2 px-6 py-10 text-center">
            <ReceiptText className="size-6 text-muted-foreground/50" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">No activity yet.</p>
            <p className="text-xs text-muted-foreground">
              Your paper funding and trades will land here, immutably.
            </p>
          </div>
        ) : (
          <ul
            className="thin-scroll max-h-96 divide-y divide-border/60 overflow-y-auto"
            aria-label="Recent ledger activity"
          >
            {entries.map((entry) => {
              const credit = entry.direction === "CREDIT";
              return (
                <li
                  key={entry.id}
                  className="flex items-center gap-3 px-4 py-2.5 sm:px-6"
                >
                  <span
                    className={cn(
                      "flex size-9 shrink-0 items-center justify-center rounded-full",
                      credit
                        ? "bg-profit/10 text-profit"
                        : "bg-loss/10 text-loss"
                    )}
                    aria-hidden="true"
                  >
                    {credit ? (
                      <ArrowDownLeft className="size-4" />
                    ) : (
                      <ArrowUpRight className="size-4" />
                    )}
                  </span>

                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium">
                      {entry.category}
                      {entry.memo ? (
                        <span className="text-muted-foreground"> · {entry.memo}</span>
                      ) : null}
                    </p>
                    <p className="font-mono text-xs tabular-nums text-muted-foreground">
                      Balance {formatInr(entry.balanceAfterCents)}
                      {entry.createdAt ? ` · ${relativeTime(entry.createdAt)}` : ""}
                    </p>
                  </div>

                  <p
                    className={cn(
                      "font-mono text-sm font-semibold tabular-nums",
                      credit ? "text-profit" : "text-loss"
                    )}
                  >
                    {formatSignedInr(
                      credit ? entry.amountCents : -Math.abs(entry.amountCents)
                    )}
                  </p>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
