"use client";

import { useMemo } from "react";
import { Star } from "lucide-react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useAddToWatchlist,
  useMarketOverview,
  useRemoveFromWatchlist,
  useWatchlist,
} from "@/hooks/use-market";
import { useFlash, useQuoteSocket } from "@/hooks/use-quotes";
import {
  formatInr,
  formatPts,
  formatSignedPct,
  formatVolume,
  trendGlyph,
} from "@/components/meridian/format";
import { cn } from "@/lib/utils";
import type { MarketQuote, TickQuote } from "@/lib/types";

/**
 * Market movers with a star toggle → optimistic watchlist add/remove.
 * Prices are WS-live (§6a) with the REST overview as the initial snapshot;
 * row click opens the instrument detail dialog.
 */
export function MarketMoversCard({ onOpen }: { onOpen?: (symbol: string) => void }) {
  const { data, isPending, isError } = useMarketOverview();
  const watchlist = useWatchlist();
  const addToWatchlist = useAddToWatchlist();
  const removeFromWatchlist = useRemoveFromWatchlist();

  const movers = useMemo(() => data?.movers ?? [], [data?.movers]);
  const moverSymbols = useMemo(() => movers.map((m) => m.symbol), [movers]);
  const { quotes: live } = useQuoteSocket(moverSymbols);

  const watchedSymbols = useMemo(
    () => new Set(watchlist.data?.items.map((i) => i.symbol) ?? []),
    [watchlist.data?.items]
  );

  const toggleWatch = (symbol: string) => {
    if (watchedSymbols.has(symbol)) {
      removeFromWatchlist.mutate(symbol, {
        onSuccess: () => toast.success(`${symbol} removed from watchlist`),
      });
    } else {
      addToWatchlist.mutate(symbol, {
        onSuccess: () => toast.success(`${symbol} added to watchlist`),
      });
    }
  };

  return (
    <Card className="bg-card/60">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div className="space-y-1">
            <CardTitle className="text-base">Market movers</CardTitle>
            <CardDescription className="text-xs">
              Largest intraday swings · live ticks
            </CardDescription>
          </div>
          <span className="font-mono text-[11px] uppercase tracking-widest text-terminal">
            OVERVIEW
          </span>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {isPending ? (
          <div className="divide-y divide-border/60 px-0 pb-1" aria-hidden="true">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 px-6 py-3">
                <Skeleton className="size-9 rounded-md" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3.5 w-24" />
                  <Skeleton className="h-3 w-36" />
                </div>
                <Skeleton className="h-3.5 w-16" />
              </div>
            ))}
          </div>
        ) : isError ? (
          <p role="alert" className="px-6 py-8 text-sm text-loss">
            Market feed unavailable — retrying…
          </p>
        ) : movers.length === 0 ? (
          <div className="flex flex-col items-center gap-2 px-6 py-10 text-center">
            <p className="text-sm text-muted-foreground">No movers right now.</p>
            <p className="text-xs text-muted-foreground">
              The feed may be warming up — check back shortly.
            </p>
          </div>
        ) : (
          <ul
            className="thin-scroll max-h-96 divide-y divide-border/60 overflow-y-auto"
            aria-label="Market movers list"
          >
            {movers.map((q) => {
              const watched = watchedSymbols.has(q.symbol);
              const pending =
                addToWatchlist.isPending || removeFromWatchlist.isPending;
              return (
                <MoverRow
                  key={q.symbol}
                  quote={q}
                  live={live[q.symbol]}
                  watched={watched}
                  pending={pending}
                  onToggle={() => toggleWatch(q.symbol)}
                  onOpen={onOpen}
                />
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

function MoverRow({
  quote,
  live,
  watched,
  pending,
  onToggle,
  onOpen,
}: {
  quote: MarketQuote;
  live?: TickQuote;
  watched: boolean;
  pending: boolean;
  onToggle: () => void;
  onOpen?: (symbol: string) => void;
}) {
  const isIndex = live ? live.type === "INDEX" : quote.type === "INDEX";
  const last = live?.lastPriceCents ?? quote.lastPriceCents;
  const pct = live?.changePct ?? quote.changePct;
  const volume = live?.volume ?? quote.volume;
  const flash = useFlash(last);

  return (
    <li className="flex items-center gap-1 pl-1 pr-3 sm:pl-2 sm:pr-5">
      <Button
        variant="ghost"
        size="icon"
        className="size-11 shrink-0"
        aria-label={
          watched
            ? `Remove ${quote.symbol} from watchlist`
            : `Add ${quote.symbol} to watchlist`
        }
        aria-pressed={watched}
        disabled={pending}
        onClick={onToggle}
      >
        <Star
          className={cn(
            "size-4",
            watched ? "fill-terminal text-terminal" : "text-muted-foreground"
          )}
          aria-hidden="true"
        />
      </Button>

      <button
        type="button"
        className="flex min-w-0 flex-1 items-center justify-between gap-3 rounded-md px-2 py-2 text-left transition-colors hover:bg-accent/50 focus-visible:bg-accent/50 focus-visible:outline-none"
        onClick={() => onOpen?.(quote.symbol)}
        aria-label={`Open ${quote.symbol} details`}
      >
        <div className="min-w-0">
          <p className="flex items-center gap-2">
            <span className="font-mono text-sm font-semibold">{quote.symbol}</span>
            <Badge
              variant="outline"
              className="px-1.5 py-0 text-[10px] text-muted-foreground"
            >
              {quote.type}
            </Badge>
          </p>
          <p className="truncate text-xs text-muted-foreground">{quote.name}</p>
        </div>

        <div className="shrink-0 text-right">
          <p
            className={cn(
              "font-mono text-sm tabular-nums transition-colors duration-500",
              flash === "up" && "bg-profit/15 text-profit",
              flash === "down" && "bg-loss/15 text-loss"
            )}
          >
            {isIndex ? formatPts(last) : formatInr(last)}
          </p>
          <p className="font-mono text-xs tabular-nums">
            <span className={pct >= 0 ? "text-profit" : "text-loss"}>
              {trendGlyph(pct)} {formatSignedPct(pct)}
            </span>
            {!isIndex ? (
              <span className="text-muted-foreground"> · {formatVolume(volume)}</span>
            ) : null}
          </p>
        </div>
      </button>
    </li>
  );
}
