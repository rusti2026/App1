"use client";

/**
 * Risk console (Phase 4 §8d, ADMIN only) — runtime trading kill switch.
 * The Switch never flips locally: tapping it opens a confirm dialog and the
 * state only settles when the POST /api/admin/risk toggle succeeds (audited
 * server-side, matcher skips fills while ON).
 */

import { useState } from "react";
import { ShieldAlert } from "lucide-react";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { useRiskStatus, useToggleKillSwitch } from "@/hooks/use-risk";
import { cn } from "@/lib/utils";

export function RiskConsoleCard() {
  const { data, isPending } = useRiskStatus();
  const toggle = useToggleKillSwitch();
  const [dialogOpen, setDialogOpen] = useState(false);

  const killSwitch = data?.killSwitch ?? false;

  return (
    <Card className="bg-card/60">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2 text-base">
              <ShieldAlert className="size-4 text-terminal" aria-hidden="true" />
              Risk console
            </CardTitle>
            <CardDescription className="text-xs">
              Trading kill switch · risk desk controls
            </CardDescription>
          </div>
          <span className="font-mono text-[11px] uppercase tracking-widest text-terminal">
            RISK
          </span>
        </div>
      </CardHeader>
      <CardContent>
        {isPending ? (
          <div className="flex items-center justify-between gap-3" aria-hidden="true">
            <div className="min-w-0 space-y-1.5">
              <Skeleton className="h-4 w-28" />
              <Skeleton className="h-3 w-44" />
            </div>
            <Skeleton className="h-6 w-11 shrink-0 rounded-full" />
          </div>
        ) : (
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="flex items-center gap-2 font-mono text-sm font-semibold">
                <span
                  aria-hidden="true"
                  className={cn(
                    "size-2 shrink-0 rounded-full",
                    killSwitch ? "bg-loss" : "animate-pulse bg-profit motion-reduce:animate-none"
                  )}
                />
                <span className={cn("min-w-0 truncate", killSwitch && "text-loss")}>
                  {killSwitch ? "TRADING PAUSED" : "Trading live"}
                </span>
              </p>
              <p className="mt-0.5 text-xs text-muted-foreground">
                {killSwitch
                  ? "New orders are rejected; resting orders stay untouched."
                  : "Order placement and matching are running normally."}
              </p>
              {data?.source === "env" ? (
                <p className="mt-1 font-mono text-[10px] text-terminal">
                  Boot-time env override active
                </p>
              ) : null}
            </div>

            <AlertDialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <AlertDialogTrigger asChild>
                <Switch
                  checked={killSwitch}
                  disabled={toggle.isPending}
                  aria-label="Toggle trading kill switch"
                />
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>
                    {killSwitch ? "Resume trading?" : "Pause all trading?"}
                  </AlertDialogTitle>
                  <AlertDialogDescription>
                    {killSwitch
                      ? "Order placement and matching resume immediately for every user."
                      : "Open orders stay resting; new orders are rejected."}
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    className={cn(
                      !killSwitch && "bg-loss text-white hover:bg-loss/90"
                    )}
                    onClick={() => toggle.mutate(!killSwitch)}
                  >
                    {killSwitch ? "Resume trading" : "Pause trading"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
