"use client";

/**
 * Instrument detail dialog — the trading centerpiece (§6a + §6b).
 *
 * Left column:  live candlestick chart (90 daily bars from /api/candles, last
 *               bar updated by WS ticks), SMA20/SMA50 overlays, RSI(14) pane,
 *               5×5 order-book depth.
 * Right column: order ticket — MARKET/LIMIT/SL-M/SL/GTT plus CO (Cover) and
 *               BO (Bracket) strategy families, CNC|MIS products, ₹ price
 *               inputs, AMO queueing, live margin line (§8a), est. total,
 *               risk-reject inline alerts, price-alert popover, POST
 *               /api/orders.
 *
 * Charts: lightweight-charts v5 (addSeries API), theme-aware (recreated on
 * theme change), responsive via ResizeObserver, disposed when dialog closes.
 */

import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import {
  createChart,
  CandlestickSeries,
  CrosshairMode,
  HistogramSeries,
  LineSeries,
  LineStyle,
  type CandlestickData,
  type HistogramData,
  type IChartApi,
  type ISeriesApi,
  type LineData,
  type Time,
} from "lightweight-charts";
import { AlertTriangle, Bell, Info } from "lucide-react";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { apiFetch, ApiError } from "@/lib/api-client";
import { useCreateAlert } from "@/hooks/use-alerts";
import { useMargin } from "@/hooks/use-margin";
import { usePortfolioSummary } from "@/hooks/use-portfolio";
import { usePlaceOrder } from "@/hooks/use-orders";
import { useDepth, useQuoteSocket } from "@/hooks/use-quotes";
import {
  formatInr,
  formatPts,
  formatSignedInr,
  formatSignedPts,
  formatSignedPct,
  formatVolume,
  trendGlyph,
} from "@/components/meridian/format";
import { cn } from "@/lib/utils";
import type {
  AlertCondition,
  CandlesResponse,
  MarginRequest,
  OrderKind,
  OrderProduct,
  OrderSide,
  PlaceOrderPayload,
  TickQuote,
} from "@/lib/types";

/* ---------- palette (brand emerald/red/amber only — never cool hues) ---------- */

const UP = "#22c07a";
const DOWN = "#ef5350";
const AMBER = "#f5a623";
const SAGE = "#5f9e82"; // muted emerald for SMA50

function chartPalette(dark: boolean) {
  return dark
    ? {
        textColor: "rgba(196, 210, 203, 0.72)",
        gridColor: "rgba(148, 163, 158, 0.10)",
        crosshair: "rgba(148, 163, 158, 0.45)",
      }
    : {
        textColor: "rgba(52, 60, 56, 0.78)",
        gridColor: "rgba(52, 60, 56, 0.10)",
        crosshair: "rgba(52, 60, 56, 0.45)",
      };
}

/* ---------- chart helpers ---------- */

interface ChartBar {
  time: string; // YYYY-MM-DD (daily bars)
  open: number; // rupees
  high: number;
  low: number;
  close: number;
  volume: number;
}

function computeSma(bars: ChartBar[], period: number): LineData<Time>[] {
  const out: LineData<Time>[] = [];
  let sum = 0;
  for (let i = 0; i < bars.length; i++) {
    sum += bars[i].close;
    if (i >= period) sum -= bars[i - period].close;
    if (i >= period - 1) {
      out.push({ time: bars[i].time as Time, value: sum / period });
    }
  }
  return out;
}

/** Wilder RSI(14). */
function computeRsi(bars: ChartBar[], period = 14): LineData<Time>[] {
  if (bars.length <= period) return [];
  const out: LineData<Time>[] = [];
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const delta = bars[i].close - bars[i - 1].close;
    if (delta >= 0) gain += delta;
    else loss -= delta;
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;
  const push = (time: string) => {
    const value = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
    out.push({ time: time as Time, value });
  };
  push(bars[period].time);
  for (let i = period + 1; i < bars.length; i++) {
    const delta = bars[i].close - bars[i - 1].close;
    avgGain = (avgGain * (period - 1) + Math.max(delta, 0)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(-delta, 0)) / period;
    push(bars[i].time);
  }
  return out;
}

function todayKey(): string {
  // The simulated feed is a continuous market — stamp live ticks with the
  // server-local date so the appended/updated bar lines up with history.
  return new Date().toISOString().slice(0, 10);
}

/* ---------- component ---------- */

export function InstrumentDetailDialog({
  symbol,
  onClose,
  prefillSide = "BUY",
}: {
  symbol: string | null;
  onClose: () => void;
  prefillSide?: OrderSide;
}) {
  const open = symbol !== null;

  return (
    <Dialog open={open} onOpenChange={(next) => (!next ? onClose() : undefined)}>
      <DialogContent
        className="max-h-[92vh] max-w-3xl overflow-y-auto thin-scroll"
        aria-describedby="instrument-detail-desc"
      >
        {symbol ? (
          <InstrumentDetail symbol={symbol} onClose={onClose} prefillSide={prefillSide} />
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

function InstrumentDetail({
  symbol,
  onClose,
  prefillSide,
}: {
  symbol: string;
  onClose: () => void;
  prefillSide: OrderSide;
}) {
  const { quotes } = useQuoteSocket([symbol]);
  const quote: TickQuote | undefined = quotes[symbol];
  const isIndex = quote ? quote.type === "INDEX" : false;
  const last = quote?.lastPriceCents;
  const changePct = quote?.changePct ?? 0;
  const changeCents = quote?.changeCents ?? 0;

  const { data: candles, isPending: candlesPending } = useQuery({
    queryKey: ["candles", symbol],
    queryFn: () =>
      apiFetch<CandlesResponse>(`/api/candles?symbol=${encodeURIComponent(symbol)}&tf=DAY`),
    enabled: !!symbol,
    staleTime: 60_000,
  });

  return (
    <>
      <DialogHeader>
        <div className="flex flex-wrap items-center gap-2 pr-6">
          <DialogTitle className="font-mono text-lg tracking-wider" aria-label={`${symbol} details`}>
            {symbol}
          </DialogTitle>
          <Badge variant="outline" className="text-[10px] text-muted-foreground">
            {quote?.exchange ?? "NSE"}
          </Badge>
          {isIndex ? (
            <Badge variant="outline" className="border-terminal/40 bg-terminal/10 text-[10px] text-terminal">
              INDEX · not tradeable
            </Badge>
          ) : null}
        </div>
        <DialogDescription id="instrument-detail-desc" className="sr-only">
          {quote?.name ?? symbol} live chart, depth and order ticket
        </DialogDescription>
        <p className="truncate text-sm text-muted-foreground">{quote?.name ?? "Loading…"}</p>
        <div className="mt-1 flex flex-wrap items-baseline gap-x-3 gap-y-1">
          <span
            className="font-mono text-3xl font-semibold tabular-nums"
          >
            {last !== undefined ? (isIndex ? formatPts(last) : formatInr(last)) : "—"}
          </span>
          <span
            className={cn(
              "font-mono text-sm tabular-nums",
              changePct > 0 ? "text-profit" : changePct < 0 ? "text-loss" : "text-muted-foreground"
            )}
          >
            {trendGlyph(changePct)} {formatSignedPct(changePct)}{" "}
            {isIndex ? formatSignedPts(changeCents) : formatSignedInr(changeCents)}
          </span>
          {quote ? (
            <span className="font-mono text-[11px] text-muted-foreground">
              Vol {formatVolume(quote.volume)} · O {formatPts(quote.openCents)} · H{" "}
              {formatPts(quote.highCents)} · L {formatPts(quote.lowCents)}
            </span>
          ) : null}
        </div>
      </DialogHeader>

      <div className="mt-2 grid gap-4 md:grid-cols-[minmax(0,1fr)_264px]">
        <div className="min-w-0 space-y-3">
          <CandleChart
            symbol={symbol}
            bars={candles?.bars}
            isPending={candlesPending}
            liveLast={last}
          />
          <DepthPanel symbol={symbol} isIndex={isIndex} />
        </div>
        {isIndex ? (
          <div className="rounded-md border border-border/60 bg-card/40 p-4 text-xs text-muted-foreground">
            <Info className="mb-2 size-4 text-terminal" aria-hidden="true" />
            Index benchmarks are not tradeable. Open a stock from the watchlist
            or movers to place an order.
          </div>
        ) : (
          <OrderTicket
            key={`${symbol}:${prefillSide}`}
            symbol={symbol}
            quote={quote}
            prefillSide={prefillSide}
          />
        )}
      </div>
    </>
  );
}

/* ---------------- candlestick + RSI charts ---------------- */

function CandleChart({
  symbol,
  bars,
  isPending,
  liveLast,
}: {
  symbol: string;
  bars?: { t: string; openCents: number; highCents: number; lowCents: number; closeCents: number; volume: number }[];
  isPending: boolean;
  liveLast?: number;
}) {
  const { resolvedTheme } = useTheme();
  const dark = resolvedTheme !== "light";

  const mainRef = useRef<HTMLDivElement | null>(null);
  const rsiRef = useRef<HTMLDivElement | null>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const rsiChartRef = useRef<IChartApi | null>(null);
  const candleSeries = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const volumeSeries = useRef<ISeriesApi<"Histogram"> | null>(null);
  const sma20Series = useRef<ISeriesApi<"Line"> | null>(null);
  const sma50Series = useRef<ISeriesApi<"Line"> | null>(null);
  const rsiSeries = useRef<ISeriesApi<"Line"> | null>(null);
  const barsState = useRef<ChartBar[]>([]);

  // (Re)create charts when data or theme changes; dispose on close.
  useEffect(() => {
    if (!bars || bars.length === 0) return;
    const mainEl = mainRef.current;
    const rsiEl = rsiRef.current;
    if (!mainEl || !rsiEl) return;

    const palette = chartPalette(dark);
    const priceFormat = { type: "price" as const, precision: 2, minMove: 0.05 };

    const chart = createChart(mainEl, {
      height: 320,
      autoSize: false,
      layout: {
        background: { color: "transparent" },
        textColor: palette.textColor,
        attributionLogo: false,
      },
      grid: {
        vertLines: { color: palette.gridColor },
        horzLines: { color: palette.gridColor },
      },
      rightPriceScale: { borderColor: palette.gridColor },
      timeScale: { borderColor: palette.gridColor, visible: true },
      crosshair: { mode: CrosshairMode.Normal },
    });
    chartRef.current = chart;

    const candleApi = chart.addSeries(CandlestickSeries, {
      upColor: UP,
      downColor: DOWN,
      wickUpColor: UP,
      wickDownColor: DOWN,
      borderVisible: false,
      priceFormat,
    });
    const volumeApi = chart.addSeries(HistogramSeries, {
      priceFormat: { type: "volume" },
      priceScaleId: "",
      color: "rgba(95, 158, 130, 0.4)",
    });
    chart.priceScale("").applyOptions({
      scaleMargins: { top: 0.82, bottom: 0 },
      visible: false,
    });
    const sma20Api = chart.addSeries(LineSeries, {
      color: AMBER,
      lineWidth: 1,
      priceLineVisible: false,
      lastValueVisible: false,
      crosshairMarkerVisible: false,
    });
    const sma50Api = chart.addSeries(LineSeries, {
      color: SAGE,
      lineWidth: 1,
      priceLineVisible: false,
      lastValueVisible: false,
      crosshairMarkerVisible: false,
    });

    const chartBars: ChartBar[] = bars.map((b) => ({
      time: b.t.slice(0, 10),
      open: b.openCents / 100,
      high: b.highCents / 100,
      low: b.lowCents / 100,
      close: b.closeCents / 100,
      volume: b.volume,
    }));
    barsState.current = chartBars;

    const candleData: CandlestickData<Time>[] = chartBars.map((b) => ({
      time: b.time as Time,
      open: b.open,
      high: b.high,
      low: b.low,
      close: b.close,
    }));
    const volumeData: HistogramData<Time>[] = chartBars.map((b) => ({
      time: b.time as Time,
      value: b.volume,
      color: b.close >= b.open ? "rgba(34, 192, 122, 0.35)" : "rgba(239, 83, 80, 0.35)",
    }));
    candleApi.setData(candleData);
    volumeApi.setData(volumeData);
    sma20Api.setData(computeSma(chartBars, 20));
    sma50Api.setData(computeSma(chartBars, 50));
    chart.timeScale().fitContent();

    candleSeries.current = candleApi;
    volumeSeries.current = volumeApi;
    sma20Series.current = sma20Api;
    sma50Series.current = sma50Api;

    // RSI pane
    const rsiChart = createChart(rsiEl, {
      height: 90,
      autoSize: false,
      layout: {
        background: { color: "transparent" },
        textColor: palette.textColor,
        attributionLogo: false,
      },
      grid: {
        vertLines: { visible: false },
        horzLines: { color: palette.gridColor },
      },
      rightPriceScale: { borderColor: palette.gridColor },
      timeScale: { borderColor: palette.gridColor, visible: false },
    });
    rsiChartRef.current = rsiChart;
    const rsiApi = rsiChart.addSeries(LineSeries, {
      color: AMBER,
      lineWidth: 1,
      priceLineVisible: false,
      autoscaleInfoProvider: () => ({
        priceRange: { minValue: 0, maxValue: 100 },
      }),
    });
    const rsiData = computeRsi(chartBars);
    rsiApi.setData(rsiData);
    rsiApi.createPriceLine({
      price: 70,
      color: DOWN,
      lineWidth: 1,
      lineStyle: LineStyle.Dashed,
      axisLabelVisible: true,
      title: "70",
    });
    rsiApi.createPriceLine({
      price: 30,
      color: UP,
      lineWidth: 1,
      lineStyle: LineStyle.Dashed,
      axisLabelVisible: true,
      title: "30",
    });
    rsiSeries.current = rsiApi;

    // Responsive sizing
    const ro = new ResizeObserver(() => {
      chart.applyOptions({ width: mainEl.clientWidth });
      rsiChart.applyOptions({ width: rsiEl.clientWidth });
    });
    ro.observe(mainEl);
    ro.observe(rsiEl);
    chart.applyOptions({ width: mainEl.clientWidth });
    rsiChart.applyOptions({ width: rsiEl.clientWidth });

    return () => {
      ro.disconnect();
      chart.remove();
      rsiChart.remove();
      chartRef.current = null;
      rsiChartRef.current = null;
      candleSeries.current = null;
      volumeSeries.current = null;
      sma20Series.current = null;
      sma50Series.current = null;
      rsiSeries.current = null;
    };
  }, [bars, dark]);

  // Live tick → update/append the last candle + last RSI point.
  useEffect(() => {
    if (liveLast === undefined) return;
    const lastRupees = liveLast / 100;
    const bars = barsState.current;
    const lastBar = bars[bars.length - 1];
    if (!lastBar) return;

    const tickDay = todayKey();
    if (tickDay > lastBar.time) {
      bars.push({
        time: tickDay,
        open: lastBar.close,
        high: lastRupees,
        low: lastRupees,
        close: lastRupees,
        volume: 0,
      });
    } else {
      lastBar.close = lastRupees;
      lastBar.high = Math.max(lastBar.high, lastRupees);
      lastBar.low = Math.min(lastBar.low, lastRupees);
    }
    const bar = bars[bars.length - 1];
    candleSeries.current?.update({
      time: bar.time as Time,
      open: bar.open,
      high: bar.high,
      low: bar.low,
      close: bar.close,
    });
    sma20Series.current?.update({ time: bar.time as Time, value: smaAt(bars, 20) });
    sma50Series.current?.update({ time: bar.time as Time, value: smaAt(bars, 50) });
    const rsiPoints = computeRsi(bars);
    const lastRsi = rsiPoints[rsiPoints.length - 1];
    if (lastRsi) rsiSeries.current?.update(lastRsi);
  }, [liveLast]);

  if (isPending) {
    return (
      <div className="space-y-2" aria-hidden="true">
        <Skeleton className="h-80 w-full rounded-md" />
        <Skeleton className="h-[90px] w-full rounded-md" />
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-3 px-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        <span className="flex items-center gap-1">
          <span aria-hidden="true" className="inline-block h-0.5 w-3 bg-[#f5a623]" /> SMA20
        </span>
        <span className="flex items-center gap-1">
          <span aria-hidden="true" className="inline-block h-0.5 w-3 bg-[#5f9e82]" /> SMA50
        </span>
        <span>Daily · RSI(14)</span>
      </div>
      <div ref={mainRef} className="h-80 w-full" role="img" aria-label={`${symbol} candlestick chart`} />
      <div ref={rsiRef} className="h-[90px] w-full" role="img" aria-label={`${symbol} RSI chart`} />
    </div>
  );
}

/** SMA value at the last index (≥ period bars), for live series.update. */
function smaAt(bars: ChartBar[], period: number): number {
  const n = Math.min(period, bars.length);
  let sum = 0;
  for (let i = bars.length - n; i < bars.length; i++) sum += bars[i].close;
  return sum / n;
}

/* ---------------- depth panel ---------------- */

function DepthPanel({ symbol, isIndex }: { symbol: string; isIndex: boolean }) {
  const depth = useDepth(symbol);
  const fmt = isIndex ? formatPts : formatInr;

  const bestBid = depth?.bids[0]?.priceCents;
  const bestAsk = depth?.asks[0]?.priceCents;
  const spread = bestBid !== undefined && bestAsk !== undefined ? bestAsk - bestBid : null;

  return (
    <div className="rounded-md border border-border/60 bg-card/40 p-3">
      <div className="mb-2 flex items-center justify-between">
        <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
          Order book · 5 levels
        </span>
        <span className="font-mono text-[10px] tabular-nums text-muted-foreground">
          Spread {spread !== null ? fmt(spread) : "—"}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <DepthColumn levels={depth?.bids} fmt={fmt} side="bid" />
        <DepthColumn levels={depth?.asks} fmt={fmt} side="ask" />
      </div>
    </div>
  );
}

function DepthColumn({
  levels,
  fmt,
  side,
}: {
  levels?: { priceCents: number; qty: number }[];
  fmt: (paise: number) => string;
  side: "bid" | "ask";
}) {
  const rows = levels ?? [];
  return (
    <div>
      <p
        className={cn(
          "mb-1 font-mono text-[10px] font-semibold uppercase tracking-widest",
          side === "bid" ? "text-profit" : "text-loss"
        )}
      >
        {side === "bid" ? "Bids" : "Asks"}
      </p>
      <ul className="space-y-0.5" aria-label={side === "bid" ? "Bid levels" : "Ask levels"}>
        {Array.from({ length: 5 }).map((_, i) => {
          const level = rows[i];
          // intensity fades with distance from the touch
          const intensity = 0.16 - i * 0.025;
          return (
            <li
              key={i}
              className="flex items-center justify-between rounded px-1.5 py-0.5 font-mono text-xs tabular-nums"
              style={{
                backgroundColor:
                  level === undefined
                    ? undefined
                    : side === "bid"
                      ? `rgba(34, 192, 122, ${Math.max(intensity, 0.03)})`
                      : `rgba(239, 83, 80, ${Math.max(intensity, 0.03)})`,
              }}
            >
              <span className={side === "bid" ? "text-profit" : "text-loss"}>
                {level ? fmt(level.priceCents) : "—"}
              </span>
              <span className="text-muted-foreground">
                {level ? formatVolume(level.qty) : "—"}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

/* ---------------- order ticket ---------------- */

/**
 * Selector state for the ticket. CO/BO are strategy *families* (§8b): the
 * payload carries `strategy` while `type` becomes the entry kind (MARKET or
 * LIMIT), so they are not OrderKind values themselves.
 */
type TicketKind = OrderKind | "CO" | "BO";

const ORDER_TYPES: Array<{ value: TicketKind; label: string }> = [
  { value: "MARKET", label: "MARKET" },
  { value: "LIMIT", label: "LIMIT" },
  { value: "STOP", label: "SL-M" },
  { value: "STOP_LIMIT", label: "SL" },
  { value: "GTT", label: "GTT" },
  { value: "CO", label: "CO · Cover" },
  { value: "BO", label: "BO · Bracket" },
];

/** GTT expiry presets → days out (ISO computed at submit). */
const GTT_EXPIRY_OPTIONS = [
  { value: "1W", label: "1 week", days: 7 },
  { value: "1M", label: "1 month", days: 30 },
  { value: "3M", label: "3 months", days: 90 },
] as const;

type GttExpiry = (typeof GTT_EXPIRY_OPTIONS)[number]["value"];

const GTT_EXPIRY_DAYS: Record<GttExpiry, number> = Object.fromEntries(
  GTT_EXPIRY_OPTIONS.map((o) => [o.value, o.days])
) as Record<GttExpiry, number>;

/**
 * Default GTT trigger in paise: LTP −0.5% for BUY / +0.5% for SELL, snapped
 * to the ₹0.05 tick. Null when no live quote yet.
 */
function defaultGttTriggerPaise(lastPriceCents: number, side: OrderSide): number {
  const raw = side === "BUY" ? lastPriceCents * 0.995 : lastPriceCents * 1.005;
  return Math.round(raw / 5) * 5;
}

/**
 * CO/BO default SL trigger (paise): protective side of the LTP (∓0.5%).
 */
function defaultStrategyStopPaise(
  lastPriceCents: number,
  side: OrderSide
): number {
  const raw = side === "BUY" ? lastPriceCents * 0.995 : lastPriceCents * 1.005;
  return Math.round(raw / 5) * 5;
}

/** BO default target (paise): profit side of the LTP (±1%). */
function defaultBoTargetPaise(
  lastPriceCents: number,
  side: OrderSide
): number {
  const raw = side === "BUY" ? lastPriceCents * 1.01 : lastPriceCents * 0.99;
  return Math.round(raw / 5) * 5;
}

/** Inputs for the margin-estimator payload builder (§8a). */
interface MarginRequestInputs {
  kind: TicketKind;
  product: OrderProduct;
  symbol: string;
  side: OrderSide;
  entryType: "MARKET" | "LIMIT";
  parsedQty: number;
  parsedLimit: number;
  parsedStop: number;
  isGtt: boolean;
  gttLimitPaise: number;
  gttTriggerPaise: number;
  strategyStopPaise: number;
  strategyTargetPaise: number;
}

/**
 * Margin-estimator request for the live ticket (§8a) — CO/BO force MIS;
 * plain MIS kinds estimate too, CNC returns null and skips the endpoint
 * entirely (plain order-value line instead).
 */
function buildMarginRequest(inputs: MarginRequestInputs): MarginRequest | null {
  const {
    kind,
    product,
    symbol,
    side,
    entryType,
    parsedQty,
    parsedLimit,
    parsedStop,
    isGtt,
    gttLimitPaise,
    gttTriggerPaise,
    strategyStopPaise,
    strategyTargetPaise,
  } = inputs;
  if (!Number.isFinite(parsedQty) || parsedQty < 1) return null;
  if (kind === "CO" || kind === "BO") {
    if (Number.isNaN(strategyStopPaise) || strategyStopPaise < 5) return null;
    if (
      kind === "BO" &&
      (Number.isNaN(strategyTargetPaise) || strategyTargetPaise < 5)
    )
      return null;
    return {
      symbol,
      side,
      type: entryType,
      qty: parsedQty,
      product: "MIS",
      strategy: kind,
      ...(entryType === "LIMIT" && !Number.isNaN(parsedLimit) && parsedLimit > 0
        ? { limitPriceCents: Math.round(parsedLimit * 100) }
        : {}),
      stopPriceCents: strategyStopPaise,
      ...(kind === "BO" ? { targetCents: strategyTargetPaise } : {}),
    };
  }
  if (product !== "MIS") return null;
  return {
    symbol,
    side,
    type: kind,
    qty: parsedQty,
    product: "MIS",
    ...(kind === "LIMIT" || kind === "STOP_LIMIT"
      ? { limitPriceCents: Math.round(parsedLimit * 100) }
      : {}),
    ...(kind === "STOP" || kind === "STOP_LIMIT"
      ? { stopPriceCents: Math.round(parsedStop * 100) }
      : {}),
    ...(isGtt && !Number.isNaN(gttLimitPaise)
      ? { limitPriceCents: gttLimitPaise }
      : {}),
    ...(isGtt && !Number.isNaN(gttTriggerPaise)
      ? { stopPriceCents: gttTriggerPaise }
      : {}),
  };
}

interface TicketReject {
  message: string;
  code?: string;
}

function OrderTicket({
  symbol,
  quote,
  prefillSide,
}: {
  symbol: string;
  quote: TickQuote | undefined;
  prefillSide: OrderSide;
}) {
  const queryClient = useQueryClient();
  const { data: portfolio } = usePortfolioSummary();
  const placeOrder = usePlaceOrder();

  const [side, setSide] = useState<OrderSide>(prefillSide);
  const [kind, setKind] = useState<TicketKind>("MARKET");
  const [qty, setQty] = useState("1");
  const [limitPrice, setLimitPrice] = useState(""); // ₹
  const [stopPrice, setStopPrice] = useState(""); // ₹
  const [reject, setReject] = useState<TicketReject | null>(null);
  // GTT: trigger/limit in ₹, expiry preset. State holds only user-edited
  // values; the displayed trigger/limit are DERIVED and follow the LTP
  // (∓0.5% default, limit = trigger) until the user types — no effects.
  const [gttTrigger, setGttTrigger] = useState("");
  const [gttLimit, setGttLimit] = useState("");
  const [gttTriggerDirty, setGttTriggerDirty] = useState(false);
  const [gttLimitDirty, setGttLimitDirty] = useState(false);
  const [gttExpiry, setGttExpiry] = useState<GttExpiry>("1W");
  // After-market order — queues the order for the next simulated session open.
  const [amo, setAmo] = useState(false);
  // CO/BO: entry type + protective/profit levels. Same derived-default
  // pattern as GTT — the values follow the LTP until the user edits them.
  const [entryType, setEntryType] = useState<"MARKET" | "LIMIT">("MARKET");
  const [strategyStop, setStrategyStop] = useState(""); // ₹ SL trigger
  const [strategyStopDirty, setStrategyStopDirty] = useState(false);
  const [strategyTarget, setStrategyTarget] = useState(""); // ₹ BO target
  const [strategyTargetDirty, setStrategyTargetDirty] = useState(false);
  // CNC (delivery, 1x) vs MIS (intraday, 5x) — strategy families force MIS.
  const [product, setProduct] = useState<OrderProduct>("CNC");
  // Per-symbol state is reset by remounting (key={symbol:side} at the call site).

  const lastRupees = quote ? quote.lastPriceCents / 100 : undefined;
  const parsedQty = Math.floor(Number(qty));
  const parsedLimit = limitPrice.trim() === "" ? NaN : Number(limitPrice);
  const parsedStop = stopPrice.trim() === "" ? NaN : Number(stopPrice);
  const needsLimit = kind === "LIMIT" || kind === "STOP_LIMIT";
  const needsStop = kind === "STOP" || kind === "STOP_LIMIT";
  const isGtt = kind === "GTT";
  const isAmoKind = kind === "MARKET" || kind === "LIMIT";
  const isStrategy = kind === "CO" || kind === "BO";
  const isBracket = kind === "BO";

  // GTT defaults — derived from the live quote (LTP ∓0.5%, ₹0.05 tick) and
  // the limit mirrors the trigger until the user edits either field.
  const gttDefaultPaise = useMemo(() => {
    if (!quote) return null;
    return defaultGttTriggerPaise(quote.lastPriceCents, side);
  }, [quote, side]);

  const displayedGttTrigger = isGtt
    ? gttTriggerDirty
      ? gttTrigger
      : gttDefaultPaise !== null
        ? (gttDefaultPaise / 100).toFixed(2)
        : ""
    : "";
  const displayedGttLimit =
    isGtt && gttLimitDirty ? gttLimit : displayedGttTrigger;

  const parsedGttTrigger = displayedGttTrigger.trim() === "" ? NaN : Number(displayedGttTrigger);
  const parsedGttLimit = displayedGttLimit.trim() === "" ? NaN : Number(displayedGttLimit);
  const gttTriggerPaise = Number.isNaN(parsedGttTrigger)
    ? NaN
    : Math.round(parsedGttTrigger * 100);
  const gttLimitPaise = Number.isNaN(parsedGttLimit)
    ? NaN
    : Math.round(parsedGttLimit * 100);

  // CO/BO defaults — same live-tracking pattern as GTT: the SL trigger trails
  // the LTP by 0.5% on the protective side, the BO target leads by 1% on the
  // profit side (₹0.05 tick) until the user edits either field.
  const strategyStopDefaultPaise = quote
    ? defaultStrategyStopPaise(quote.lastPriceCents, side)
    : null;
  const strategyTargetDefaultPaise = quote
    ? defaultBoTargetPaise(quote.lastPriceCents, side)
    : null;

  const displayedStrategyStop = isStrategy
    ? strategyStopDirty
      ? strategyStop
      : strategyStopDefaultPaise !== null
        ? (strategyStopDefaultPaise / 100).toFixed(2)
        : ""
    : "";
  const displayedStrategyTarget =
    isStrategy && isBracket
      ? strategyTargetDirty
        ? strategyTarget
        : strategyTargetDefaultPaise !== null
          ? (strategyTargetDefaultPaise / 100).toFixed(2)
          : ""
      : "";

  const parsedStrategyStop =
    displayedStrategyStop.trim() === "" ? NaN : Number(displayedStrategyStop);
  const strategyStopPaise = Number.isNaN(parsedStrategyStop)
    ? NaN
    : Math.round(parsedStrategyStop * 100);
  const parsedStrategyTarget =
    displayedStrategyTarget.trim() === "" ? NaN : Number(displayedStrategyTarget);
  const strategyTargetPaise = Number.isNaN(parsedStrategyTarget)
    ? NaN
    : Math.round(parsedStrategyTarget * 100);

  const limitValid = !needsLimit || (!Number.isNaN(parsedLimit) && parsedLimit > 0);
  const stopValid = !needsStop || (!Number.isNaN(parsedStop) && parsedStop > 0);
  // GTT needs a trigger ≥ ₹0.05 (5 paise) and a positive limit.
  const gttTriggerValid =
    !Number.isNaN(gttTriggerPaise) && gttTriggerPaise >= 5;
  const gttLimitValid = !Number.isNaN(gttLimitPaise) && gttLimitPaise > 0;
  // GTT trigger must stay inside the ±20% price band around the LTP.
  const gttBandOk =
    lastRupees !== undefined &&
    !Number.isNaN(parsedGttTrigger) &&
    Math.abs(parsedGttTrigger - lastRupees) <= 0.2 * lastRupees;
  const gttBandHint =
    isGtt &&
    lastRupees !== undefined &&
    !Number.isNaN(parsedGttTrigger) &&
    !gttBandOk
      ? `Trigger must stay within ±20% of LTP (₹${(lastRupees * 0.8).toFixed(2)} – ₹${(lastRupees * 1.2).toFixed(2)})`
      : null;

  // --- CO/BO leg validation (§8b) — mirrors the GTT band-hint pattern ------
  // Est. entry: the LIMIT entry price when entered, else the live LTP.
  const strategyEstEntryRupees =
    entryType === "LIMIT"
      ? Number.isNaN(parsedLimit)
        ? undefined
        : parsedLimit
      : lastRupees;
  const strategyEstEntryPaise =
    strategyEstEntryRupees !== undefined
      ? Math.round(strategyEstEntryRupees * 100)
      : undefined;

  const strategyStopPaiseValid =
    !Number.isNaN(strategyStopPaise) && strategyStopPaise >= 5;
  const strategyTargetPaiseValid =
    !isBracket || (!Number.isNaN(strategyTargetPaise) && strategyTargetPaise >= 5);
  const strategyLimitPaiseValid =
    entryType === "MARKET" || (!Number.isNaN(parsedLimit) && parsedLimit > 0);

  // Direction: BUY protects below / targets above the est. entry; SELL mirrored.
  const strategyStopSideOk =
    strategyEstEntryRupees !== undefined &&
    strategyEstEntryRupees > 0 &&
    !Number.isNaN(parsedStrategyStop) &&
    (side === "BUY"
      ? parsedStrategyStop < strategyEstEntryRupees
      : parsedStrategyStop > strategyEstEntryRupees);
  const strategyTargetSideOk =
    !isBracket ||
    (strategyEstEntryRupees !== undefined &&
      strategyEstEntryRupees > 0 &&
      !Number.isNaN(parsedStrategyTarget) &&
      (side === "BUY"
        ? parsedStrategyTarget > strategyEstEntryRupees
        : parsedStrategyTarget < strategyEstEntryRupees));

  // Every strategy price must stay inside the ±20% band around the live LTP.
  const strategyStopBandOk =
    lastRupees !== undefined &&
    !Number.isNaN(parsedStrategyStop) &&
    Math.abs(parsedStrategyStop - lastRupees) <= 0.2 * lastRupees;
  const strategyTargetBandOk =
    !isBracket ||
    (lastRupees !== undefined &&
      !Number.isNaN(parsedStrategyTarget) &&
      Math.abs(parsedStrategyTarget - lastRupees) <= 0.2 * lastRupees);
  const strategyLimitBandOk =
    entryType === "MARKET" ||
    (lastRupees !== undefined &&
      !Number.isNaN(parsedLimit) &&
      Math.abs(parsedLimit - lastRupees) <= 0.2 * lastRupees);

  const estEntryLabel =
    strategyEstEntryPaise !== undefined ? formatInr(strategyEstEntryPaise) : "—";
  const bandLabel =
    lastRupees !== undefined
      ? `₹${(lastRupees * 0.8).toFixed(2)} – ₹${(lastRupees * 1.2).toFixed(2)}`
      : "";

  // Amber inline hints — each blocks submit while visible.
  const strategyStopHint =
    !isStrategy || Number.isNaN(strategyStopPaise)
      ? null
      : !strategyStopPaiseValid
        ? "Stop trigger must be at least ₹0.05."
        : strategyEstEntryRupees !== undefined && !strategyStopSideOk
          ? `Stop-loss must be ${side === "BUY" ? "below" : "above"} the est. entry ${estEntryLabel} for a ${side} entry.`
          : lastRupees !== undefined && !strategyStopBandOk
            ? `Stop trigger must stay within ±20% of LTP (${bandLabel}).`
            : null;
  const strategyTargetHint =
    !isBracket || Number.isNaN(strategyTargetPaise)
      ? null
      : !strategyTargetPaiseValid
        ? "Target must be at least ₹0.05."
        : strategyEstEntryRupees !== undefined && !strategyTargetSideOk
          ? `Target must be ${side === "BUY" ? "above" : "below"} the est. entry ${estEntryLabel} for a ${side} entry.`
          : lastRupees !== undefined && !strategyTargetBandOk
            ? `Target must stay within ±20% of LTP (${bandLabel}).`
            : null;
  const strategyLimitHint =
    !isStrategy || entryType !== "LIMIT" || Number.isNaN(parsedLimit)
      ? null
      : lastRupees !== undefined && !strategyLimitBandOk
        ? `Entry limit must stay within ±20% of LTP (${bandLabel}).`
        : null;

  // Margin line (§8a) — CO/BO force MIS; plain MIS kinds estimate too. CNC
  // keeps the plain order-value line and skips the endpoint entirely.
  const marginRequest = buildMarginRequest({
    kind,
    product,
    symbol,
    side,
    entryType,
    parsedQty,
    parsedLimit,
    parsedStop,
    isGtt,
    gttLimitPaise,
    gttTriggerPaise,
    strategyStopPaise,
    strategyTargetPaise,
  });

  const refRupees = isGtt
    ? Number.isNaN(parsedGttLimit)
      ? undefined
      : parsedGttLimit
    : isStrategy
      ? strategyEstEntryRupees
      : needsLimit
        ? Number.isNaN(parsedLimit)
          ? undefined
          : parsedLimit
        : lastRupees;
  const estTotal =
    Number.isFinite(parsedQty) && parsedQty >= 1 && refRupees !== undefined
      ? Math.round(parsedQty * refRupees * 100)
      : null;

  const heldQty = portfolio?.positions.find((p) => p.symbol === symbol)?.qty ?? 0;
  const cash = portfolio?.cashAvailableCents ?? 0;

  const marginData = useMargin(marginRequest);
  const marginInsufficient =
    marginRequest !== null &&
    marginData.data !== undefined &&
    marginData.data.requiredCents > marginData.data.availableCents;

  const canSubmit =
    !placeOrder.isPending &&
    Number.isFinite(parsedQty) &&
    parsedQty >= 1 &&
    limitValid &&
    stopValid &&
    (!isGtt || (gttTriggerValid && gttLimitValid && gttBandOk)) &&
    (!isStrategy ||
      (strategyStopPaiseValid &&
        strategyStopSideOk &&
        strategyStopBandOk &&
        strategyLimitPaiseValid &&
        strategyLimitBandOk &&
        strategyTargetPaiseValid &&
        strategyTargetSideOk &&
        strategyTargetBandOk &&
        !marginInsufficient));

  const handleSubmit = () => {
    if (!canSubmit) return;
    setReject(null);
    let payload: PlaceOrderPayload;
    if (kind === "CO" || kind === "BO") {
      // Strategy families (§8b): MIS is forced, AMO/GTT never combine, and
      // `type` is the entry kind. SL trigger is mandatory; the target rides
      // along for BO brackets.
      payload = {
        symbol,
        side,
        type: entryType,
        strategy: kind,
        qty: parsedQty,
        product: "MIS",
        stopPriceCents: strategyStopPaise,
        ...(kind === "BO" ? { targetCents: strategyTargetPaise } : {}),
        ...(entryType === "LIMIT"
          ? { limitPriceCents: Math.round(parsedLimit * 100) }
          : {}),
        timeInForce: "DAY",
      };
    } else {
      payload = {
        symbol,
        side,
        type: kind,
        qty: parsedQty,
        product,
        ...(kind === "LIMIT" || kind === "STOP_LIMIT"
          ? { limitPriceCents: Math.round(parsedLimit * 100) }
          : {}),
        ...(kind === "STOP" || kind === "STOP_LIMIT"
          ? { stopPriceCents: Math.round(parsedStop * 100) }
          : {}),
        ...(isGtt
          ? {
              stopPriceCents: gttTriggerPaise,
              limitPriceCents: gttLimitPaise,
              expiresAt: new Date(
                Date.now() + GTT_EXPIRY_DAYS[gttExpiry] * 86_400_000
              ).toISOString(),
            }
          : {}),
        ...(amo && isAmoKind ? { amo: true } : {}),
        timeInForce: "DAY",
      };
    }
    placeOrder.mutate(payload, {
      onSuccess: (result) => {
        if (result.fill) {
          toast.success(
            `Order filled · ${result.order.side} ${result.fill.qty} ${result.order.symbol} @ ${formatInr(result.fill.priceCents)}`
          );
        } else {
          toast.success(
            `Order accepted · ${result.order.side} ${result.order.qty} ${result.order.symbol}`
          );
        }
        void queryClient.invalidateQueries({ queryKey: ["portfolio"] });
        void queryClient.invalidateQueries({ queryKey: ["orders"] });
      },
      onError: (error) => {
        if (error instanceof ApiError && error.status === 422) {
          setReject({ message: error.message, code: error.code });
        } else if (error instanceof ApiError && error.status === 403) {
          setReject({
            message: "KYC required — complete identity verification to place orders.",
            code: error.code ?? "KYC_REQUIRED",
          });
        } else {
          setReject({
            message: error instanceof Error ? error.message : "Order failed.",
            code: error instanceof ApiError ? error.code : undefined,
          });
        }
      },
    });
  };

  const stopLabel = kind === "STOP" ? "Trigger price (₹)" : "Stop trigger (₹)";

  return (
    <div className="rounded-md border border-border/60 bg-card/40 p-3">
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="font-mono text-[10px] uppercase tracking-widest text-terminal">
          ORDER TICKET
        </p>
        <AlertBellButton symbol={symbol} lastRupees={lastRupees} />
      </div>

      {/* side toggle */}
      <div className="mb-3 grid grid-cols-2 gap-2" role="radiogroup" aria-label="Order side">
        <Button
          type="button"
          variant={side === "BUY" ? "default" : "outline"}
          className={cn(
            "h-11 font-semibold",
            side === "BUY"
              ? "border-transparent bg-profit text-background hover:bg-profit/90"
              : "border-profit/40 text-profit hover:bg-profit/10 hover:text-profit"
          )}
          onClick={() => setSide("BUY")}
          aria-pressed={side === "BUY"}
        >
          BUY
        </Button>
        <Button
          type="button"
          variant={side === "SELL" ? "default" : "outline"}
          className={cn(
            "h-11 font-semibold",
            side === "SELL"
              ? "border-transparent bg-loss text-background hover:bg-loss/90"
              : "border-loss/40 text-loss hover:bg-loss/10 hover:text-loss"
          )}
          onClick={() => setSide("SELL")}
          aria-pressed={side === "SELL"}
        >
          SELL
        </Button>
      </div>

      <div className="space-y-3">
        <div className="space-y-1.5">
          <Label htmlFor="ticket-type" className="text-xs text-muted-foreground">
            Order type
          </Label>
          <Select
            value={kind}
            onValueChange={(v) => {
              const next = v as TicketKind;
              setKind(next);
              // Re-entering GTT / CO / BO re-seeds the derived defaults from LTP.
              if (next === "GTT") {
                setGttTriggerDirty(false);
                setGttLimitDirty(false);
              }
              if (next === "CO" || next === "BO") {
                setStrategyStopDirty(false);
                setStrategyTargetDirty(false);
              }
            }}
          >
            <SelectTrigger id="ticket-type" className="h-11 w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ORDER_TYPES.map((t) => (
                <SelectItem key={t.value} value={t.value}>
                  {t.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1.5">
            <Label htmlFor="ticket-qty" className="text-xs text-muted-foreground">
              Qty
            </Label>
            <Input
              id="ticket-qty"
              className="h-11 font-mono tabular-nums"
              inputMode="numeric"
              min={1}
              value={qty}
              onChange={(e) => setQty(e.target.value.replace(/\D/g, "").slice(0, 6))}
              aria-label="Quantity"
            />
          </div>
          {needsStop ? (
            <div className="space-y-1.5">
              <Label htmlFor="ticket-stop" className="text-xs text-muted-foreground">
                {stopLabel}
              </Label>
              <Input
                id="ticket-stop"
                className="h-11 font-mono tabular-nums"
                inputMode="decimal"
                placeholder={(lastRupees ?? 0).toFixed(2)}
                value={stopPrice}
                onChange={(e) => setStopPrice(e.target.value.replace(/[^\d.]/g, "").slice(0, 12))}
                aria-label={stopLabel}
              />
            </div>
          ) : (
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Last (₹)</Label>
              <p className="flex h-11 items-center font-mono text-sm tabular-nums">
                {lastRupees !== undefined ? lastRupees.toFixed(2) : "—"}
              </p>
            </div>
          )}
        </div>

        {needsLimit ? (
          <div className="space-y-1.5">
            <Label htmlFor="ticket-limit" className="text-xs text-muted-foreground">
              Limit price (₹)
            </Label>
            <Input
              id="ticket-limit"
              className="h-11 font-mono tabular-nums"
              inputMode="decimal"
              placeholder={(lastRupees ?? 0).toFixed(2)}
              value={limitPrice}
              onChange={(e) => setLimitPrice(e.target.value.replace(/[^\d.]/g, "").slice(0, 12))}
              aria-label="Limit price in rupees"
            />
          </div>
        ) : null}

        {isGtt ? (
          <>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <Label htmlFor="ticket-gtt-trigger" className="text-xs text-muted-foreground">
                  Trigger price (₹)
                </Label>
                <Input
                  id="ticket-gtt-trigger"
                  className="h-11 font-mono tabular-nums"
                  inputMode="decimal"
                  placeholder={(lastRupees ?? 0).toFixed(2)}
                  value={displayedGttTrigger}
                  onChange={(e) => {
                    setGttTrigger(e.target.value.replace(/[^\d.]/g, "").slice(0, 12));
                    setGttTriggerDirty(true);
                  }}
                  aria-label="GTT trigger price in rupees"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ticket-gtt-limit" className="text-xs text-muted-foreground">
                  Limit price (₹)
                </Label>
                <Input
                  id="ticket-gtt-limit"
                  className="h-11 font-mono tabular-nums"
                  inputMode="decimal"
                  placeholder={(lastRupees ?? 0).toFixed(2)}
                  value={displayedGttLimit}
                  onChange={(e) => {
                    setGttLimit(e.target.value.replace(/[^\d.]/g, "").slice(0, 12));
                    setGttLimitDirty(true);
                  }}
                  aria-label="GTT limit price in rupees"
                />
              </div>
            </div>
            {gttBandHint ? (
              <p role="note" className="font-mono text-[10px] leading-relaxed text-terminal">
                {gttBandHint}
              </p>
            ) : null}
            <div className="space-y-1.5">
              <Label htmlFor="ticket-gtt-expiry" className="text-xs text-muted-foreground">
                Expiry
              </Label>
              <Select
                value={gttExpiry}
                onValueChange={(v) => setGttExpiry(v as GttExpiry)}
              >
                <SelectTrigger id="ticket-gtt-expiry" className="h-11 w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {GTT_EXPIRY_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </>
        ) : null}

        {isStrategy ? (
          <div className="space-y-3 rounded-md border border-border/60 bg-background/40 p-3">
            <div className="flex items-center justify-between gap-2">
              <Label className="text-xs text-muted-foreground">Entry type</Label>
              <Badge
                variant="outline"
                className="border-terminal/40 bg-terminal/10 px-1.5 py-0 font-mono text-[10px] font-semibold text-terminal"
              >
                MIS · 5x
              </Badge>
            </div>
            <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="Entry type">
              <Button
                type="button"
                variant={entryType === "MARKET" ? "default" : "outline"}
                className="h-11 font-semibold"
                onClick={() => setEntryType("MARKET")}
                aria-pressed={entryType === "MARKET"}
              >
                Market
              </Button>
              <Button
                type="button"
                variant={entryType === "LIMIT" ? "default" : "outline"}
                className="h-11 font-semibold"
                onClick={() => setEntryType("LIMIT")}
                aria-pressed={entryType === "LIMIT"}
              >
                Limit
              </Button>
            </div>
            <p className="font-mono text-[10px] tabular-nums text-muted-foreground">
              Est. entry {" "}
              {strategyEstEntryPaise !== undefined
                ? formatInr(strategyEstEntryPaise)
                : "—"}
              {entryType === "MARKET" ? " · live LTP" : " · your limit"}
            </p>
            {entryType === "LIMIT" ? (
              <div className="space-y-1.5">
                <Label htmlFor="ticket-strategy-limit" className="text-xs text-muted-foreground">
                  Entry limit (₹)
                </Label>
                <Input
                  id="ticket-strategy-limit"
                  className="h-11 font-mono tabular-nums"
                  inputMode="decimal"
                  placeholder={(lastRupees ?? 0).toFixed(2)}
                  value={limitPrice}
                  onChange={(e) => setLimitPrice(e.target.value.replace(/[^\d.]/g, "").slice(0, 12))}
                  aria-label="Entry limit price in rupees"
                />
              </div>
            ) : null}
            {isBracket ? (
              <div className="space-y-1.5">
                <Label htmlFor="ticket-strategy-target" className="text-xs text-muted-foreground">
                  Target (₹)
                </Label>
                <Input
                  id="ticket-strategy-target"
                  className="h-11 font-mono tabular-nums"
                  inputMode="decimal"
                  placeholder={(lastRupees ?? 0).toFixed(2)}
                  value={displayedStrategyTarget}
                  onChange={(e) => {
                    setStrategyTarget(e.target.value.replace(/[^\d.]/g, "").slice(0, 12));
                    setStrategyTargetDirty(true);
                  }}
                  aria-label="Bracket target price in rupees"
                />
              </div>
            ) : null}
            <div className="space-y-1.5">
              <Label htmlFor="ticket-strategy-stop" className="text-xs text-muted-foreground">
                Stop trigger (₹)
              </Label>
              <Input
                id="ticket-strategy-stop"
                className="h-11 font-mono tabular-nums"
                inputMode="decimal"
                placeholder={(lastRupees ?? 0).toFixed(2)}
                value={displayedStrategyStop}
                onChange={(e) => {
                  setStrategyStop(e.target.value.replace(/[^\d.]/g, "").slice(0, 12));
                  setStrategyStopDirty(true);
                }}
                aria-label="Stop-loss trigger price in rupees"
              />
              <p className="font-mono text-[10px] leading-relaxed text-muted-foreground">
                {isBracket
                  ? "Target and stop-loss arm automatically after entry."
                  : "Auto-exits at trigger if the trade goes against you."}
              </p>
            </div>
            {strategyLimitHint ? (
              <p role="note" className="font-mono text-[10px] leading-relaxed text-terminal">
                {strategyLimitHint}
              </p>
            ) : null}
            {strategyTargetHint ? (
              <p role="note" className="font-mono text-[10px] leading-relaxed text-terminal">
                {strategyTargetHint}
              </p>
            ) : null}
            {strategyStopHint ? (
              <p role="note" className="font-mono text-[10px] leading-relaxed text-terminal">
                {strategyStopHint}
              </p>
            ) : null}
          </div>
        ) : null}

        {!isStrategy ? (
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Product</Label>
            <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="Product type">
              <Button
                type="button"
                variant={product === "CNC" ? "default" : "outline"}
                className="h-11 font-semibold"
                onClick={() => setProduct("CNC")}
                aria-pressed={product === "CNC"}
              >
                CNC
              </Button>
              <Button
                type="button"
                variant={product === "MIS" ? "default" : "outline"}
                className="h-11 font-semibold"
                onClick={() => setProduct("MIS")}
                aria-pressed={product === "MIS"}
              >
                MIS
              </Button>
            </div>
            <p className="font-mono text-[10px] leading-relaxed text-muted-foreground">
              {product === "CNC"
                ? "Delivery — full money, sell needs holdings."
                : "Intraday — 5x margin, shorting allowed."}
            </p>
          </div>
        ) : null}

        {isAmoKind ? (
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <Checkbox
                id="ticket-amo"
                checked={amo}
                onCheckedChange={(v) => setAmo(v === true)}
              />
              <Label htmlFor="ticket-amo" className="text-xs text-muted-foreground">
                After market (AMO)
              </Label>
            </div>
            {amo ? (
              <p className="font-mono text-[10px] leading-relaxed text-terminal">
                Queued now — releases at the next hourly session open.
              </p>
            ) : null}
          </div>
        ) : null}

        <dl className="space-y-1 rounded-md border border-border/60 bg-background/40 px-3 py-2 font-mono text-xs tabular-nums">
          <div className="flex justify-between">
            <dt className="text-muted-foreground">Est. total</dt>
            <dd>{estTotal !== null ? formatInr(estTotal) : "—"}</dd>
          </div>
          {isStrategy || product === "MIS" ? (
            <>
              <div className="flex justify-between gap-2">
                <dt className="shrink-0 text-muted-foreground">Required</dt>
                <dd className={cn("min-w-0 text-right", marginInsufficient && "text-loss")}>
                  {marginData.data
                    ? `${formatInr(marginData.data.requiredCents)} · ${formatInr(marginData.data.availableCents)} · ${marginData.data.leverage}x`
                    : "…"}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Fee est.</dt>
                <dd className="text-muted-foreground">
                  {marginData.data ? formatInr(marginData.data.feeEstimateCents) : "—"}
                </dd>
              </div>
            </>
          ) : (
            <>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Cash available</dt>
                <dd>{formatInr(cash)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Holding</dt>
                <dd>{heldQty > 0 ? `${heldQty} qty` : "—"}</dd>
              </div>
            </>
          )}
        </dl>

        {marginInsufficient && marginData.data ? (
          <p role="note" className="font-mono text-[10px] leading-relaxed text-terminal">
            Insufficient margin — required {formatInr(marginData.data.requiredCents)} exceeds
            available {formatInr(marginData.data.availableCents)}.{" "}
            {isStrategy ? "Reduce the quantity." : "Reduce qty or switch product."}
          </p>
        ) : null}

        {reject ? (
          <Alert variant="destructive" role="alert">
            <AlertTriangle className="size-4" aria-hidden="true" />
            <AlertTitle>Order rejected{reject.code ? ` · ${reject.code}` : ""}</AlertTitle>
            <AlertDescription>{reject.message}</AlertDescription>
          </Alert>
        ) : null}

        <Button
          type="button"
          className={cn(
            "h-11 w-full font-semibold",
            side === "BUY"
              ? "border-transparent bg-profit text-background hover:bg-profit/90"
              : "border-transparent bg-loss text-background hover:bg-loss/90"
          )}
          disabled={!canSubmit}
          onClick={handleSubmit}
        >
          {placeOrder.isPending
            ? "Placing…"
            : `${side} ${Number.isFinite(parsedQty) && parsedQty >= 1 ? parsedQty : ""} ${symbol}`.trim()}
        </Button>
        <p className="text-center font-mono text-[10px] text-muted-foreground">
          SIMULATED BROKER · RISK ENGINE IN ORDER PATH
        </p>
      </div>
    </div>
  );
}

/* ---------------- price alert popover (Phase 3) ---------------- */

/**
 * Bell button in the ticket header → popover to create a price alert
 * (ABOVE/BELOW + ₹ target). Content state remounts on every open, so the
 * target re-defaults to the current LTP.
 */
function AlertBellButton({
  symbol,
  lastRupees,
}: {
  symbol: string;
  lastRupees: number | undefined;
}) {
  const [open, setOpen] = useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="size-11 shrink-0 border-terminal/40 text-terminal hover:bg-terminal/10 hover:text-terminal"
          aria-label={`Set a price alert for ${symbol}`}
        >
          <Bell className="size-4" aria-hidden="true" />
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-64 p-4">
        <AlertPopoverForm
          symbol={symbol}
          lastRupees={lastRupees}
          onCreated={() => setOpen(false)}
        />
      </PopoverContent>
    </Popover>
  );
}

function AlertPopoverForm({
  symbol,
  lastRupees,
  onCreated,
}: {
  symbol: string;
  lastRupees: number | undefined;
  onCreated: () => void;
}) {
  const createAlert = useCreateAlert();
  const [condition, setCondition] = useState<AlertCondition>("ABOVE");
  const [price, setPrice] = useState(() =>
    lastRupees !== undefined ? lastRupees.toFixed(2) : ""
  );

  const parsed = price.trim() === "" ? NaN : Number(price);
  const targetPaise = Number.isNaN(parsed) ? NaN : Math.round(parsed * 100);
  const valid = !Number.isNaN(targetPaise) && targetPaise > 0;

  const handleSubmit = () => {
    if (!valid) return;
    createAlert.mutate(
      { symbol, condition, targetCents: targetPaise },
      { onSuccess: () => onCreated() }
    );
  };

  return (
    <div className="space-y-3">
      <div>
        <p className="font-mono text-[10px] uppercase tracking-widest text-terminal">
          PRICE ALERT
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          Notify me when {symbol} crosses the target.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="Alert condition">
        <Button
          type="button"
          variant={condition === "ABOVE" ? "default" : "outline"}
          className={cn(
            "h-11 font-semibold",
            condition === "ABOVE"
              ? "border-transparent bg-profit text-background hover:bg-profit/90"
              : "border-profit/40 text-profit hover:bg-profit/10 hover:text-profit"
          )}
          onClick={() => setCondition("ABOVE")}
          aria-pressed={condition === "ABOVE"}
        >
          <span aria-hidden="true">{"\u25B2"}</span> Above
        </Button>
        <Button
          type="button"
          variant={condition === "BELOW" ? "default" : "outline"}
          className={cn(
            "h-11 font-semibold",
            condition === "BELOW"
              ? "border-transparent bg-loss text-background hover:bg-loss/90"
              : "border-loss/40 text-loss hover:bg-loss/10 hover:text-loss"
          )}
          onClick={() => setCondition("BELOW")}
          aria-pressed={condition === "BELOW"}
        >
          <span aria-hidden="true">{"\u25BC"}</span> Below
        </Button>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="alert-target" className="text-xs text-muted-foreground">
          Target price (₹)
        </Label>
        <Input
          id="alert-target"
          className="h-11 font-mono tabular-nums"
          inputMode="decimal"
          placeholder={(lastRupees ?? 0).toFixed(2)}
          value={price}
          onChange={(e) => setPrice(e.target.value.replace(/[^\d.]/g, "").slice(0, 12))}
          aria-label="Alert target price in rupees"
        />
      </div>

      <Button
        type="button"
        className="h-11 w-full bg-terminal font-semibold text-background hover:bg-terminal/90"
        disabled={!valid || createAlert.isPending}
        onClick={handleSubmit}
      >
        {createAlert.isPending ? "Setting…" : "Create alert"}
      </Button>
    </div>
  );
}
