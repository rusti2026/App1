"use client";

import { useEffect, useState, useSyncExternalStore } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { KeyRound, Laptop, Phone, ShieldCheck, ShieldX } from "lucide-react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useMfaDisable, useMfaEnable, useMfaSetup } from "@/hooks/use-auth";
import { SESSION_KEY } from "@/hooks/use-session";
import { OtpFlow } from "@/components/meridian/otp-flow";
import type { KycStatus, SessionUser } from "@/lib/types";

/** Security center: MFA (TOTP), phone verification, KYC status, session info. */
export function SecurityCard({ user }: { user: SessionUser }) {
  const [mfaDialog, setMfaDialog] = useState<"enable" | "disable" | null>(null);
  const [phoneDialog, setPhoneDialog] = useState(false);

  return (
    <Card className="bg-card/60">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div className="space-y-1">
            <CardTitle className="text-base">Security center</CardTitle>
            <CardDescription className="text-xs">
              Hardening your account, one layer at a time
            </CardDescription>
          </div>
          <span className="font-mono text-[11px] uppercase tracking-widest text-terminal">
            SECURITY
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <ul className="divide-y divide-border/60">
          {/* MFA */}
          <li className="flex items-center justify-between gap-4 py-3.5">
            <div className="flex min-w-0 items-start gap-3">
              <KeyRound className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
              <div>
                <p className="text-sm font-medium">Multi-factor authentication</p>
                <p className="text-xs text-muted-foreground">
                  TOTP authenticator app · required for withdrawals in Phase 4
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2.5">
              <Badge
                variant="outline"
                className={
                  user.mfaEnabled
                    ? "border-profit/40 bg-profit/10 text-profit"
                    : "text-muted-foreground"
                }
              >
                {user.mfaEnabled ? "Enabled" : "Disabled"}
              </Badge>
              <Switch
                checked={user.mfaEnabled}
                onCheckedChange={(checked) =>
                  setMfaDialog(checked ? "enable" : "disable")
                }
                aria-label={
                  user.mfaEnabled
                    ? "Disable multi-factor authentication"
                    : "Enable multi-factor authentication"
                }
              />
            </div>
          </li>

          {/* Phone */}
          <li className="flex items-center justify-between gap-4 py-3.5">
            <div className="flex min-w-0 items-start gap-3">
              <Phone className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
              <div>
                <p className="text-sm font-medium">Phone verified</p>
                <p className="text-xs text-muted-foreground">
                  Enables SMS one-time codes and alerts
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2.5">
              <Badge
                variant="outline"
                className={
                  user.phoneVerified
                    ? "border-profit/40 bg-profit/10 text-profit"
                    : "text-muted-foreground"
                }
              >
                {user.phoneVerified ? "Verified" : "Not verified"}
              </Badge>
              <Button
                variant="outline"
                size="sm"
                className="h-9"
                onClick={() => setPhoneDialog(true)}
              >
                {user.phoneVerified ? "Re-verify" : "Verify"}
              </Button>
            </div>
          </li>

          {/* KYC */}
          <li className="flex items-center justify-between gap-4 py-3.5">
            <div className="flex min-w-0 items-start gap-3">
              {user.kycStatus === "APPROVED" ? (
                <ShieldCheck className="mt-0.5 size-4 shrink-0 text-profit" aria-hidden="true" />
              ) : (
                <ShieldX className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
              )}
              <div>
                <p className="text-sm font-medium">Identity verification</p>
                <p className="text-xs text-muted-foreground">
                  Unlocks trading and wallet rails
                </p>
              </div>
            </div>
            <KycBadge status={user.kycStatus} />
          </li>

          {/* Session */}
          <SessionRow />
        </ul>
      </CardContent>

      <MfaDialog mode={mfaDialog} onClose={() => setMfaDialog(null)} />

      <PhoneVerifyDialog open={phoneDialog} onOpenChange={setPhoneDialog} />
    </Card>
  );
}

/* ---------------- phone verification (reuses OtpFlow) ---------------- */
function PhoneVerifyDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const queryClient = useQueryClient();
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Verify with a one-time code</DialogTitle>
          <DialogDescription>
            Choose a channel — in this sandbox the code is displayed on screen.
          </DialogDescription>
        </DialogHeader>
        <OtpFlow
          onVerified={() => {
            onOpenChange(false);
            void queryClient.invalidateQueries({ queryKey: SESSION_KEY });
          }}
          onCancel={() => onOpenChange(false)}
        />
      </DialogContent>
    </Dialog>
  );
}

function KycBadge({ status }: { status: KycStatus }) {
  if (status === "APPROVED") {
    return (
      <Badge variant="outline" className="border-profit/40 bg-profit/10 text-profit">
        Approved
      </Badge>
    );
  }
  if (status === "PENDING") {
    return (
      <Badge
        variant="outline"
        className="animate-pulse border-terminal/40 bg-terminal/10 text-terminal"
      >
        Under review
      </Badge>
    );
  }
  if (status === "REJECTED") {
    return (
      <Badge variant="outline" className="border-loss/40 bg-loss/10 text-loss">
        Rejected
      </Badge>
    );
  }
  return <Badge variant="outline" className="text-muted-foreground">Not started</Badge>;
}

/* ---------------- MFA dialog ---------------- */

function MfaDialog({
  mode,
  onClose,
}: {
  mode: "enable" | "disable" | null;
  onClose: () => void;
}) {
  if (mode === "enable") {
    return <MfaEnableDialog open onClose={onClose} />;
  }
  if (mode === "disable") {
    return <MfaDisableDialog open onClose={onClose} />;
  }
  return null;
}

function MfaEnableDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const setup = useMfaSetup();
  const enable = useMfaEnable();
  const queryClient = useQueryClient();
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [attempts, setAttempts] = useState(0);

  // Fire setup once when the dialog opens.
  useEffect(() => {
    if (open && !setup.data && !setup.isPending && !setup.isError) {
      setup.mutate();
    }
  }, [open, setup]);

  const handleEnable = () => {
    if (code.length !== 6) return;
    enable.mutate(
      { code },
      {
        onSuccess: () => {
          toast.success("MFA enabled", {
            description: "Your account now requires authenticator codes at login.",
          });
          void queryClient.invalidateQueries({ queryKey: SESSION_KEY });
          setCode("");
          setError(null);
          onClose();
        },
        onError: (err) => {
          setAttempts((a) => a + 1);
          setError(err instanceof Error ? err.message : "Verification failed.");
          setCode("");
        },
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={(next) => (next ? undefined : onClose())}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Enable authenticator app</DialogTitle>
          <DialogDescription>
            Scan the QR code with your authenticator app (Google Authenticator,
            1Password, Authy…), then confirm with a 6-digit code.
          </DialogDescription>
        </DialogHeader>

        {setup.isPending ? (
          <div className="flex flex-col items-center gap-3 py-8" role="status">
            <div className="size-40 animate-pulse rounded-md bg-muted" aria-hidden="true" />
            <p className="font-mono text-xs text-muted-foreground">
              GENERATING SECRET…
            </p>
          </div>
        ) : setup.isError || !setup.data ? (
          <div className="space-y-4 py-4 text-center">
            <p role="alert" className="text-sm text-loss">
              Couldn&apos;t generate a secret. Please try again.
            </p>
            <Button variant="outline" className="h-11" onClick={() => setup.mutate()}>
              Retry
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex justify-center">
              <img
                src={setup.data.qrDataUrl}
                alt="TOTP QR code — scan with your authenticator app"
                className="size-44 rounded-md border border-border bg-white p-2"
              />
            </div>
            <div className="space-y-1.5 text-center">
              <p className="text-xs text-muted-foreground">
                Can&apos;t scan? Enter this secret manually:
              </p>
              <button
                type="button"
                className="rounded bg-muted px-3 py-1.5 font-mono text-sm font-semibold tracking-wider transition-colors hover:bg-accent"
                onClick={() => {
                  void navigator.clipboard
                    .writeText(setup.data.secret)
                    .then(() => toast.success("Secret copied"))
                    .catch(() => toast.error("Copy failed"));
                }}
                aria-label="Copy manual entry secret"
              >
                {setup.data.secret}
              </button>
            </div>

            <div key={attempts} className="flex justify-center">
              <InputOTP
                maxLength={6}
                value={code}
                onChange={(value) => {
                  setCode(value);
                  setError(null);
                }}
                aria-label="6-digit authenticator code"
              >
                <InputOTPGroup>
                  {[0, 1, 2, 3, 4, 5].map((i) => (
                    <InputOTPSlot key={i} index={i} className="size-11 text-base" />
                  ))}
                </InputOTPGroup>
              </InputOTP>
            </div>

            {error ? (
              <p role="alert" className="text-center text-xs font-medium text-loss">
                {error}
              </p>
            ) : null}
          </div>
        )}

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="ghost" className="h-11" onClick={onClose}>
            Cancel
          </Button>
          <Button
            className="h-11"
            disabled={!setup.data || code.length !== 6 || enable.isPending}
            onClick={handleEnable}
          >
            {enable.isPending ? "Verifying…" : "Confirm & enable"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function MfaDisableDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const disable = useMfaDisable();
  const queryClient = useQueryClient();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleDisable = () => {
    disable.mutate(
      { password },
      {
        onSuccess: () => {
          toast.success("MFA disabled", {
            description: "We recommend re-enabling it soon.",
          });
          void queryClient.invalidateQueries({ queryKey: SESSION_KEY });
          setPassword("");
          setError(null);
          onClose();
        },
        onError: (err) => {
          setError(err instanceof Error ? err.message : "Verification failed.");
        },
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={(next) => (next ? undefined : onClose())}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Disable multi-factor authentication</DialogTitle>
          <DialogDescription>
            Confirm your password to remove the authenticator requirement. This
            weakens your account security.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2">
          <Label htmlFor="mfa-disable-password" className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            Password
          </Label>
          <Input
            id="mfa-disable-password"
            type="password"
            className="h-11"
            autoComplete="current-password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              setError(null);
            }}
            aria-invalid={!!error}
          />
          {error ? (
            <p role="alert" className="text-xs font-medium text-loss">
              {error}
            </p>
          ) : null}
        </div>
        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="ghost" className="h-11" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="destructive"
            className="h-11"
            disabled={password.length === 0 || disable.isPending}
            onClick={handleDisable}
          >
            {disable.isPending ? "Disabling…" : "Disable MFA"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- session info row ---------------- */

const sessionInfoSubscribe = () => () => {};
let sessionInfoCache: { device: string; startedAt: string } | null = null;

function getSessionInfoSnapshot() {
  if (!sessionInfoCache) {
    sessionInfoCache = {
      device:
        typeof navigator !== "undefined"
          ? describeDevice(navigator.userAgent)
          : "This browser",
      startedAt: new Intl.DateTimeFormat("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        month: "short",
        day: "numeric",
      }).format(new Date()),
    };
  }
  return sessionInfoCache;
}

function getSessionInfoServerSnapshot() {
  return { device: "This browser", startedAt: "" };
}

function SessionRow() {
  // Read browser-only session metadata without hydration mismatches or
  // setState-in-effect cascades (React 19 useSyncExternalStore pattern).
  const { device, startedAt } = useSyncExternalStore(
    sessionInfoSubscribe,
    getSessionInfoSnapshot,
    getSessionInfoServerSnapshot
  );

  return (
    <li className="flex items-center justify-between gap-4 py-3.5">
      <div className="flex min-w-0 items-start gap-3">
        <Laptop className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
        <div className="min-w-0">
          <p className="text-sm font-medium">Active session</p>
          <p className="truncate font-mono text-xs text-muted-foreground">
            {device}
            {startedAt ? ` · since ${startedAt}` : ""}
          </p>
        </div>
      </div>
      <Badge variant="outline" className="shrink-0 border-profit/40 bg-profit/10 text-profit">
        Active
      </Badge>
    </li>
  );
}

function describeDevice(ua: string): string {
  const browser = /Edg\//.test(ua)
    ? "Edge"
    : /OPR\//.test(ua)
      ? "Opera"
      : /Chrome\//.test(ua)
        ? "Chrome"
        : /Safari\//.test(ua)
          ? "Safari"
          : /Firefox\//.test(ua)
            ? "Firefox"
            : "Browser";
  const os = /Windows/.test(ua)
    ? "Windows"
    : /Android/.test(ua)
      ? "Android"
      : /iPhone|iPad|iPod/.test(ua)
        ? "iOS"
        : /Mac OS X/.test(ua)
          ? "macOS"
          : /Linux/.test(ua)
            ? "Linux"
            : "Unknown OS";
  return `${browser} on ${os}`;
}
