"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { usePortfolioSummary } from "@/hooks/use-portfolio";
import {
  formatInr,
  formatSignedInr,
  formatSignedPct,
  trendGlyph,
} from "@/components/meridian/format";
import { cn } from "@/lib/utils";

/** Four KPI cards: equity, cash, buying power, day P&L. */
export function SummaryCards() {
  const { data, isPending, isError } = usePortfolioSummary();

  if (isPending) {
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="bg-card/60">
            <CardContent className="space-y-3 p-5">
              <Skeleton className="h-3 w-24" />
              <Skeleton className="h-7 w-32" />
              <Skeleton className="h-3 w-20" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (isError || !data) {
    return (
      <Card className="bg-card/60">
        <CardContent className="p-5">
          <p role="alert" className="text-sm text-loss">
            Couldn&apos;t load your portfolio. Retrying automatically…
          </p>
        </CardContent>
      </Card>
    );
  }

  const pendingSettling = data.cashPendingCents > 0;

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <SummaryCard
        label="Total equity"
        value={formatInr(data.totalEquityCents)}
        sub={`Positions ${formatInr(data.positionsValueCents)}`}
      />
      <SummaryCard
        label="Cash available"
        value={formatInr(data.cashAvailableCents)}
        sub={
          pendingSettling
            ? `${formatInr(data.cashPendingCents)} settling`
            : "Fully settled"
        }
      />
      <SummaryCard
        label="Buying power"
        value={formatInr(data.cashAvailableCents)}
        sub="Paper account · INR"
      />
      <SummaryCard
        label="Day P&L"
        value={formatSignedInr(data.dayPnlCents)}
        valueClassName={cn(
          data.dayPnlCents > 0 && "text-profit",
          data.dayPnlCents < 0 && "text-loss"
        )}
        sub={
          <span
            className={cn(
              "font-mono text-xs tabular-nums",
              data.dayPnlCents >= 0 ? "text-profit" : "text-loss"
            )}
          >
            {trendGlyph(data.dayPnlCents)} {formatSignedPct(data.dayPnlPct)} today
          </span>
        }
      />
    </div>
  );
}

function SummaryCard({
  label,
  value,
  sub,
  valueClassName,
}: {
  label: string;
  value: string;
  sub?: React.ReactNode;
  valueClassName?: string;
}) {
  return (
    <Card className="bg-card/60">
      <CardContent className="space-y-1.5 p-5">
        <p className="font-mono text-[11px] font-medium uppercase tracking-widest text-muted-foreground">
          {label}
        </p>
        <p
          className={cn(
            "font-mono text-2xl font-semibold tabular-nums",
            valueClassName
          )}
        >
          {value}
        </p>
        {sub ? <div className="text-xs text-muted-foreground">{sub}</div> : null}
      </CardContent>
    </Card>
  );
}
