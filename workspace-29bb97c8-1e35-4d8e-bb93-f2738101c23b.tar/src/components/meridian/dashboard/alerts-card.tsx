"use client";

/**
 * Price alerts — active alerts first (cancel-able), recently triggered below
 * with a green badge. Data: GET /api/alerts (15s poll) + WS `alert` event
 * invalidations from use-quotes. Cancel is optimistic with rollback.
 */

import { useMemo } from "react";
import { BellOff, X } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useAlerts, useCancelAlert } from "@/hooks/use-alerts";
import { formatInr, relativeTime } from "@/components/meridian/format";
import { cn } from "@/lib/utils";
import type { PriceAlertDTO } from "@/lib/types";

export function AlertsCard() {
  const { data, isPending, isError } = useAlerts();
  const cancelAlert = useCancelAlert();

  // CANCELED alerts drop out of the feed entirely.
  const visible = useMemo(
    () => (data?.alerts ?? []).filter((a) => a.status !== "CANCELED"),
    [data?.alerts]
  );
  const active = useMemo(
    () => visible.filter((a) => a.status === "ACTIVE"),
    [visible]
  );
  const triggered = useMemo(
    () => visible.filter((a) => a.status === "TRIGGERED").slice(0, 8),
    [visible]
  );

  return (
    <Card className="bg-card/60">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div className="space-y-1">
            <CardTitle className="text-base">Price alerts</CardTitle>
            <CardDescription className="text-xs">
              Level-crossing notifications · pushed live over WS
            </CardDescription>
          </div>
          <span className="font-mono text-[11px] uppercase tracking-widest text-terminal">
            ALERTS
          </span>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {isPending ? (
          <div className="divide-y divide-border/60" aria-hidden="true">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 px-4 py-3">
                <Skeleton className="h-4 w-4" />
                <Skeleton className="h-4 w-16" />
                <Skeleton className="ml-auto h-4 w-20" />
              </div>
            ))}
          </div>
        ) : isError ? (
          <p role="alert" className="px-4 py-8 text-sm text-loss">
            Couldn&apos;t load alerts — retrying…
          </p>
        ) : visible.length === 0 ? (
          <div className="flex flex-col items-center gap-2 px-4 py-10 text-center">
            <BellOff className="size-6 text-muted-foreground/50" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">
              No alerts yet — set one from any instrument.
            </p>
            <p className="text-xs text-muted-foreground">
              Tap the bell in an order ticket and we&apos;ll ping you on the crossing.
            </p>
          </div>
        ) : (
          <div className="thin-scroll max-h-96 overflow-y-auto">
            {active.length > 0 ? (
              <section aria-label="Active alerts">
                <p className="px-4 pb-1 pt-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                  Active
                </p>
                <ul className="divide-y divide-border/60">
                  {active.map((alert) => (
                    <AlertRow
                      key={alert.id}
                      alert={alert}
                      onCancel={() => cancelAlert.mutate(alert.id)}
                      cancelPending={cancelAlert.isPending}
                    />
                  ))}
                </ul>
              </section>
            ) : null}
            {triggered.length > 0 ? (
              <section aria-label="Triggered alerts">
                <p className="px-4 pb-1 pt-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                  Triggered
                </p>
                <ul className="divide-y divide-border/60">
                  {triggered.map((alert) => (
                    <AlertRow
                      key={alert.id}
                      alert={alert}
                      onCancel={() => cancelAlert.mutate(alert.id)}
                      cancelPending={cancelAlert.isPending}
                    />
                  ))}
                </ul>
              </section>
            ) : null}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function AlertRow({
  alert,
  onCancel,
  cancelPending,
}: {
  alert: PriceAlertDTO;
  onCancel: () => void;
  cancelPending: boolean;
}) {
  const triggered = alert.status === "TRIGGERED";
  const above = alert.condition === "ABOVE";

  return (
    <li className="flex items-center gap-3 px-4 py-2.5">
      <span
        aria-hidden="true"
        className={cn(
          "w-4 shrink-0 text-center font-mono text-xs",
          above ? "text-profit" : "text-loss"
        )}
      >
        {above ? "\u25B2" : "\u25BC"}
      </span>

      <div className="min-w-0 flex-1">
        <p className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-sm font-semibold">{alert.symbol}</span>
          <span className="font-mono text-xs tabular-nums text-muted-foreground">
            {formatInr(alert.targetCents)}
          </span>
          {triggered ? (
            <Badge
              variant="outline"
              className="border-profit/40 bg-profit/10 px-1.5 py-0 font-mono text-[10px] font-semibold text-profit"
            >
              Triggered
            </Badge>
          ) : null}
        </p>
        <p className="mt-0.5 font-mono text-[10px] text-muted-foreground">
          {triggered
            ? `Triggered ${relativeTime(alert.triggeredAt ?? undefined) || "recently"}`
            : `Set ${relativeTime(alert.createdAt) || "recently"}`}
        </p>
      </div>

      {triggered ? (
        <span className="w-[1px]" aria-hidden="true" />
      ) : (
        <Button
          variant="ghost"
          size="icon"
          className="size-11 shrink-0"
          disabled={cancelPending}
          onClick={onCancel}
          aria-label={`Cancel ${alert.symbol} alert`}
        >
          <X className="size-4" aria-hidden="true" />
        </Button>
      )}
    </li>
  );
}
