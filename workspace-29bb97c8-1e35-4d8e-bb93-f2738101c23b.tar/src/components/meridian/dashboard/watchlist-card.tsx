"use client";

import { useMemo, useState } from "react";
import { Plus, Star, X } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useAddToWatchlist,
  useMarketOverview,
  useRemoveFromWatchlist,
  useWatchlist,
} from "@/hooks/use-market";
import { useFlash, useQuoteSocket } from "@/hooks/use-quotes";
import {
  formatInr,
  formatPts,
  formatSignedPct,
  formatVolume,
  trendGlyph,
} from "@/components/meridian/format";
import { cn } from "@/lib/utils";
import type { MarketQuote, TickQuote } from "@/lib/types";

/**
 * Watchlist with live quote join — WS ticks (§6a) override the REST overview
 * snapshot; row click opens the instrument detail dialog; star add/remove
 * stays optimistic.
 */
export function WatchlistCard({ onOpen }: { onOpen?: (symbol: string) => void }) {
  const [symbol, setSymbol] = useState("");
  const { data: overview } = useMarketOverview();
  const watchlist = useWatchlist();
  const addToWatchlist = useAddToWatchlist();
  const removeFromWatchlist = useRemoveFromWatchlist();

  const items = watchlist.data?.items ?? [];
  const watchSymbols = useMemo(() => items.map((i) => i.symbol), [items]);
  const { quotes: live } = useQuoteSocket(watchSymbols);

  const overviewMap = useMemo(() => {
    const map = new Map<string, MarketQuote>();
    for (const q of [...(overview?.movers ?? []), ...(overview?.indices ?? [])]) {
      map.set(q.symbol, q);
    }
    return map;
  }, [overview?.movers, overview?.indices]);

  const knownSymbols = useMemo(
    () => Array.from(overviewMap.keys()).sort(),
    [overviewMap]
  );

  const handleAdd = (event: React.FormEvent) => {
    event.preventDefault();
    const normalized = symbol.trim().toUpperCase();
    if (!normalized) return;
    if (items.some((i) => i.symbol === normalized)) {
      toast.info(`${normalized} is already on your watchlist.`);
      setSymbol("");
      return;
    }
    addToWatchlist.mutate(normalized, {
      onSuccess: () => {
        toast.success(`${normalized} added to watchlist`);
        setSymbol("");
      },
    });
  };

  return (
    <Card className="bg-card/60">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div className="space-y-1">
            <CardTitle className="text-base">Watchlist</CardTitle>
            <CardDescription className="text-xs">
              Your starred assets, priced live · click a row for details
            </CardDescription>
          </div>
          <span className="font-mono text-[11px] uppercase tracking-widest text-terminal">
            TRACKING
          </span>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <form onSubmit={handleAdd} className="flex gap-2">
          <div className="relative min-w-0 flex-1">
            <Input
              list="meridian-known-symbols"
              className="h-11 min-w-0 font-mono uppercase"
              placeholder="Add symbol (e.g. RELIANCE)"
              aria-label="Symbol to add to watchlist"
              maxLength={12}
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
            />
            <datalist id="meridian-known-symbols">
              {knownSymbols.map((sym) => (
                <option key={sym} value={sym} />
              ))}
            </datalist>
          </div>
          <Button
            type="submit"
            variant="outline"
            className="h-11"
            disabled={addToWatchlist.isPending || symbol.trim().length === 0}
            aria-label="Add symbol to watchlist"
          >
            <Plus className="size-4" aria-hidden="true" />
            Add
          </Button>
        </form>

        {watchlist.isPending ? (
          <div className="divide-y divide-border/60" aria-hidden="true">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between px-1 py-3">
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-4 w-24" />
              </div>
            ))}
          </div>
        ) : watchlist.isError ? (
          <p role="alert" className="px-1 py-6 text-sm text-loss">
            Couldn&apos;t load your watchlist — retrying…
          </p>
        ) : items.length === 0 ? (
          <div className="flex flex-col items-center gap-2 px-1 py-10 text-center">
            <Star className="size-6 text-muted-foreground/50" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">
              Star an asset to track it here.
            </p>
            <p className="text-xs text-muted-foreground">
              Tap the star on any mover — quotes stream in live.
            </p>
          </div>
        ) : (
          <ul
            className="thin-scroll max-h-96 divide-y divide-border/60 overflow-y-auto"
            aria-label="Watchlist"
          >
            {items.map((item) => {
              const fallback = overviewMap.get(item.symbol);
              const quote: TickQuote | undefined = live[item.symbol];
              const name = quote?.name ?? fallback?.name ?? "—";
              const isIndex = quote ? quote.type === "INDEX" : fallback?.type === "INDEX";
              const last = quote?.lastPriceCents ?? fallback?.lastPriceCents;
              const pct = quote?.changePct ?? fallback?.changePct;
              const volume = quote?.volume ?? fallback?.volume;
              return (
                <WatchRow
                  key={item.symbol}
                  symbol={item.symbol}
                  name={name}
                  isIndex={!!isIndex}
                  last={last}
                  pct={pct}
                  volume={volume}
                  onOpen={onOpen}
                  onRemove={() =>
                    removeFromWatchlist.mutate(item.symbol, {
                      onSuccess: () =>
                        toast.success(`${item.symbol} removed from watchlist`),
                    })
                  }
                  removePending={removeFromWatchlist.isPending}
                />
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

function WatchRow({
  symbol,
  name,
  isIndex,
  last,
  pct,
  volume,
  onOpen,
  onRemove,
  removePending,
}: {
  symbol: string;
  name: string;
  isIndex: boolean;
  last?: number;
  pct?: number;
  volume?: number;
  onOpen?: (symbol: string) => void;
  onRemove: () => void;
  removePending: boolean;
}) {
  const flash = useFlash(last);
  return (
    <li className="flex items-center gap-1 pr-1">
      <button
        type="button"
        className="flex min-w-0 flex-1 items-center justify-between gap-3 rounded-md px-2 py-2.5 text-left transition-colors hover:bg-accent/50 focus-visible:bg-accent/50 focus-visible:outline-none"
        onClick={() => onOpen?.(symbol)}
        aria-label={`Open ${symbol} details`}
      >
        <div className="min-w-0">
          <p className="font-mono text-sm font-semibold">{symbol}</p>
          <p className="truncate text-xs text-muted-foreground">{name}</p>
        </div>
        <div className="shrink-0 text-right">
          <p
            className={cn(
              "font-mono text-sm tabular-nums transition-colors duration-500",
              flash === "up" && "bg-profit/15 text-profit",
              flash === "down" && "bg-loss/15 text-loss"
            )}
          >
            {last !== undefined ? (isIndex ? formatPts(last) : formatInr(last)) : "—"}
          </p>
          <p className="font-mono text-xs tabular-nums">
            {pct !== undefined ? (
              <span className={pct >= 0 ? "text-profit" : "text-loss"}>
                {trendGlyph(pct)} {formatSignedPct(pct)}
              </span>
            ) : (
              <span className="text-muted-foreground">no quote</span>
            )}
            {!isIndex && volume !== undefined ? (
              <span className="text-muted-foreground"> · {formatVolume(volume)}</span>
            ) : null}
          </p>
        </div>
      </button>
      <Button
        variant="ghost"
        size="icon"
        className="size-11 shrink-0"
        aria-label={`Remove ${symbol} from watchlist`}
        disabled={removePending}
        onClick={onRemove}
      >
        <X className="size-4" aria-hidden="true" />
      </Button>
    </li>
  );
}
