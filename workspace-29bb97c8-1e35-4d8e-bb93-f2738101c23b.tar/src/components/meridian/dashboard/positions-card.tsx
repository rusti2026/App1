"use client";

/**
 * Holdings — live mark-to-market positions from the portfolio summary,
 * re-marked client-side against the quote socket for sub-second P&L.
 * MIS/CO/BO shorts arrive as negative qty (signed math server-side, §8a)
 * and render a SHORT badge. Row click opens the instrument detail dialog.
 */

import { useMemo } from "react";
import { PackageOpen } from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { usePortfolioSummary } from "@/hooks/use-portfolio";
import { useQuoteSocket } from "@/hooks/use-quotes";
import {
  formatInr,
  formatSignedInr,
  trendGlyph,
} from "@/components/meridian/format";
import { cn } from "@/lib/utils";
import type { PositionDetail } from "@/lib/types";

export function PositionsCard({ onOpen }: { onOpen: (symbol: string) => void }) {
  const { data, isPending, isError } = usePortfolioSummary();
  const positions = useMemo(() => data?.positions ?? [], [data?.positions]);
  const symbols = useMemo(() => positions.map((p) => p.symbol), [positions]);
  const { quotes } = useQuoteSocket(symbols);

  return (
    <Card className="bg-card/60">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div className="space-y-1">
            <CardTitle className="text-base">Holdings</CardTitle>
            <CardDescription className="text-xs">
              Live mark-to-market · P&amp;L updates with the tape
            </CardDescription>
          </div>
          <span className="font-mono text-[11px] uppercase tracking-widest text-terminal">
            POSITIONS
          </span>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {isPending ? (
          <div className="divide-y divide-border/60" aria-hidden="true">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between px-4 py-3">
                <div className="space-y-1.5">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-3 w-28" />
                </div>
                <div className="space-y-1.5 text-right">
                  <Skeleton className="ml-auto h-4 w-24" />
                  <Skeleton className="ml-auto h-3 w-16" />
                </div>
              </div>
            ))}
          </div>
        ) : isError ? (
          <p role="alert" className="px-4 py-8 text-sm text-loss">
            Couldn&apos;t load holdings — retrying…
          </p>
        ) : positions.length === 0 ? (
          <div className="flex flex-col items-center gap-2 px-4 py-10 text-center">
            <PackageOpen className="size-6 text-muted-foreground/50" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">
              No holdings yet — tap a stock and place your first trade.
            </p>
          </div>
        ) : (
          <ul
            className="thin-scroll max-h-96 divide-y divide-border/60 overflow-y-auto"
            aria-label="Holdings"
          >
            {positions.map((position) => (
              <PositionRow
                key={position.symbol}
                position={position}
                liveLast={quotes[position.symbol]?.lastPriceCents}
                onOpen={onOpen}
              />
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

function PositionRow({
  position,
  liveLast,
  onOpen,
}: {
  position: PositionDetail;
  liveLast?: number;
  onOpen: (symbol: string) => void;
}) {
  const last = liveLast ?? position.lastPriceCents;
  // Re-mark against the live tape when a tick has arrived.
  const unrealized =
    liveLast !== undefined
      ? (last - position.avgCostCents) * position.qty
      : position.unrealizedPnlCents;

  return (
    <li>
      <button
        type="button"
        className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left transition-colors hover:bg-accent/50 focus-visible:bg-accent/50 focus-visible:outline-none"
        onClick={() => onOpen(position.symbol)}
        aria-label={`Open ${position.symbol} details`}
      >
        <div className="min-w-0">
          <p className="flex items-center gap-2 font-mono text-sm font-semibold">
            <span className="min-w-0 truncate">{position.symbol}</span>
            {position.qty < 0 ? (
              <Badge
                variant="outline"
                className="shrink-0 border-loss/50 bg-loss/10 px-1.5 py-0 text-[10px] font-semibold text-loss"
              >
                SHORT
              </Badge>
            ) : null}
          </p>
          <p className="truncate text-xs tabular-nums text-muted-foreground">
            {position.qty} × {formatInr(position.avgCostCents)} avg · {position.name}
          </p>
        </div>
        <div className="shrink-0 text-right">
          <p className="font-mono text-sm tabular-nums">{formatInr(last)}</p>
          <p
            className={cn(
              "font-mono text-xs tabular-nums",
              unrealized > 0 ? "text-profit" : unrealized < 0 ? "text-loss" : "text-muted-foreground"
            )}
          >
            {trendGlyph(unrealized)} {formatSignedInr(unrealized)}
          </p>
        </div>
      </button>
    </li>
  );
}
