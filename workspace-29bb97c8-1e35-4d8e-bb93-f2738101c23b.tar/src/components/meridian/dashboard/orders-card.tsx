"use client";

/**
 * Orders — order history from GET /api/orders (newest first) with live
 * status badges, GTT trigger/limit/expiry details, AMO QUEUED release time
 * and cancel for NEW/PARTIALLY_FILLED/QUEUED working orders.
 *
 * Phase 4 (§8b): CO/BO legs (TARGET/STOP/EXIT) are grouped indented under
 * their parent entry row; entries carry a CO/BO badge with their SL/target
 * levels; filled strategy entries offer a market Exit (square-off). The
 * list itself stays flat — grouping is purely presentational. Kept fresh by
 * WS order-update/portfolio-nudge invalidations + 15s poll.
 */

import { useMemo } from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useCancelOrder, useExitOrder, useOrders } from "@/hooks/use-orders";
import {
  formatDateShort,
  formatInr,
  formatTimeHM,
} from "@/components/meridian/format";
import { cn } from "@/lib/utils";
import type { OrderDTO, OrderLegKind, OrderStatus } from "@/lib/types";

const timeFmt = new Intl.DateTimeFormat("en-IN", {
  hour: "2-digit",
  minute: "2-digit",
  hour12: false,
});

export function OrdersCard() {
  const { data, isPending, isError } = useOrders();
  const cancelOrder = useCancelOrder();
  const exitOrder = useExitOrder();
  const orders = data?.orders ?? [];

  // The feed is flat and newest-first; legs reference their entry via
  // parentOrderId. Rows with a parent present in the list render indented
  // beneath it; orphan legs (parent pruned/absent) stay inline.
  const parentIds = useMemo(() => new Set(orders.map((o) => o.id)), [orders]);
  const legsByParent = useMemo(() => {
    const map = new Map<string, OrderDTO[]>();
    for (const order of orders) {
      if (!order.parentOrderId) continue;
      const legs = map.get(order.parentOrderId);
      if (legs) legs.push(order);
      else map.set(order.parentOrderId, [order]);
    }
    return map;
  }, [orders]);

  const topRows = orders.filter(
    (order) => !(order.parentOrderId && parentIds.has(order.parentOrderId))
  );

  return (
    <Card className="bg-card/60">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div className="space-y-1">
            <CardTitle className="text-base">Orders</CardTitle>
            <CardDescription className="text-xs">
              Execution and risk status · confirms push over WS
            </CardDescription>
          </div>
          <span className="font-mono text-[11px] uppercase tracking-widest text-terminal">
            OMS
          </span>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {isPending ? (
          <div className="divide-y divide-border/60" aria-hidden="true">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 px-4 py-3">
                <Skeleton className="h-4 w-10" />
                <Skeleton className="h-4 w-16" />
                <Skeleton className="ml-auto h-4 w-20" />
              </div>
            ))}
          </div>
        ) : isError ? (
          <p role="alert" className="px-4 py-8 text-sm text-loss">
            Couldn&apos;t load orders — retrying…
          </p>
        ) : orders.length === 0 ? (
          <div className="flex flex-col items-center gap-2 px-4 py-10 text-center">
            <p className="text-sm text-muted-foreground">No orders yet.</p>
            <p className="text-xs text-muted-foreground">
              Place a trade from any instrument — fills land here in real time.
            </p>
          </div>
        ) : (
          <ul
            className="thin-scroll max-h-96 divide-y divide-border/60 overflow-y-auto"
            aria-label="Orders"
          >
            {topRows.map((order) => (
              <OrderGroup
                key={order.id}
                order={order}
                legs={
                  order.strategy && !order.parentOrderId
                    ? legsByParent.get(order.id) ?? []
                    : []
                }
                onCancel={(id) => cancelOrder.mutate(id)}
                onExit={(id) => exitOrder.mutate(id)}
                cancelPending={cancelOrder.isPending}
                exitPending={exitOrder.isPending}
              />
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

/**
 * One top-level row (entry / standalone order / orphan leg) plus its legs
 * (when the row is a CO/BO entry). Legs always render without actions.
 */
function OrderGroup({
  order,
  legs,
  onCancel,
  onExit,
  cancelPending,
  exitPending,
}: {
  order: OrderDTO;
  legs: OrderDTO[];
  onCancel: (orderId: string) => void;
  onExit: (orderId: string) => void;
  cancelPending: boolean;
  exitPending: boolean;
}) {
  return (
    <>
      <OrderRow
        order={order}
        isLeg={Boolean(order.parentOrderId)}
        onCancel={() => onCancel(order.id)}
        onExit={() => onExit(order.id)}
        cancelPending={cancelPending}
        exitPending={exitPending}
      />
      {legs.map((leg) => (
        <OrderRow
          key={leg.id}
          order={leg}
          isLeg
          indent
          cancelPending={cancelPending}
          exitPending={exitPending}
          onCancel={() => onCancel(leg.id)}
          onExit={() => onExit(leg.id)}
        />
      ))}
    </>
  );
}

function OrderRow({
  order,
  isLeg,
  indent = false,
  onCancel,
  onExit,
  cancelPending,
  exitPending,
}: {
  order: OrderDTO;
  /** Legs (TARGET/STOP/EXIT) reference a parent entry via parentOrderId. */
  isLeg: boolean;
  /** Render indented beneath the parent entry row. */
  indent?: boolean;
  onCancel: () => void;
  onExit: () => void;
  cancelPending: boolean;
  exitPending: boolean;
}) {
  const buy = order.side === "BUY";
  const isGtt = order.type === "GTT";
  const isStrategyEntry = !isLeg && Boolean(order.strategy);
  const price =
    order.limitPriceCents ??
    order.stopPriceCents ??
    (order.avgFillPriceCents > 0 ? order.avgFillPriceCents : null);
  // AMO orders sit QUEUED until the matcher releases them at the next
  // hourly session open; the matcher also honours QUEUED/GTT cancels.
  // Legs never take actions — the family is managed via entry cancel/exit.
  const cancellable =
    !isLeg &&
    (order.status === "NEW" ||
      order.status === "PARTIALLY_FILLED" ||
      order.status === "QUEUED");
  const exitable =
    isStrategyEntry &&
    (order.status === "FILLED" || order.status === "PARTIALLY_FILLED");

  return (
    <li
      className={cn(
        "flex items-center gap-3 px-4 py-2.5",
        indent && "bg-background/20 pl-10"
      )}
    >
      <span className="w-10 shrink-0 font-mono text-xs tabular-nums text-muted-foreground">
        {timeFmt.format(new Date(order.createdAt))}
      </span>

      <div className="min-w-0 flex-1">
        <p className="flex items-center gap-2">
          {indent ? (
            <span
              aria-hidden="true"
              className="font-mono text-xs text-muted-foreground"
            >
              ↳
            </span>
          ) : null}
          <span className="font-mono text-sm font-semibold">{order.symbol}</span>
          <Badge
            variant="outline"
            className={cn(
              "px-1.5 py-0 text-[10px] font-semibold",
              buy
                ? "border-transparent bg-profit text-background"
                : "border-loss/60 bg-transparent text-loss"
            )}
          >
            {order.side}
          </Badge>
          {isLeg && order.legKind ? (
            <LegBadge legKind={order.legKind} />
          ) : null}
          {isStrategyEntry && order.strategy ? (
            <Badge
              variant="outline"
              className="border-terminal/40 bg-terminal/10 px-1.5 py-0 font-mono text-[10px] font-semibold text-terminal"
            >
              {order.strategy}
            </Badge>
          ) : null}
          <span className="font-mono text-[11px] tabular-nums text-muted-foreground">
            {isGtt && order.stopPriceCents && order.limitPriceCents
              ? `${order.qty} · T ${formatInr(order.stopPriceCents)} · L ${formatInr(order.limitPriceCents)}`
              : `${order.qty} @ ${price ? formatInr(price) : "MKT"}`}
          </span>
        </p>
        {isStrategyEntry ? (
          <p className="mt-0.5 font-mono text-[10px] tabular-nums text-muted-foreground">
            {order.stopPriceCents
              ? `SL ${formatInr(order.stopPriceCents)}`
              : "SL —"}
            {order.strategy === "BO" && order.targetCents
              ? ` · T ${formatInr(order.targetCents)}`
              : ""}
          </p>
        ) : isLeg && order.parentOrderId && !indent ? (
          // Orphan leg — the parent entry is absent from the current page.
          <p className="mt-0.5 truncate font-mono text-[10px] text-muted-foreground">
            leg of parent ·{order.parentOrderId.slice(-6)}
          </p>
        ) : !isLeg && !order.strategy ? (
          <p className="mt-0.5 truncate font-mono text-[10px] text-muted-foreground">
            {order.product}
            {order.status === "QUEUED" && order.activateAt
              ? ` · Releases ~${formatTimeHM(order.activateAt)}`
              : ""}
            {isGtt && order.expiresAt
              ? ` · Expires ${formatDateShort(order.expiresAt)}`
              : ""}
          </p>
        ) : null}
      </div>

      <StatusBadge order={order} />

      {exitable ? (
        <Button
          variant="outline"
          className="h-11 shrink-0 border-terminal/40 px-3 text-xs text-terminal hover:bg-terminal/10 hover:text-terminal"
          disabled={exitPending}
          onClick={onExit}
          aria-label={`Exit ${order.side} ${order.qty} ${order.symbol} position`}
        >
          Exit
        </Button>
      ) : null}

      {cancellable ? (
        <Button
          variant="outline"
          className="h-11 shrink-0 border-loss/40 px-3 text-xs text-loss hover:bg-loss/10 hover:text-loss"
          disabled={cancelPending}
          onClick={onCancel}
          aria-label={`Cancel ${order.side} ${order.qty} ${order.symbol} order`}
        >
          Cancel
        </Button>
      ) : exitable ? null : (
        <span className="w-[1px]" aria-hidden="true" />
      )}
    </li>
  );
}

/** TARGET (profit) / STOP (loss) / EXIT (terminal amber) mono leg badges. */
function LegBadge({ legKind }: { legKind: OrderLegKind }) {
  return (
    <Badge
      variant="outline"
      className={cn(
        "px-1.5 py-0 font-mono text-[10px] font-semibold",
        legKind === "TARGET" && "border-profit/40 bg-profit/10 text-profit",
        legKind === "STOP" && "border-loss/50 bg-loss/10 text-loss",
        legKind === "EXIT" && "border-terminal/40 bg-terminal/10 text-terminal"
      )}
    >
      {legKind}
    </Badge>
  );
}

function StatusBadge({ order }: { order: OrderDTO }) {
  const status = order.status as OrderStatus;
  const label =
    status === "PARTIALLY_FILLED"
      ? `PARTIAL ${order.filledQty}/${order.qty}`
      : status;

  if (status === "REJECTED") {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge
            variant="outline"
            className="shrink-0 border-loss/50 bg-loss/10 font-mono text-[10px] font-semibold text-loss"
          >
            REJECTED
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          {order.rejectReason ?? "Risk check failed"}
        </TooltipContent>
      </Tooltip>
    );
  }

  return (
    <Badge
      variant="outline"
      className={cn(
        "shrink-0 gap-1.5 px-1.5 py-0 font-mono text-[10px] font-semibold",
        status === "FILLED" && "border-profit/40 bg-profit/10 text-profit",
        (status === "NEW" || status === "PARTIALLY_FILLED") &&
          "border-terminal/40 bg-terminal/10 text-terminal",
        status === "QUEUED" &&
          "border-border/60 bg-muted/30 text-muted-foreground",
        status === "CANCELED" && "text-muted-foreground"
      )}
    >
      <span
        aria-hidden="true"
        className={cn(
          "size-1.5 rounded-full",
          status === "FILLED" && "bg-profit",
          status === "NEW" && "animate-pulse bg-terminal motion-reduce:animate-none",
          status === "PARTIALLY_FILLED" && "animate-pulse bg-terminal motion-reduce:animate-none",
          status === "QUEUED" && "bg-muted-foreground/70",
          status === "CANCELED" && "bg-muted-foreground"
        )}
      />
      {label}
    </Badge>
  );
}
