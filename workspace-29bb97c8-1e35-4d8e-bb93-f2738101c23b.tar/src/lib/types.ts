/**
 * MERIDIAN — shared API contract types (client side).
 * Mirrors ARCHITECTURE.md §4 (Phase 1) and §6 (Phase 2). Never import server code here.
 * Money = integer minor units (paise for INR). Never floats.
 */

/* ---------- primitives ---------- */

export type Role = "USER" | "ADMIN";

/** KYC lifecycle. Anything !== "APPROVED" is treated as "not approved yet". */
export type KycStatus =
  | "UNSUBMITTED"
  | "NOT_STARTED"
  | "PENDING"
  | "APPROVED"
  | "REJECTED";

export type AssetType = "STOCK" | "ETF" | "CRYPTO" | "INDEX";

export type OtpChannel = "EMAIL" | "SMS";

export type DocType = "PAN" | "AADHAAR" | "PASSPORT" | "DRIVERS_LICENSE";

export type LedgerDirection = "CREDIT" | "DEBIT";

export type OrderSide = "BUY" | "SELL";
export type OrderKind = "MARKET" | "LIMIT" | "STOP" | "STOP_LIMIT" | "GTT";
/** Delivery vs intraday margin products (Phase 4 margin engine). */
export type OrderProduct = "CNC" | "MIS";
/** CO (Cover) / BO (Bracket) strategy families — entry orders carry this. */
export type OrderStrategy = "CO" | "BO";
export type OrderLegKind = "ENTRY" | "TARGET" | "STOP" | "EXIT";
export type OrderStatus =
  | "QUEUED" // AMO: waiting for the next simulated session open
  | "NEW"
  | "PARTIALLY_FILLED"
  | "FILLED"
  | "CANCELED"
  | "REJECTED";

/* ---------- price alerts (Phase 3) ---------- */

export type AlertCondition = "ABOVE" | "BELOW";
export type AlertStatus = "ACTIVE" | "TRIGGERED" | "CANCELED";

export interface PriceAlertDTO {
  id: string;
  symbol: string;
  name?: string;
  condition: AlertCondition;
  targetCents: number;
  status: AlertStatus;
  createdAt: string;
  triggeredAt?: string | null;
}

export interface CreateAlertPayload {
  symbol: string;
  condition: AlertCondition;
  targetCents: number;
}

export interface AlertsResponse {
  alerts: PriceAlertDTO[];
}

/* ---------- notifications (Phase 4) ---------- */

export type NotificationType =
  | "ORDER_PLACED"
  | "ORDER_FILLED"
  | "ORDER_REJECTED"
  | "ORDER_CANCELLED"
  | "ORDER_EXITED"
  | "LEG_CREATED"
  | "OCO_COMPLETED"
  | "ALERT_TRIGGERED"
  | "RISK"
  | "SYSTEM";

export interface NotificationDTO {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  refType?: string | null;
  refId?: string | null;
  readAt?: string | null;
  createdAt: string;
}

export interface NotificationsResponse {
  notifications: NotificationDTO[];
  unread: number;
}

export interface MarkNotificationsReadPayload {
  ids?: string[];
  all?: boolean;
}

/* ---------- auth ---------- */

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: Role;
  status: string;
  mfaEnabled: boolean;
  phoneVerified: boolean;
  kycStatus: KycStatus;
  onboardingDone: boolean;
}

export interface SessionResponse {
  authenticated: boolean;
  user?: SessionUser;
}

export interface RegisterPayload {
  email: string;
  password: string;
  name: string;
}

export interface RegisterResponse {
  user: {
    id: string;
    email: string;
    name: string;
    role: Role;
  };
}

export type LoginPayload = { email: string; password: string };

export type LoginResponse =
  | { status: "ok" }
  | { status: "mfa_required"; tempToken: string };

export type LoginMfaPayload = { tempToken: string; code: string };
export type LoginMfaResponse = { status: "ok" };

export interface LogoutResponse {
  ok: boolean;
}

/* ---------- OTP (one-time codes) ---------- */

export interface OtpRequestPayload {
  channel: OtpChannel;
  destination: string;
}

export interface OtpRequestResponse {
  challengeId: string;
  expiresAt: string;
  /** Sandbox only — shown in the UI because there is no SMS/email gateway. */
  devCode: string;
}

export interface OtpVerifyPayload {
  challengeId: string;
  code: string;
}

export interface OtpVerifyResponse {
  verified: boolean;
}

/* ---------- MFA (TOTP) ---------- */

export interface MfaSetupResponse {
  secret: string;
  otpauthUri: string;
  qrDataUrl: string;
}

export interface MfaEnablePayload {
  code: string;
}

export interface MfaEnableResponse {
  enabled: boolean;
}

export interface MfaDisablePayload {
  password: string;
}

export interface MfaDisableResponse {
  enabled: boolean;
}

/* ---------- KYC ---------- */

export interface KycSubmitPayload {
  legalFirstName: string;
  legalLastName: string;
  dateOfBirth: string; // ISO date (yyyy-mm-dd)
  country: string;
  address1: string;
  address2?: string;
  city: string;
  region: string;
  postalCode: string;
  taxIdLast4: string;
  docType: DocType;
  docNumber: string;
  pep: boolean;
}

export interface KycSubmitResponse {
  status: "PENDING";
}

export interface KycStatusResponse {
  status: KycStatus;
  onboardingDone: boolean;
}

/* ---------- portfolio / ledger ---------- */

export interface LedgerEntry {
  id: string;
  direction: LedgerDirection;
  category: "DEPOSIT" | "TRADE" | "FEE" | "ADJUSTMENT" | string;
  memo?: string;
  amountCents: number;
  balanceAfterCents: number;
  createdAt?: string;
  refType?: string;
  refId?: string;
}

/** Holding with live mark-to-market (Phase 2). */
export interface PositionDetail {
  symbol: string;
  name: string;
  qty: number;
  avgCostCents: number;
  lastPriceCents: number;
  mktValueCents: number;
  unrealizedPnlCents: number;
  dayPnlCents: number;
  dayPnlPct: number;
}

export interface PortfolioSummary {
  cashAvailableCents: number;
  cashPendingCents: number;
  positionsValueCents: number;
  totalEquityCents: number;
  dayPnlCents: number;
  dayPnlPct: number;
  positions: PositionDetail[];
  ledger: LedgerEntry[];
}

/* ---------- market data ---------- */

export interface MarketQuote {
  symbol: string;
  name: string;
  type: AssetType;
  exchange?: string;
  lastPriceCents: number;
  prevCloseCents?: number;
  changeCents: number;
  changePct: number;
  volume: number;
}

export interface MarketOverview {
  movers: MarketQuote[];
  indices: MarketQuote[];
}

/* ---------- watchlist ---------- */

export interface WatchlistItem {
  symbol: string;
  addedAt?: string;
}

export interface WatchlistResponse {
  items: WatchlistItem[];
}

/* ---------- trading (Phase 2 — §6b) ---------- */

export interface OrderDTO {
  id: string;
  symbol: string;
  side: OrderSide;
  type: OrderKind;
  qty: number;
  product: OrderProduct;
  /** CO | BO on the ENTRY order of a strategy family; legs are null. */
  strategy?: OrderStrategy | null;
  legKind?: OrderLegKind | null;
  parentOrderId?: string | null;
  /** BO: target exit price (profit leg). */
  targetCents?: number | null;
  limitPriceCents?: number | null;
  stopPriceCents?: number | null;
  timeInForce: string;
  status: OrderStatus;
  filledQty: number;
  avgFillPriceCents: number;
  rejectReason?: string | null;
  brokerRef?: string | null;
  /** GTT: cancel if unfilled by this time. */
  expiresAt?: string | null;
  /** AMO: eligible for execution at this time. */
  activateAt?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface PlaceOrderPayload {
  symbol: string;
  side: OrderSide;
  type: OrderKind;
  qty: number;
  /** CNC (delivery, 1x, SELL needs holdings) | MIS (intraday, 5x, shorting OK). Default CNC. */
  product?: OrderProduct;
  /** CO/BO only: MARKET or LIMIT entry. The payload `type` becomes the entry type. */
  strategy?: OrderStrategy;
  /** CO/BO only: target exit price (BO profit leg). */
  targetCents?: number;
  limitPriceCents?: number;
  stopPriceCents?: number;
  timeInForce?: "DAY" | "GTC";
  /** GTT: cancel if unfilled by this ISO time (max 365 days out). */
  expiresAt?: string;
  /** After-market order: queue until the next simulated session open. */
  amo?: boolean;
}

export interface FillInfo {
  qty: number;
  priceCents: number;
  feeCents: number;
}

export interface PlaceOrderResponse {
  order: OrderDTO;
  fill?: FillInfo;
}

export interface OrdersResponse {
  orders: OrderDTO[];
}

/* ---------- margin engine (Phase 4) ---------- */

export interface MarginRequest {
  symbol: string;
  side: OrderSide;
  type: OrderKind;
  qty: number;
  product?: OrderProduct;
  strategy?: OrderStrategy;
  limitPriceCents?: number;
  stopPriceCents?: number;
  targetCents?: number;
}

export interface MarginResponse {
  notionalCents: number;
  requiredCents: number;
  availableCents: number;
  leverage: number;
  feeEstimateCents: number;
}

/* ---------- risk console (Phase 4, ADMIN) ---------- */

export interface RiskStatusResponse {
  killSwitch: boolean;
  source: "flag" | "env" | "off";
}

export interface RiskToggleResponse {
  killSwitch: boolean;
}

/* ---------- market data WS (Phase 2 — §6a) ---------- */

export interface TickQuote {
  symbol: string;
  name: string;
  type: AssetType;
  exchange: string;
  lastPriceCents: number;
  prevCloseCents: number;
  openCents: number;
  highCents: number;
  lowCents: number;
  changeCents: number;
  changePct: number;
  volume: number;
  ts: number;
}

export interface DepthLevel {
  priceCents: number;
  qty: number;
}

export interface DepthSnapshot {
  symbol: string;
  bids: DepthLevel[];
  asks: DepthLevel[];
  ts: number;
}

export interface Candle {
  t: string;
  openCents: number;
  highCents: number;
  lowCents: number;
  closeCents: number;
  volume: number;
}

export interface CandlesResponse {
  symbol: string;
  bars: Candle[];
}

export interface WsTicketResponse {
  ticket: string;
}

/** Risk-engine reject codes (§6b). */
export type RiskRejectCode =
  | "KILL_SWITCH"
  | "MARKET_CLOSED"
  | "NOT_TRADEABLE"
  | "PRICE_BAND"
  | "INSUFFICIENT_FUNDS"
  | "INSUFFICIENT_QTY"
  | "INVALID_PRODUCT"
  | "INVALID_LEG"
  | "FEED_UNAVAILABLE";

/** WS user-room events (§6a + Phase 3 + Phase 4). */
export type UserWsEvent = "order-update" | "portfolio-nudge" | "alert" | "notification";

/** Payload of the `alert` WS event. */
export interface AlertEventPayload {
  alert: PriceAlertDTO;
}

/** Payload of the `notification` WS event. */
export interface NotificationEventPayload {
  notification: NotificationDTO;
}
