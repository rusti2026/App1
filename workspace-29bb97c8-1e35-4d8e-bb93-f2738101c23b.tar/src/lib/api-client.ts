/**
 * MERIDIAN — typed same-origin fetch wrapper.
 *
 * - JSON headers + `credentials: "same-origin"` (session cookie) + `x-requested-with: meridian-web`
 * - Throws typed `ApiError { status, code, message }` from `{ error, code? }` bodies
 * - Globally handles session expiry (401) via a window event, EXCEPT for the
 *   auth endpoints where a 401 is an expected user-level failure (bad password,
 *   bad OTP code…), not a stale session.
 */

export class ApiError extends Error {
  readonly status: number;
  readonly code?: string;

  constructor(status: number, message: string, code?: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}

/** Fired on unexpected 401s so the app shell can reset to the landing view. */
export const SESSION_EXPIRED_EVENT = "meridian:session-expired";

/**
 * Debounce for the global session-expired dispatch: after a deliberate sign-out
 * several in-flight authenticated queries can 401 at once; only the first one
 * within this window triggers the global toast + SPA reset.
 */
const SESSION_EXPIRY_DEBOUNCE_MS = 4_000;
let lastSessionExpiryAt = 0;

/** Endpoints where 401 is a *user* error (bad credentials / wrong code), not an expired session. */
const AUTH_FALLBACK_PATHS = new Set([
  "/api/auth/session", // returns 200 { authenticated:false }; never "expired"
  "/api/auth/login",
  "/api/auth/login/mfa",
  "/api/auth/register",
  "/api/auth/otp/request",
  "/api/auth/otp/verify",
]);

export type ApiFetchOptions = Omit<RequestInit, "body"> & {
  /** JSON-serializable request body — sent as JSON automatically. */
  json?: unknown;
};

export async function apiFetch<T>(
  path: string,
  options: ApiFetchOptions = {}
): Promise<T> {
  const { json, headers, ...rest } = options;

  let res: Response;
  try {
    res = await fetch(path, {
      ...rest,
      credentials: "same-origin",
      headers: {
        "x-requested-with": "meridian-web",
        ...(json !== undefined ? { "Content-Type": "application/json" } : {}),
        ...(headers as Record<string, string> | undefined),
      },
      body: json !== undefined ? JSON.stringify(json) : undefined,
    });
  } catch {
    throw new ApiError(0, "Network error — check your connection and retry.");
  }

  if (res.status === 401 && !AUTH_FALLBACK_PATHS.has(path.split("?")[0])) {
    if (typeof window !== "undefined") {
      const now = Date.now();
      if (now - lastSessionExpiryAt >= SESSION_EXPIRY_DEBOUNCE_MS) {
        lastSessionExpiryAt = now;
        window.dispatchEvent(new CustomEvent(SESSION_EXPIRED_EVENT));
      }
    }
  }

  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    let code: string | undefined;
    try {
      const data = (await res.json()) as { error?: unknown; code?: unknown };
      if (typeof data.error === "string" && data.error.length > 0) {
        message = data.error;
      }
      if (typeof data.code === "string") code = data.code;
    } catch {
      /* non-JSON error body — keep the generic message */
    }
    throw new ApiError(res.status, message, code);
  }

  if (res.status === 204) return undefined as T;

  try {
    return (await res.json()) as T;
  } catch {
    return undefined as T;
  }
}
