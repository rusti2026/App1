/**
 * MERIDIAN — in-memory sliding-window rate limiter (sandbox stand-in for Redis).
 * Same call shape as a production Redis implementation (INCR+EXPIRE / sorted set).
 */

const buckets = new Map<string, number[]>();

/** Returns true when the action is ALLOWED. */
export function rateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const hits = buckets.get(key) ?? [];
  const recent = hits.filter((t) => now - t < windowMs);
  if (recent.length >= limit) {
    buckets.set(key, recent);
    return false;
  }
  recent.push(now);
  buckets.set(key, recent);
  if (buckets.size > 10_000) {
    // Opportunistic GC so the map cannot grow unbounded.
    for (const [k, v] of buckets) {
      if (v.every((t) => now - t >= windowMs)) buckets.delete(k);
    }
  }
  return true;
}

export const WINDOW = {
  SEC_10: 10_000,
  MIN_1: 60_000,
  MIN_15: 15 * 60_000,
  MIN_30: 30 * 60_000,
} as const;
