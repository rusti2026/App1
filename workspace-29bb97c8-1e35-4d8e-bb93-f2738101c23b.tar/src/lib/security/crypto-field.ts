/**
 * MERIDIAN — field-level encryption at rest (AES-256-GCM).
 * Ciphertext format: v1.<iv-b64>.<authTag-b64>.<ciphertext-b64>
 * Key: FIELD_ENCRYPTION_KEY env var, 64 hex chars (32 bytes).
 */
import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";

function key(): Buffer {
  const hex = process.env.FIELD_ENCRYPTION_KEY;
  if (!hex || hex.length !== 64) {
    throw new Error("FIELD_ENCRYPTION_KEY missing — must be 64 hex chars (32 bytes). Add it to .env");
  }
  return Buffer.from(hex, "hex");
}

export function encryptField(plaintext: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key(), iv);
  const enc = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1.${iv.toString("base64")}.${tag.toString("base64")}.${enc.toString("base64")}`;
}

export function decryptField(payload: string | null | undefined): string {
  if (!payload) return "";
  try {
    const [v, ivB64, tagB64, dataB64] = payload.split(".");
    if (v !== "v1") return "";
    const decipher = createDecipheriv("aes-256-gcm", key(), Buffer.from(ivB64, "base64"));
    decipher.setAuthTag(Buffer.from(tagB64, "base64"));
    return Buffer.concat([decipher.update(Buffer.from(dataB64, "base64")), decipher.final()]).toString("utf8");
  } catch {
    return "";
  }
}
