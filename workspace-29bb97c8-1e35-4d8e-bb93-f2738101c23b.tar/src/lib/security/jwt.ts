/**
 * MERIDIAN — HS256 JWT (zero-dependency, Node crypto).
 * Used for: session cookies (purpose "session", 7d, revocable via Session row)
 *           and MFA login challenges (purpose "mfa", 10 min, stateless).
 */
import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";

export type TokenPurpose = "session" | "mfa" | "ws";

interface TokenPayload {
  sub: string;        // userId
  jti: string;        // session id (session) or random nonce (mfa)
  purpose: TokenPurpose;
  iat: number;
  exp: number;        // epoch seconds
}

function secret(): string {
  const s = process.env.AUTH_SECRET;
  if (!s || s.length < 32) {
    // Fail loudly in dev rather than silently using a weak key.
    throw new Error("AUTH_SECRET missing or too short (>=32 chars). Add it to .env");
  }
  return s;
}

const b64url = (buf: Buffer | string) => Buffer.from(buf).toString("base64url");

export function signToken(
  sub: string,
  purpose: TokenPurpose,
  ttlSeconds: number,
  jti?: string
): { token: string; jti: string; payload: TokenPayload } {
  const id = jti ?? randomUUID();
  const iat = Math.floor(Date.now() / 1000);
  const payload: TokenPayload = { sub, jti: id, purpose, iat, exp: iat + ttlSeconds };
  const head = b64url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const body = b64url(JSON.stringify(payload));
  const data = `${head}.${body}`;
  const sig = createHmac("sha256", secret()).update(data).digest("base64url");
  return { token: `${data}.${sig}`, jti: id, payload };
}

export function verifyToken(token: string, purpose: TokenPurpose): TokenPayload | null {
  try {
    const [head, body, sig] = token.split(".");
    if (!head || !body || !sig) return null;
    const expected = createHmac("sha256", secret()).update(`${head}.${body}`).digest();
    const given = Buffer.from(sig, "base64url");
    if (given.length !== expected.length || !timingSafeEqual(given, expected)) return null;
    const payload = JSON.parse(Buffer.from(body, "base64url").toString()) as TokenPayload;
    if (payload.purpose !== purpose) return null;
    if (typeof payload.exp !== "number" || payload.exp * 1000 < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

export const SESSION_TTL_SECONDS = 7 * 24 * 60 * 60; // 7 days
export const MFA_CHALLENGE_TTL_SECONDS = 10 * 60;    // 10 minutes
