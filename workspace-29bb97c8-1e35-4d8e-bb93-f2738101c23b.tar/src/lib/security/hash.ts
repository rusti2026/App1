/**
 * MERIDIAN — password hashing (scrypt, FIPS-friendly KDF, zero deps).
 * Format: scrypt$N$r$p$saltHex$hashHex  — parameters embedded for future upgrades.
 */
import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";

const N = 16384, R = 8, P = 1, KEYLEN = 64, MAXMEM = 128 * 1024 * 1024;

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, KEYLEN, { N, r: R, p: P, maxmem: MAXMEM });
  return `scrypt$${N}$${R}$${P}$${salt.toString("hex")}$${hash.toString("hex")}`;
}

export function verifyPassword(password: string, stored: string | null | undefined): boolean {
  if (!stored) {
    // Equalize timing for unknown users: run a throwaway scrypt derivation.
    scryptSync(password, randomBytes(16), KEYLEN, { N, r: R, p: P, maxmem: MAXMEM });
    return false;
  }
  try {
    const [alg, n, r, p, saltHex, hashHex] = stored.split("$");
    if (alg !== "scrypt") return false;
    const hash = scryptSync(password, Buffer.from(saltHex, "hex"), hashHex.length / 2, {
      N: Number(n), r: Number(r), p: Number(p), maxmem: MAXMEM,
    });
    return timingSafeEqual(hash, Buffer.from(hashHex, "hex"));
  } catch {
    return false;
  }
}

/** sha256 hex — used for OTP codes and session token hashes (fast, NOT for passwords). */
export function sha256Hex(input: string): string {
  return createHash("sha256").update(input).digest("hex");
}
