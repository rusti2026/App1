/**
 * MERIDIAN — server-side session lifecycle + user DTO mapping.
 */
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { SESSION_COOKIE } from "@/lib/api-utils";
import { SESSION_TTL_SECONDS, signToken } from "@/lib/security/jwt";
import { sha256Hex } from "@/lib/security/hash";
import type { User, KycProfile } from "@prisma/client";

export async function createSession(user: User, req: NextRequest): Promise<NextResponse> {
  const { token, jti } = signToken(user.id, "session", SESSION_TTL_SECONDS);
  const expiresAt = new Date(Date.now() + SESSION_TTL_SECONDS * 1000);
  await db.session.create({
    data: {
      id: jti, // JWT jti ↔ Session row id → server-side revocation
      userId: user.id,
      tokenHash: sha256Hex(token),
      ip: req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "127.0.0.1",
      userAgent: req.headers.get("user-agent") ?? null,
      expiresAt,
    },
  });
  const res = NextResponse.json({ status: "ok" }, { status: 200 });
  res.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: SESSION_TTL_SECONDS,
  });
  return res;
}

export function clearSessionCookie(res: NextResponse): NextResponse {
  res.cookies.set(SESSION_COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 0,
  });
  return res;
}

export type UserWithKyc = User & { kycProfile: KycProfile | null };

/** Map a user to the public session DTO (see ARCHITECTURE.md §4). */
export function toSessionUser(user: UserWithKyc) {
  const kycStatus = user.kycProfile?.status ?? "UNSUBMITTED";
  return {
    id: user.id,
    email: user.email,
    name: user.name ?? user.email.split("@")[0],
    role: user.role as "USER" | "ADMIN",
    status: user.status,
    mfaEnabled: user.mfaEnabled,
    phoneVerified: user.phoneVerified,
    kycStatus,
    onboardingDone: kycStatus === "APPROVED",
  };
}

/** Simulated compliance reviewer: auto-approves PENDING KYC after a short delay. */
export async function settleKycIfDue(userId: string): Promise<KycProfile | null> {
  const profile = await db.kycProfile.findUnique({ where: { userId } });
  if (!profile) return null;
  if (
    profile.status === "PENDING" &&
    profile.submittedAt &&
    Date.now() - profile.submittedAt.getTime() > 5000
  ) {
    return db.kycProfile.update({
      where: { id: profile.id },
      data: {
        status: "APPROVED",
        reviewedAt: new Date(),
        reviewNote: "Simulated compliance auto-review (sandbox)",
      },
    });
  }
  return profile;
}
