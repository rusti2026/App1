/**
 * MERIDIAN — append-only security audit trail.
 * Every privileged event (auth, MFA, KYC, admin) is recorded with request context.
 */
import { db } from "@/lib/db";
import { getClientIp } from "@/lib/api-utils";

export type AuditAction =
  | "REGISTER"
  | "LOGIN_OK"
  | "LOGIN_FAILED"
  | "LOGIN_MFA_OK"
  | "LOGIN_MFA_FAILED"
  | "LOGOUT"
  | "OTP_REQUEST"
  | "OTP_VERIFIED"
  | "OTP_FAILED"
  | "MFA_SETUP"
  | "MFA_ENABLED"
  | "MFA_DISABLE_FAILED"
  | "MFA_DISABLED"
  | "KYC_SUBMITTED"
  | "WATCHLIST_ADD"
  | "WATCHLIST_REMOVE"
  | "SESSION_REJECTED"
  | "ORDER_PLACED"
  | "ORDER_FILLED"
  | "ORDER_REJECTED"
  | "ORDER_CANCELLED"
  | "ORDER_EXITED"
  | "RISK_KILL_SWITCH_ON"
  | "RISK_KILL_SWITCH_OFF"
  | "ALERT_CREATED"
  | "ALERT_TRIGGERED"
  | "ALERT_CANCELED";

export async function audit(
  action: AuditAction,
  req: Request,
  opts: { userId?: string | null; detail?: string } = {}
): Promise<void> {
  try {
    await db.auditLog.create({
      data: {
        action,
        userId: opts.userId ?? null,
        ip: getClientIp(req),
        userAgent: req.headers.get("user-agent") ?? null,
        detail: opts.detail ?? null,
      },
    });
  } catch {
    // Never let audit failures break the main flow; production ships these to a queue.
  }
}

/**
 * System-context audit for background processes (e.g. the exchange matcher)
 * that have no Request object. ip=null, userAgent="meridian-matcher".
 * detail carries { userId?, detail?, ...extra } — userId/detail are extracted
 * into columns, the rest is ignored (keeps the schema unchanged).
 */
export async function auditSystem(
  action: string,
  detail: Record<string, unknown>
): Promise<void> {
  try {
    await db.auditLog.create({
      data: {
        action,
        userId: typeof detail.userId === "string" ? detail.userId : null,
        ip: null,
        userAgent: "meridian-matcher",
        detail: typeof detail.detail === "string" ? detail.detail : null,
      },
    });
  } catch {
    // Never let audit failures break the main flow.
  }
}
