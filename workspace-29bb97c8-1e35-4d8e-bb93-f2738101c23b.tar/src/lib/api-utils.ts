/**
 * MERIDIAN — route-handler utilities: responses, origin guard, rate-limit keys,
 * auth guard (revocable JWT session ↔ Session row), zod body parsing.
 */
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { sha256Hex } from "@/lib/security/hash";
import { verifyToken } from "@/lib/security/jwt";
import type { User } from "@prisma/client";

export const SESSION_COOKIE = "meridian_session";

export function ok<T>(data: T, status = 200) {
  return NextResponse.json(data, { status });
}

export function fail(status: number, error: string, code?: string) {
  return NextResponse.json({ error, ...(code ? { code } : {}) }, { status });
}

export function getClientIp(req: NextRequest | Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0]!.trim();
  return req.headers.get("x-real-ip") ?? "127.0.0.1";
}

/**
 * CSRF defense-in-depth:
 *  1. If an Origin header is present (browsers always send it on mutations), it must
 *     match the serving host.
 *  2. Non-browser clients must carry our custom `x-requested-with` marker.
 */
export function passesOriginGuard(req: NextRequest): boolean {
  const origin = req.headers.get("origin");
  if (origin) {
    try {
      const originHost = new URL(origin).host;
      const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
      if (!host || originHost !== host) return false;
    } catch {
      return false;
    }
    return true;
  }
  return req.headers.get("x-requested-with") === "meridian-web";
}

export function rateKey(req: NextRequest, scope: string, extra?: string): string {
  return `${scope}:${extra ?? getClientIp(req)}`;
}

export async function parseBody<T extends z.ZodType>(
  req: NextRequest,
  schema: T
): Promise<{ data: z.infer<T> } | { response: NextResponse }> {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return { response: fail(400, "Invalid JSON body") };
  }
  const parsed = schema.safeParse(raw);
  if (!parsed.success) {
    const first = parsed.error.issues[0];
    return { response: fail(400, first ? `${first.path.join(".") || "body"}: ${first.message}` : "Invalid payload", "VALIDATION") };
  }
  return { data: parsed.data };
}

export type AuthResult = { user: User } | NextResponse;

/**
 * Verifies the session cookie: signature → purpose → Session row (not revoked,
 * not expired, token hash match) → ACTIVE user. Sessions are server-revocable.
 */
export async function requireAuth(req: NextRequest): Promise<AuthResult> {
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  if (!token) return fail(401, "Authentication required", "NO_SESSION");
  const payload = verifyToken(token, "session");
  if (!payload) return fail(401, "Session invalid or expired", "BAD_TOKEN");
  const session = await db.session.findUnique({ where: { id: payload.jti } });
  if (!session || session.revokedAt || session.expiresAt < new Date() || session.tokenHash !== sha256Hex(token)) {
    return fail(401, "Session invalid or expired", "SESSION_GONE");
  }
  const user = await db.user.findUnique({ where: { id: session.userId } });
  if (!user || user.status !== "ACTIVE") return fail(403, "Account unavailable", "USER_INACTIVE");
  return { user };
}

export function isAuthed(r: AuthResult): r is { user: User } {
  return !(r instanceof NextResponse);
}

/**
 * ADMIN-only guard (RBAC, Phase 4 risk console): session auth first, then the
 * role check. Non-admins get 403 ROLE_REQUIRED.
 */
export async function requireAdmin(req: NextRequest): Promise<AuthResult> {
  const auth = await requireAuth(req);
  if (!isAuthed(auth)) return auth;
  if (auth.user.role !== "ADMIN") return fail(403, "Admin role required.", "ROLE_REQUIRED");
  return auth;
}

/** Simulation flag for the compliance auto-reviewer (sandbox). */
export const KYC_AUTO_REVIEW_DELAY_MS = 5_000;
