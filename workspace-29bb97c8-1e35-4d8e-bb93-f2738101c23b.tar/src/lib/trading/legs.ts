/**
 * MERIDIAN — CO/BO strategy-leg engine (Phase 4, ARCHITECTURE.md §8b).
 *
 * Legs are plain Order rows with legKind set (TARGET / STOP / EXIT) and
 * parentOrderId pointing at the strategy ENTRY order. They flow through the
 * existing matcher (LIMIT/STOP resting logic, MARKET sweep) — no new fill
 * mechanics. legKind is what keeps the engine from recursing: legs are never
 * created with legKind "ENTRY" and `onEntryFilled` ignores anything else.
 *
 * OCO semantics: when a TARGET or STOP leg fills, every still-open sibling leg
 * of the same parent is canceled (rejectReason "OCO_CLOSED").
 */
import type { Order } from "@prisma/client";
import { db } from "@/lib/db";
import { auditSystem } from "@/lib/security/audit";
import { emitToUser, notifyUser } from "@/lib/trading/notify";
import { toOrderDTO } from "@/lib/trading/dto";
import type { OrderSide } from "@/lib/types";

const inr = (cents: number): string => `₹${(cents / 100).toFixed(2)}`;

/** Legs are intraday MIS orders that work like their entry counterpart. */
function legBase(entry: Order, side: OrderSide) {
  return {
    userId: entry.userId,
    symbol: entry.symbol,
    side,
    qty: entry.qty,
    product: "MIS" as const,
    timeInForce: "DAY" as const,
    parentOrderId: entry.id,
    // strategy stays null on legs — only ENTRY rows carry CO/BO, which (with
    // legKind) is what prevents onEntryFilled from recursing on a filled leg.
    status: "NEW" as const,
  };
}

/**
 * Called ONCE when a strategy ENTRY order fills (placement path + matcher).
 * CO arms a STOP leg; BO arms a TARGET leg + STOP leg. Never throws — a leg
 * failure must not corrupt the already-committed entry fill.
 */
export async function onEntryFilled(order: Order): Promise<void> {
  if (order.legKind !== "ENTRY" || !order.strategy) return;
  const exitSide: OrderSide = order.side === "BUY" ? "SELL" : "BUY";
  const stop = order.stopPriceCents;
  const target = order.strategy === "BO" ? order.targetCents : null;
  if (!stop) return; // defensive — placement validation guarantees stopPriceCents

  try {
    if (target) {
      // BO: profit leg (LIMIT at the target) + stop leg.
      const targetLeg = await db.order.create({
        data: {
          ...legBase(order, exitSide),
          type: "LIMIT",
          limitPriceCents: target,
          legKind: "TARGET",
        },
      });
      await emitToUser(order.userId, "order-update", { order: toOrderDTO(targetLeg) });
    }
    const stopLeg = await db.order.create({
      data: {
        ...legBase(order, exitSide),
        type: "STOP",
        stopPriceCents: stop,
        legKind: "STOP",
      },
    });
    await emitToUser(order.userId, "order-update", { order: toOrderDTO(stopLeg) });

    await auditSystem("LEG_CREATED", {
      userId: order.userId,
      detail: `${order.strategy} legs for ${order.side} ${order.qty} ${order.symbol}${
        target ? `: TARGET @ ${inr(target)} +` : ":"
      } STOP @ ${inr(stop)} (entry ${order.id})`,
    });
    await notifyUser(order.userId, {
      type: "LEG_CREATED",
      title: order.strategy === "BO" ? "Bracket armed" : "Cover armed",
      body: target
        ? `${order.qty} ${order.symbol} protected — target ${inr(target)}, stop-loss ${inr(stop)}.`
        : `${order.qty} ${order.symbol} protected — stop-loss trigger ${inr(stop)}.`,
      refType: "ORDER",
      refId: order.id,
    });
  } catch (e) {
    console.error("[legs] onEntryFilled failed:", e);
  }
}

/**
 * Called when a leg fills. TARGET/STOP → OCO: cancel still-open siblings of
 * the same parent (rejectReason "OCO_CLOSED") and notify. EXIT → the manual
 * exit completed; notify. Never throws.
 */
export async function handleLegFill(leg: Order): Promise<void> {
  if (leg.legKind !== "TARGET" && leg.legKind !== "STOP" && leg.legKind !== "EXIT") return;

  try {
    if (leg.legKind === "TARGET" || leg.legKind === "STOP") {
      const siblings = await db.order.findMany({
        where: {
          parentOrderId: leg.parentOrderId,
          id: { not: leg.id },
          status: { in: ["NEW", "PARTIALLY_FILLED"] },
        },
      });
      for (const sib of siblings) {
        const canceled = await db.order.update({
          where: { id: sib.id },
          data: { status: "CANCELED", rejectReason: "OCO_CLOSED" },
        });
        await auditSystem("ORDER_CANCELLED", {
          userId: leg.userId,
          detail: `OCO closed ${sib.legKind ?? "leg"} ${sib.side} ${sib.qty} ${sib.symbol} (${sib.id}) — ${leg.legKind} leg filled`,
        });
        await emitToUser(leg.userId, "order-update", { order: toOrderDTO(canceled) });
      }
      await notifyUser(leg.userId, {
        type: "OCO_COMPLETED",
        title: "Bracket completed",
        body: `${leg.legKind === "TARGET" ? "Target" : "Stop-loss"} filled at ${inr(leg.avgFillPriceCents)} — ${siblings.length} sibling leg${siblings.length === 1 ? "" : "s"} cancelled (OCO).`,
        refType: "ORDER",
        refId: leg.parentOrderId ?? undefined,
      });
    } else {
      // EXIT leg filled — the manual exit has fully landed.
      await notifyUser(leg.userId, {
        type: "ORDER_EXITED",
        title: "Position exited",
        body: `Exit filled at ${inr(leg.avgFillPriceCents)} — ${leg.side === "BUY" ? "bought back" : "sold"} ${leg.qty} ${leg.symbol}.`,
        refType: "ORDER",
        refId: leg.parentOrderId ?? undefined,
      });
    }
  } catch (e) {
    console.error("[legs] handleLegFill failed:", e);
  }
}

/** Dispatch after any fill in the matcher: entry hooks vs leg hooks. */
export async function afterFillHooks(filled: Order): Promise<void> {
  if (filled.legKind === "ENTRY" && filled.strategy) {
    await onEntryFilled(filled);
  } else if (filled.legKind === "TARGET" || filled.legKind === "STOP" || filled.legKind === "EXIT") {
    await handleLegFill(filled);
  }
}
