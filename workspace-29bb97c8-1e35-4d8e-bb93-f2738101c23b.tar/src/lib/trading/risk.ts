/**
 * MERIDIAN — risk engine. EVERY order passes through here (client-approved
 * invariant: "Risk engine — always in the order path"). Production replaces
 * these checks with SPAN + exposure margin (M7–M9); the interface stays.
 *
 * Phase 4 (§8a): funds checks are margin-based. CNC reserves the full
 * notional (leverage 1 — same semantics as before); MIS/CO/BO reserve
 * ceil(notional / 5) and allow shorting. The ±20% price band also covers
 * strategy SL/target legs — those are validated at the route level with
 * INVALID_LEG (they belong to the leg engine, not this engine).
 */
import type { OrderKind, OrderProduct, OrderSide, OrderStrategy, RiskRejectCode } from "@/lib/types";
import { estimateEntryPriceCents, requiredMarginForCents } from "@/lib/trading/margin";

export interface RiskContext {
  side: OrderSide;
  type: OrderKind;
  qty: number;
  /** CNC (delivery, 1x) | MIS (intraday, 5x). */
  product: OrderProduct;
  /** CO | BO on strategy ENTRY orders; null on plain orders and legs. */
  strategy?: OrderStrategy | null;
  /** BO target exit price (leg validation happens at the route level). */
  targetCents?: number | null;
  limitPriceCents?: number | null;
  stopPriceCents?: number | null;
  assetType: string;
  quote: { lastPriceCents: number } | null;
  cashAvailableCents: number;
  positionQty: number;
  /** Margin reserved by ALL of the user's open orders (BUY and SELL) — margin.ts. */
  openReservedMarginCents: number;
  killSwitchOn: boolean;
  marketOpen: boolean;
}

export type RiskDecision = { ok: true } | { ok: false; code: RiskRejectCode; message: string };

const reject = (code: RiskRejectCode, message: string): RiskDecision => ({ ok: false, code, message });
export const PRICE_BAND = 0.2;

/**
 * Next simulated session open for AMO orders. The sandbox exchange runs a
 * continuous feed and rolls its hourly sessions at the top of each UTC hour —
 * the analog of the pre-open release window (next trading day 09:00 IST) in
 * production. Returns the first hour boundary STRICTLY AFTER `from`
 * (e.g. 17:22:41 -> 18:00:00; exactly 18:00:00.000 -> 19:00:00).
 */
export function nextSessionOpen(from: Date): Date {
  const d = new Date(from.getTime());
  d.setUTCMinutes(0, 0, 0); // floor to the current hour boundary
  d.setUTCHours(d.getUTCHours() + 1); // roll to the next session
  return d;
}

export function assessRisk(ctx: RiskContext): RiskDecision {
  if (ctx.killSwitchOn) return reject("KILL_SWITCH", "Trading is temporarily paused by the risk desk.");
  if (!ctx.marketOpen) return reject("MARKET_CLOSED", "Markets are closed. Orders open for the next session.");
  if (ctx.assetType === "INDEX") {
    return reject("NOT_TRADEABLE", "Indices are not tradeable — use ETFs like NIFTYBEES instead.");
  }
  if (!Number.isInteger(ctx.qty) || ctx.qty < 1 || ctx.qty > 100_000) {
    return reject("INSUFFICIENT_QTY", "Quantity must be between 1 and 100,000.");
  }
  if (!ctx.quote) return reject("FEED_UNAVAILABLE", "Live price unavailable — please try again.");

  const ltp = ctx.quote.lastPriceCents;
  if (ctx.type === "LIMIT" && ctx.limitPriceCents) {
    if (Math.abs(ctx.limitPriceCents - ltp) / ltp > PRICE_BAND) {
      return reject("PRICE_BAND", "Limit price is more than 20% away from the last traded price.");
    }
  }
  // GTT carries a trigger price too — same band check as stop orders.
  if ((ctx.type === "STOP" || ctx.type === "STOP_LIMIT" || ctx.type === "GTT") && ctx.stopPriceCents) {
    if (Math.abs(ctx.stopPriceCents - ltp) / ltp > PRICE_BAND) {
      return reject("PRICE_BAND", "Trigger price is more than 20% away from the last traded price.");
    }
  }

  // Margin check (§8a): the new order's required margin plus the margin already
  // reserved by the user's open orders must fit within available cash.
  // CNC BUY keeps full-notional semantics via leverage 1. MIS/CO/BO are
  // exposure-aware: closing an opposite position releases margin (only the
  // excess needs fresh margin) so leveraged accounts can always flatten.
  const estPrice = estimateEntryPriceCents(ctx.type, ctx.side, ctx.limitPriceCents, ltp);
  const { requiredCents: requiredMargin, reducingOnly } = requiredMarginForCents(
    ctx.product,
    ctx.side,
    ctx.qty,
    ctx.positionQty,
    estPrice
  );

  if (ctx.side === "BUY") {
    if (!reducingOnly && ctx.openReservedMarginCents + requiredMargin > ctx.cashAvailableCents) {
      return reject(
        "INSUFFICIENT_FUNDS",
        ctx.product === "CNC"
          ? "Not enough buying power for this order (open orders reserve cash)."
          : "Not enough margin for this order (open orders reserve margin)."
      );
    }
  } else if (ctx.product === "CNC") {
    // Delivery sells come from holdings; the position may now be SHORT (qty < 0)
    // thanks to MIS — either way CNC cannot sell what is not held.
    if (ctx.positionQty < 0) {
      return reject(
        "INSUFFICIENT_QTY",
        "You are short this symbol — CNC sells need holdings. Use MIS for intraday trades."
      );
    }
    if (ctx.qty > ctx.positionQty) {
      return reject(
        "INSUFFICIENT_QTY",
        `You hold ${ctx.positionQty} unit(s) — CNC sells are limited to your holdings. Use MIS for intraday shorts.`
      );
    }
  } else {
    // MIS / CO / BO SELL: shorting allowed — margin is reserved on the sale
    // notional (only on the part that opens/extends a short).
    if (!reducingOnly && ctx.openReservedMarginCents + requiredMargin > ctx.cashAvailableCents) {
      return reject("INSUFFICIENT_FUNDS", "Not enough margin for this order (open orders reserve margin).");
    }
  }

  return { ok: true };
}

/** Market-order execution price with slippage, snapped to the ₹0.05 tick. */
export function marketFillPrice(side: OrderSide, ltp: number): number {
  const raw = side === "BUY" ? ltp * 1.0025 : ltp * 0.9975;
  return Math.max(5, Math.round(raw / 5) * 5);
}
