/**
 * MERIDIAN — margin engine (Phase 4, SEBI peak-margin analog; ARCHITECTURE.md §8a).
 *
 * Leverage table (post-2021 SEBI peak-margin rules):
 *   CNC  1x — delivery, full notional; SELL comes from holdings (no reservation).
 *   MIS  5x — intraday; shorting allowed, margin reserved on the sale notional.
 *   CO/BO — priced as MIS (5x).
 *
 * All amounts are integer paise. Margin is rounded UP to the whole rupee so a
 * partially-funded order can never sneak through on a rounding remainder.
 */
import type { OrderKind, OrderProduct, OrderSide } from "@/lib/types";

export const LEVERAGE: Record<OrderProduct, number> = { CNC: 1, MIS: 5 };

/**
 * Estimated entry price used for margin math.
 * - Orders whose limit price caps the fill (LIMIT / GTT / STOP_LIMIT) estimate
 *   at the limit — the worst-case execution price (GTT keeps its §7 semantics:
 *   "open GTT BUYs count toward reserved notional" at the limit price).
 * - Everything else (MARKET, STOP) estimates at LTP ±25 bps slippage buffer,
 *   snapped to the ₹0.05 tick — identical to `marketFillPrice` in risk.ts, so
 *   the reserved margin matches the eventual fill amount.
 */
export function estimateEntryPriceCents(
  type: OrderKind,
  side: OrderSide,
  limitPriceCents?: number | null,
  ltp?: number | null
): number {
  if ((type === "LIMIT" || type === "GTT" || type === "STOP_LIMIT") && limitPriceCents) {
    return limitPriceCents;
  }
  if (!ltp || ltp <= 0) return limitPriceCents ?? 0;
  const raw = side === "BUY" ? ltp * 1.0025 : ltp * 0.9975;
  return Math.max(5, Math.round(raw / 5) * 5);
}

/**
 * Margin reserved for one order. CNC SELL is funded by existing holdings → no
 * reservation; everything else reserves ceil(notional / leverage), rounded UP
 * to the whole rupee.
 */
export function marginForCents(
  product: OrderProduct,
  side: OrderSide,
  qty: number,
  estPriceCents: number
): number {
  if (product === "CNC" && side === "SELL") return 0;
  const leverage = LEVERAGE[product] ?? 1;
  const notional = Math.max(0, qty) * Math.max(0, estPriceCents);
  return Math.ceil(Math.ceil(notional / leverage) / 100) * 100;
}

/** Minimal shape of an open Order row needed for the reservation sum. */
export interface OpenMarginOrder {
  side: string; // BUY | SELL
  product?: string | null; // CNC | MIS (null → legacy CNC)
  qty: number;
  filledQty: number;
  limitPriceCents?: number | null;
}

/**
 * Sum of margin reserved by a user's OPEN orders (NEW / PARTIALLY_FILLED /
 * QUEUED) — both BUY and SELL (short sells reserve margin too).
 *
 * Estimation per open order:
 *  - the order's limit price when present (LIMIT / GTT / STOP_LIMIT) — the
 *    worst-case fill price;
 *  - 0 for MARKET orders without a limit. MARKET legs are TRANSIENT: the
 *    matcher's MARKET sweep fills them within one 2 s cycle, so their margin
 *    exposure is momentary. (Released AMO MARKET orders are the accepted gap —
 *    they wait at most until the next hourly session but reserve nothing.)
 *  - STOP orders estimate at LTP±25 bps when the caller has a quote; without a
 *    persisted limit they contribute via `estPriceCents` = 0 here for the same
 *    transient reason (stops rarely rest long, and the placement-path check
 *    for the NEW order always uses a live quote).
 *
 * Only the UNFILLED remainder (qty − filledQty) still reserves margin.
 */
export function sumReservedMarginCents(orders: OpenMarginOrder[]): number {
  return orders.reduce((sum, o) => {
    const remaining = Math.max(0, o.qty - o.filledQty);
    if (remaining <= 0) return sum;
    const estPriceCents = o.limitPriceCents ?? 0;
    const product = (o.product ?? "CNC") as OrderProduct;
    return sum + marginForCents(product, o.side as OrderSide, remaining, estPriceCents);
  }, 0);
}

/**
 * Exposure-aware margin for one order against the user's current position
 * (peak-margin analog). Closing an opposite position RELEASES margin, so only
 * the quantity beyond the closing part needs fresh margin:
 *   BUY  with a short position → first min(qty, |positionQty|) units cover;
 *   SELL with a long position  → first min(qty, positionQty) units close.
 * `reducingOnly` orders (pure close/cover) never require fresh margin —
 * otherwise a leveraged account (negative cash from the intraday-funding
 * analog) could never flatten itself and stop-loss cover legs would jam.
 */
export function requiredMarginForCents(
  product: OrderProduct,
  side: OrderSide,
  qty: number,
  positionQty: number,
  estPriceCents: number
): { requiredCents: number; reducingOnly: boolean } {
  if (product === "CNC") {
    return { requiredCents: marginForCents(product, side, qty, estPriceCents), reducingOnly: false };
  }
  const closingQty = Math.min(qty, Math.max(0, side === "BUY" ? -positionQty : positionQty));
  const excessQty = qty - closingQty;
  return {
    requiredCents: excessQty > 0 ? marginForCents(product, side, excessQty, estPriceCents) : 0,
    reducingOnly: excessQty === 0,
  };
}
