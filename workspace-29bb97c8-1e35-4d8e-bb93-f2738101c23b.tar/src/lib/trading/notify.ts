/**
 * MERIDIAN — order confirmations + user notifications over WS (the "order
 * confirmations" async arrow from the confirmed architecture). Fire-and-forget
 * POST to the market-data service /internal/emit → user room `user:{id}`.
 * REST responses remain the source of truth; WS push is best-effort.
 */
import { db } from "@/lib/db";
import { toNotificationDTO } from "@/lib/trading/dto";
import type { NotificationType } from "@/lib/types";

const BASE = process.env.MARKET_DATA_URL ?? "http://127.0.0.1:3003";

export async function emitToUser(userId: string, event: string, payload: unknown): Promise<void> {
  const secret = process.env.INTERNAL_EMIT_SECRET ?? process.env.AUTH_SECRET ?? "";
  try {
    await fetch(`${BASE}/internal/emit`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ secret, room: `user:${userId}`, event, payload }),
      signal: AbortSignal.timeout(1500),
    });
  } catch {
    // best-effort
  }
}

export interface NotifyInput {
  type: NotificationType;
  title: string;
  body: string;
  refType?: string;
  refId?: string;
}

/**
 * Phase 4 notifications (§8c): persist the Notification row, prune the user's
 * feed to the newest 100, then push the `notification` WS event. Never throws —
 * notification failures must not break trading flows.
 */
export async function notifyUser(userId: string, n: NotifyInput): Promise<void> {
  try {
    const row = await db.notification.create({
      data: {
        userId,
        type: n.type,
        title: n.title,
        body: n.body,
        refType: n.refType ?? null,
        refId: n.refId ?? null,
      },
    });
    // Prune to the newest 100 rows per user (deterministic on createdAt + id).
    const stale = await db.notification.findMany({
      where: { userId },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      skip: 100,
      select: { id: true },
    });
    if (stale.length > 0) {
      await db.notification.deleteMany({ where: { id: { in: stale.map((r) => r.id) } } });
    }
    await emitToUser(userId, "notification", { notification: toNotificationDTO(row) });
  } catch (e) {
    console.error("[notify] notification failed:", e);
  }
}
