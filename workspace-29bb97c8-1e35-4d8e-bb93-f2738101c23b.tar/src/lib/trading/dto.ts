import type { Notification, Order, PriceAlert } from "@prisma/client";
import type { NotificationDTO, OrderDTO, PriceAlertDTO } from "@/lib/types";

export function toOrderDTO(o: Order): OrderDTO {
  return {
    id: o.id,
    symbol: o.symbol,
    side: o.side as OrderDTO["side"],
    type: o.type as OrderDTO["type"],
    qty: o.qty,
    product: (o.product ?? "CNC") as OrderDTO["product"],
    strategy: (o.strategy ?? null) as OrderDTO["strategy"],
    legKind: (o.legKind ?? null) as OrderDTO["legKind"],
    parentOrderId: o.parentOrderId,
    targetCents: o.targetCents,
    limitPriceCents: o.limitPriceCents,
    stopPriceCents: o.stopPriceCents,
    timeInForce: o.timeInForce,
    status: o.status as OrderDTO["status"],
    filledQty: o.filledQty,
    avgFillPriceCents: o.avgFillPriceCents,
    rejectReason: o.rejectReason,
    brokerRef: o.brokerRef,
    expiresAt: o.expiresAt ? o.expiresAt.toISOString() : null,
    activateAt: o.activateAt ? o.activateAt.toISOString() : null,
    createdAt: o.createdAt.toISOString(),
    updatedAt: o.updatedAt.toISOString(),
  };
}

/** PriceAlert row (optionally joined with its Asset name) -> contract DTO. */
export function toAlertDTO(
  a: PriceAlert & { asset?: { name: string } | null }
): PriceAlertDTO {
  return {
    id: a.id,
    symbol: a.symbol,
    name: a.asset?.name,
    condition: a.condition as PriceAlertDTO["condition"],
    targetCents: a.targetCents,
    status: a.status as PriceAlertDTO["status"],
    createdAt: a.createdAt.toISOString(),
    triggeredAt: a.triggeredAt ? a.triggeredAt.toISOString() : null,
  };
}

/** Notification row -> contract DTO (§8c). */
export function toNotificationDTO(n: Notification): NotificationDTO {
  return {
    id: n.id,
    type: n.type as NotificationDTO["type"],
    title: n.title,
    body: n.body,
    refType: n.refType,
    refId: n.refId,
    readAt: n.readAt ? n.readAt.toISOString() : null,
    createdAt: n.createdAt.toISOString(),
  };
}
