/**
 * MERIDIAN — simulated exchange matcher (the M2–M4 "broker API").
 * Every 2 s cycle, against one live-feed snapshot:
 *   0. Kill switch — while ON (§8d) the entire cycle is skipped: resting
 *      orders stay resting, nothing fills, nothing is released or notified.
 *   1. AMO release — QUEUED orders whose activateAt has passed become NEW
 *      (MARKET AMOs fill immediately in the same cycle).
 *   2. GTT expiry — expired Good-Till-Triggered orders are canceled (EXPIRED).
 *   3. Resting LIMIT / STOP / STOP_LIMIT / GTT matching.
 *   4. Price alerts — ACTIVE alerts fire a WS `alert` event when crossed.
 * STOP_LIMIT activation survives restarts: an order whose trigger has already
 * been crossed is treated as active on the first evaluation.
 * Every fill runs the strategy-leg hooks (CO/BO arm legs, OCO closes siblings)
 * and writes a notification row (§8b/§8c) alongside the WS pushes.
 */
import type { Order, PriceAlert } from "@prisma/client";
import { statSync } from "node:fs";
import path from "node:path";
import { db } from "@/lib/db";
import { fetchLiveQuotes, type LiveQuote } from "@/lib/market/quotes-client";
import { executeFill, simFeeCents } from "@/lib/trading/engine";
import { requiredMarginForCents } from "@/lib/trading/margin";
import { marketFillPrice } from "@/lib/trading/risk";
import { emitToUser, notifyUser } from "@/lib/trading/notify";
import { getKillSwitchState } from "@/lib/trading/kill-switch";
import { afterFillHooks } from "@/lib/trading/legs";
import { toAlertDTO, toOrderDTO } from "@/lib/trading/dto";
import { auditSystem } from "@/lib/security/audit";
import type { OrderSide, OrderProduct } from "@/lib/types";

const MATCH_INTERVAL_MS = 2000;

const inr = (cents: number): string => `₹${(cents / 100).toFixed(2)}`;

/**
 * The interval handle lives on globalThis so hot reloads never spawn duplicate
 * matchers. Alongside the timer we keep the matcher source's mtime as a version
 * marker: when the module is re-evaluated after an edit (or regeneration), the
 * stale closure's timer is replaced with one bound to the current code —
 * otherwise the running process would keep executing the old cycle forever.
 */
const g = globalThis as typeof globalThis & {
  __meridianMatcher?: { timer: ReturnType<typeof setInterval>; versionMs: number };
};
const activatedStopLimits = new Set<string>();

function matcherVersionMs(): number {
  try {
    return statSync(path.join(process.cwd(), "src", "lib", "trading", "matcher.ts")).mtimeMs;
  } catch {
    return 0;
  }
}

export function ensureMatcher(): void {
  const versionMs = matcherVersionMs();
  const existing = g.__meridianMatcher;
  if (existing && existing.versionMs === versionMs) return;
  if (existing) clearInterval(existing.timer);
  const timer = setInterval(() => void matchCycle(), MATCH_INTERVAL_MS);
  if (typeof timer.unref === "function") timer.unref();
  g.__meridianMatcher = { timer, versionMs };
  console.log("[matcher] simulated exchange matcher started (2s cycle)");
}

type RestingOrder = {
  id: string;
  userId: string;
  symbol: string;
  side: string;
  type: string;
  qty: number;
  filledQty: number;
  limitPriceCents: number | null;
  stopPriceCents: number | null;
};

function fillPriceFor(order: RestingOrder, ltp: number): number | null {
  switch (order.type) {
    case "LIMIT": {
      const lp = order.limitPriceCents;
      if (!lp) return null;
      if (order.side === "BUY") return ltp <= lp ? Math.min(ltp, lp) : null;
      return ltp >= lp ? Math.max(ltp, lp) : null;
    }
    case "STOP": {
      const sp = order.stopPriceCents;
      if (!sp) return null;
      if (order.side === "BUY") return ltp >= sp ? ltp : null;
      return ltp <= sp ? ltp : null;
    }
    case "STOP_LIMIT": {
      const sp = order.stopPriceCents;
      const lp = order.limitPriceCents;
      if (!sp || !lp) return null;
      const triggered =
        activatedStopLimits.has(order.id) ||
        (order.side === "BUY" ? ltp >= sp : ltp <= sp);
      if (!triggered) return null;
      activatedStopLimits.add(order.id);
      if (order.side === "BUY") return ltp <= lp ? Math.min(ltp, lp) : null;
      return ltp >= lp ? Math.max(ltp, lp) : null;
    }
    case "GTT": {
      // Zerodha-style Good-Till-Triggered: BUY fires when the price dips to the
      // trigger, SELL fires when it rallies to it; the fill never crosses the
      // limit price (same min/max rule as a resting LIMIT).
      const trigger = order.stopPriceCents;
      const limit = order.limitPriceCents;
      if (!trigger || !limit) return null;
      if (order.side === "BUY") return ltp <= trigger ? Math.min(ltp, limit) : null;
      return ltp >= trigger ? Math.max(ltp, limit) : null;
    }
    default:
      return null;
  }
}

/**
 * Shared fill path for the matcher: cash re-check (funds may have moved since
 * placement) -> one transactional fill -> audit -> WS order-update + portfolio
 * nudge + notification row -> strategy-leg hooks. Rejects the order when cash
 * no longer covers the remaining margin (MIS reserves notional/leverage, CNC
 * the full notional).
 */
async function tryFillResting(order: Order, price: number): Promise<void> {
  const remaining = order.qty - order.filledQty;
  if (remaining <= 0) return;

  if (order.side === "BUY") {
    const wallet = await db.wallet.findUnique({ where: { userId: order.userId } });
    const product = (order.product ?? "CNC") as OrderProduct;
    // Exposure-aware margin re-check: a pure cover (short position ≥ remaining)
    // releases margin and always passes; new exposure must fit in cash (a
    // negative cash — intraday-funding analog — therefore only lets reducing
    // orders through).
    let cashShort = false;
    if (!wallet) {
      cashShort = true;
    } else {
      const pos = await db.position.findUnique({
        where: { userId_symbol: { userId: order.userId, symbol: order.symbol } },
      });
      const { requiredCents, reducingOnly } = requiredMarginForCents(
        product,
        "BUY",
        remaining,
        pos?.qty ?? 0,
        price
      );
      cashShort = !reducingOnly && wallet.cashAvailableCents < requiredCents;
    }
    if (cashShort) {
      const rejected = await db.order.update({
        where: { id: order.id },
        data: { status: "REJECTED", rejectReason: "INSUFFICIENT_FUNDS" },
      });
      await auditSystem("ORDER_REJECTED", { userId: order.userId, detail: `matcher:INSUFFICIENT_FUNDS:${order.id}` });
      await emitToUser(order.userId, "order-update", { order: toOrderDTO(rejected) });
      await notifyUser(order.userId, {
        type: "ORDER_REJECTED",
        title: "Order rejected",
        body: `${order.side} ${remaining} ${order.symbol} — not enough ${product === "MIS" ? "margin" : "buying power"} at execution time.`,
        refType: "ORDER",
        refId: order.id,
      });
      return;
    }
  }

  const fee = simFeeCents(price * remaining);
  const result = await db.$transaction((tx) => executeFill(tx, order, remaining, price, fee));
  await auditSystem("ORDER_FILLED", {
    userId: order.userId,
    detail: `${order.side} ${remaining} ${order.symbol} @ ₹${(price / 100).toFixed(2)} (matcher)`,
  });
  await emitToUser(order.userId, "order-update", { order: toOrderDTO(result.order) });
  await emitToUser(order.userId, "portfolio-nudge", { ts: Date.now() });
  await notifyUser(order.userId, {
    type: "ORDER_FILLED",
    title: "Order filled",
    body: `${order.side} ${remaining} ${order.symbol} @ ${inr(price)}.`,
    refType: "ORDER",
    refId: order.id,
  });
  // CO/BO: arm legs on a filled strategy entry; close OCO siblings on a filled
  // leg; notify on a filled EXIT leg. No-ops for plain orders.
  await afterFillHooks(result.order);
}

/**
 * AMO release: QUEUED orders whose activateAt has passed become NEW
 * (activateAt is kept for the audit trail / order history). Non-market AMOs
 * flow through the normal resting logic from the next evaluation onward.
 */
async function releaseAmoOrders(): Promise<void> {
  const queued = await db.order.findMany({
    where: { status: "QUEUED", activateAt: { lte: new Date() } },
  });
  for (const order of queued) {
    const released = await db.order.update({
      where: { id: order.id },
      data: { status: "NEW" },
    });
    await auditSystem("ORDER_PLACED", {
      userId: order.userId,
      detail: `released AMO ${released.type} ${released.side} ${released.qty} ${released.symbol}`,
    });
    await emitToUser(order.userId, "order-update", { order: toOrderDTO(released) });
    await notifyUser(order.userId, {
      type: "ORDER_PLACED",
      title: "AMO released",
      body: `${released.side} ${released.qty} ${released.symbol} released to the exchange.`,
      refType: "ORDER",
      refId: released.id,
    });
  }
}

/**
 * MARKET execution sweep: fills released MARKET AMOs immediately in the same
 * cycle they become NEW, and retries any MARKET order that was left resting
 * by a transient feed outage at placement. Feed down -> retried next cycle.
 */
async function fillMarketOrders(): Promise<void> {
  const marketOrders = await db.order.findMany({
    where: { status: { in: ["NEW", "PARTIALLY_FILLED"] }, type: "MARKET" },
  });
  if (marketOrders.length === 0) return;
  const quotes = await fetchLiveQuotes(Array.from(new Set(marketOrders.map((o) => o.symbol))));
  if (!quotes) return;
  for (const order of marketOrders) {
    const quote = quotes.get(order.symbol);
    if (!quote) continue;
    await tryFillResting(order, marketFillPrice(order.side as OrderSide, quote.lastPriceCents));
  }
}

/**
 * GTT expiry: open Good-Till-Triggered orders past their expiresAt are
 * canceled with rejectReason EXPIRED. Returns the ids that were canceled so
 * the same cycle does not try to match them afterwards.
 */
async function expireGttOrders(open: Order[]): Promise<Set<string>> {
  const expiredIds = new Set<string>();
  const now = new Date();
  for (const order of open) {
    if (order.type !== "GTT" || !order.expiresAt || order.expiresAt >= now) continue;
    const canceled = await db.order.update({
      where: { id: order.id },
      data: { status: "CANCELED", rejectReason: "EXPIRED" },
    });
    expiredIds.add(order.id);
    await auditSystem("ORDER_CANCELLED", {
      userId: order.userId,
      detail: `GTT expired: ${order.side} ${order.qty} ${order.symbol} (${order.id})`,
    });
    await emitToUser(order.userId, "order-update", { order: toOrderDTO(canceled) });
    await notifyUser(order.userId, {
      type: "ORDER_CANCELLED",
      title: "GTT expired",
      body: `${order.side} ${order.qty} ${order.symbol} expired unfilled and was cancelled.`,
      refType: "ORDER",
      refId: order.id,
    });
  }
  return expiredIds;
}

async function matchResting(open: Order[], quotes: Map<string, LiveQuote>): Promise<void> {
  for (const order of open) {
    const quote = quotes.get(order.symbol);
    if (!quote) continue;
    const remaining = order.qty - order.filledQty;
    if (remaining <= 0) continue;
    const price = fillPriceFor(order, quote.lastPriceCents);
    if (price == null) continue;
    await tryFillResting(order, price);
  }
}

/**
 * Price alerts: ABOVE fires when LTP >= target, BELOW when LTP <= target.
 * Triggered alerts are flipped to TRIGGERED once and pushed over WS (+ notification).
 */
async function evaluateAlerts(
  alerts: (PriceAlert & { asset: { name: string } })[],
  quotes: Map<string, LiveQuote>
): Promise<void> {
  for (const alert of alerts) {
    const quote = quotes.get(alert.symbol);
    if (!quote) continue;
    const ltp = quote.lastPriceCents;
    const fired =
      alert.condition === "ABOVE" ? ltp >= alert.targetCents : ltp <= alert.targetCents;
    if (!fired) continue;
    const triggered = await db.priceAlert.update({
      where: { id: alert.id },
      data: { status: "TRIGGERED", triggeredAt: new Date() },
      include: { asset: { select: { name: true } } },
    });
    await auditSystem("ALERT_TRIGGERED", {
      userId: alert.userId,
      detail: `${alert.condition} ${alert.symbol} target=${alert.targetCents} ltp=${ltp}`,
    });
    await emitToUser(alert.userId, "alert", { alert: toAlertDTO(triggered) });
    await notifyUser(alert.userId, {
      type: "ALERT_TRIGGERED",
      title: "Price alert triggered",
      body: `${alert.symbol} crossed ${alert.condition} ${inr(alert.targetCents)}.`,
      refType: "ALERT",
      refId: alert.id,
    });
  }
}

async function matchCycle(): Promise<void> {
  try {
    // §8d: one cached kill-switch read per cycle — while ON, skip every
    // fill/release/notify action; resting orders stay resting.
    const killSwitch = await getKillSwitchState();
    if (killSwitch.on) return;

    await releaseAmoOrders();

    const [open, activeAlerts] = await Promise.all([
      // type: { not: "MARKET" } picks up LIMIT / STOP / STOP_LIMIT / GTT
      // (MARKET orders are handled by fillMarketOrders below).
      db.order.findMany({
        where: { status: { in: ["NEW", "PARTIALLY_FILLED"] }, type: { not: "MARKET" } },
      }),
      db.priceAlert.findMany({
        where: { status: "ACTIVE" },
        include: { asset: { select: { name: true } } },
      }),
    ]);

    const expiredIds = await expireGttOrders(open);
    const resting = open.filter((o) => !expiredIds.has(o.id));

    // ONE feed call per cycle for order symbols + alert symbols.
    const symbols = new Set<string>();
    for (const o of resting) symbols.add(o.symbol);
    for (const a of activeAlerts) symbols.add(a.symbol);

    await fillMarketOrders();

    if (symbols.size === 0) return;
    const quotes = await fetchLiveQuotes(Array.from(symbols));
    if (!quotes) return; // feed down — orders stay resting, alerts stay active

    await matchResting(resting, quotes);
    await evaluateAlerts(activeAlerts, quotes);
  } catch (e) {
    console.error("[matcher] cycle error:", e);
  }
}
