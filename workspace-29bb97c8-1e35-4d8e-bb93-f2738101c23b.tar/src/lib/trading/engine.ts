/**
 * MERIDIAN — execution + ledger engine (simulated broker fills).
 * Every fill is ONE Prisma transaction: Order → Trade → LedgerEntry → Position
 * → Wallet cache. The ledger is append-only; balances are derived + cached.
 */
import type { Prisma, Order, Position } from "@prisma/client";

type Tx = Prisma.TransactionClient;

/** Discount-broker fee model: min(₹20, 0.03% of notional), floor ₹1. */
export function simFeeCents(notionalCents: number): number {
  return Math.max(100, Math.min(2000, Math.round(notionalCents * 0.0003)));
}

export interface FillResult {
  fillQty: number;
  fillPriceCents: number;
  feeCents: number;
  order: Order;
  position: Position;
}

export async function executeFill(
  tx: Tx,
  order: Order,
  fillQty: number,
  fillPriceCents: number,
  feeCents: number
): Promise<FillResult> {
  const wallet = await tx.wallet.findUnique({ where: { userId: order.userId } });
  if (!wallet) throw new Error("WALLET_MISSING");

  const notional = fillQty * fillPriceCents;
  const remaining = order.qty - order.filledQty;
  if (fillQty > remaining) throw new Error("OVERFILL");

  // 1) Order progress
  const filledQty = order.filledQty + fillQty;
  const avgFillPriceCents = Math.round(
    (order.avgFillPriceCents * order.filledQty + fillPriceCents * fillQty) / filledQty
  );
  const updatedOrder = await tx.order.update({
    where: { id: order.id },
    data: {
      filledQty,
      avgFillPriceCents,
      status: filledQty >= order.qty ? "FILLED" : "PARTIALLY_FILLED",
      brokerRef: order.brokerRef ?? `SIM-${Date.now().toString(36).toUpperCase()}`,
    },
  });

  // 2) Execution record
  await tx.trade.create({
    data: {
      orderId: order.id,
      userId: order.userId,
      symbol: order.symbol,
      side: order.side,
      qty: fillQty,
      priceCents: fillPriceCents,
      feeCents,
    },
  });

  // 3) Position — direction-aware (longs AND shorts; MIS/CO/BO may short).
  //    avgCostCents is always the average cost of the OPEN direction:
  //    weighted avg of long legs while long, of short legs while short.
  //    Crossing zero resets the average to the new entry price; realized PnL
  //    accrues ONLY on the units that actually close a position.
  const pos = await tx.position.findUnique({
    where: { userId_symbol: { userId: order.userId, symbol: order.symbol } },
  });
  const oldQty = pos?.qty ?? 0;
  const newQty = oldQty + (order.side === "BUY" ? fillQty : -fillQty);
  let realizedDelta = 0;
  let newAvg: number;

  if (order.side === "BUY") {
    if (oldQty < 0) {
      // Covering a short: realize (avgCost − price) on the closed units.
      const closedQty = Math.min(-oldQty, fillQty);
      realizedDelta = ((pos?.avgCostCents ?? 0) - fillPriceCents) * closedQty;
      // Excess beyond the short opens a fresh long at the fill price; a
      // partial cover keeps the short's average.
      newAvg = newQty > 0 ? fillPriceCents : (pos?.avgCostCents ?? 0);
    } else {
      // Opening / extending a long: weighted average cost.
      newAvg = Math.round(((pos?.avgCostCents ?? 0) * oldQty + notional) / newQty);
    }
  } else {
    if (oldQty > 0) {
      // Reducing a long: realize (price − avg) on the closed units only.
      const closedQty = Math.min(oldQty, fillQty);
      realizedDelta = (fillPriceCents - (pos?.avgCostCents ?? 0)) * closedQty;
      // An oversell beyond the long flips into a fresh short at the fill price.
      newAvg = newQty < 0 ? fillPriceCents : (pos?.avgCostCents ?? 0);
    } else {
      // Opening / extending a short: weighted average of the short legs.
      // Realized PnL is unchanged for a pure short extension.
      newAvg = Math.round(
        ((pos?.avgCostCents ?? 0) * Math.abs(oldQty) + notional) / (Math.abs(oldQty) + fillQty)
      );
    }
  }

  const position = pos
    ? await tx.position.update({
        where: { id: pos.id },
        data: {
          qty: newQty,
          avgCostCents: newAvg,
          realizedPnlCents: pos.realizedPnlCents + realizedDelta,
        },
      })
    : await tx.position.create({
        data: {
          userId: order.userId,
          symbol: order.symbol,
          qty: newQty,
          avgCostCents: newAvg,
          realizedPnlCents: realizedDelta,
        },
      });

  // 4) Append-only ledger + wallet cache (fee included in the cash move)
  const cashDelta = order.side === "BUY" ? notional + feeCents : notional - feeCents;
  const direction = order.side === "BUY" ? "DEBIT" : "CREDIT";
  const balanceAfter =
    direction === "CREDIT" ? wallet.cashAvailableCents + cashDelta : wallet.cashAvailableCents - cashDelta;
  await tx.ledgerEntry.create({
    data: {
      walletId: wallet.id,
      direction,
      category: "TRADE",
      amountCents: cashDelta,
      balanceAfterCents: balanceAfter,
      refType: "ORDER",
      refId: order.id,
      memo: `${order.side} ${fillQty} ${order.symbol} @ ₹${(fillPriceCents / 100).toFixed(2)}`,
    },
  });
  await tx.wallet.update({
    where: { id: wallet.id },
    data: { cashAvailableCents: balanceAfter },
  });

  return { fillQty, fillPriceCents, feeCents, order: updatedOrder, position };
}
