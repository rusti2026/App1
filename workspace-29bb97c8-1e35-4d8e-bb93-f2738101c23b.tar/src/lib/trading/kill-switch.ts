/**
 * MERIDIAN — runtime kill switch (Phase 4 risk console, ARCHITECTURE.md §8d).
 *
 * Two sources, in precedence order:
 *   1. env TRADING_KILL_SWITCH=1 — boot-time ops override, always wins;
 *   2. SystemFlag row key "TRADING_KILL_SWITCH" ("1"/"0") — runtime toggle
 *      from /api/admin/risk.
 *
 * Reads go through a 5 s module-level cache (globalThis so hot reloads share
 * it): the matcher calls this once per 2 s cycle and the orders route on every
 * placement, so we avoid hammering SQLite for a value that changes rarely.
 */
import { db } from "@/lib/db";

export interface KillSwitchState {
  on: boolean;
  source: "flag" | "env" | "off";
}

const CACHE_TTL_MS = 5_000;
const FLAG_KEY = "TRADING_KILL_SWITCH";

const g = globalThis as typeof globalThis & {
  __meridianKillSwitch?: { state: KillSwitchState; at: number };
};

export async function getKillSwitchState(): Promise<KillSwitchState> {
  const cached = g.__meridianKillSwitch;
  if (cached && Date.now() - cached.at < CACHE_TTL_MS) return cached.state;

  let state: KillSwitchState = { on: false, source: "off" };
  if (process.env.TRADING_KILL_SWITCH === "1") {
    state = { on: true, source: "env" };
  } else {
    try {
      const flag = await db.systemFlag.findUnique({ where: { key: FLAG_KEY } });
      if (flag?.value === "1") state = { on: true, source: "flag" };
    } catch {
      // DB unavailable → default to OFF; the next read retries.
    }
  }

  g.__meridianKillSwitch = { state, at: Date.now() };
  return state;
}

/**
 * Runtime toggle: upserts the SystemFlag and invalidates the read cache. The
 * env override (if set) keeps winning on subsequent reads — the flag row is
 * still written so the console shows the requested state.
 */
export async function setKillSwitch(on: boolean): Promise<void> {
  const value = on ? "1" : "0";
  await db.systemFlag.upsert({
    where: { key: FLAG_KEY },
    update: { value },
    create: { key: FLAG_KEY, value },
  });
  delete g.__meridianKillSwitch;
}
