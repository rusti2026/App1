import { createRequire } from "node:module";
import path from "node:path";
import { statSync } from "node:fs";

/**
 * Prisma regenerates the client (node_modules/.prisma/client) on `prisma
 * generate` / `prisma db push`. A long-running dev server keeps the previously
 * loaded copy pinned in Node's require cache (Next externalizes node_modules
 * packages), so freshly generated models would stay invisible until a process
 * restart. To make the dev loop pick up a regenerated client automatically:
 *   1. the generated client file's mtime is used as the cache version —
 *      whenever it changes, the require cache for the client chain is purged
 *      and a NEW PrismaClient is built from the freshly generated code;
 *   2. between generations the instance is cached on globalThis (standard
 *      Next.js pattern — avoids exhausting SQLite connections on HMR).
 * Types always come from the regular package declaration.
 */
const GENERATED_CLIENT = path.join(process.cwd(), "node_modules", ".prisma", "client", "index.js");
const nodeRequire = createRequire(GENERATED_CLIENT);

type PrismaClientCtor = typeof import("@prisma/client")["PrismaClient"];
type ClientCache = { client: InstanceType<PrismaClientCtor>; mtimeMs: number };

const globalForPrisma = globalThis as unknown as { __meridianPrismaClient?: ClientCache };

function generatedClientMtimeMs(): number {
  try {
    return statSync(GENERATED_CLIENT).mtimeMs;
  } catch {
    return 0;
  }
}

/** Drops cached copies of the generated client chain so require re-evaluates disk. */
function purgeGeneratedClientCache(): void {
  const roots = [
    path.join(process.cwd(), "node_modules", "@prisma", "client"),
    path.join(process.cwd(), "node_modules", ".prisma", "client"),
  ];
  for (const root of roots) {
    for (const key of Object.keys(nodeRequire.cache)) {
      if (key.startsWith(root + path.sep)) delete nodeRequire.cache[key];
    }
  }
}

function getDb(): InstanceType<PrismaClientCtor> {
  const mtimeMs = generatedClientMtimeMs();
  const cached = globalForPrisma.__meridianPrismaClient;
  if (cached && cached.mtimeMs === mtimeMs) return cached.client;

  purgeGeneratedClientCache();
  const { PrismaClient } = nodeRequire("@prisma/client") as typeof import("@prisma/client");
  const client = new PrismaClient({ log: ["query"] });
  globalForPrisma.__meridianPrismaClient = { client, mtimeMs };
  console.log("[db] PrismaClient (re)loaded from the generated client, mtime:", mtimeMs);
  return client;
}

export const db = getDb();
