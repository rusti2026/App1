/**
 * MERIDIAN — server-side read of the market-data hot cache (mini-service :3003).
 * Sandbox analog of reading the Redis hot cache. Returns null when the feed is
 * down so callers degrade gracefully (risk engine rejects with FEED_UNAVAILABLE).
 */
const BASE = process.env.MARKET_DATA_URL ?? "http://127.0.0.1:3003";

export interface LiveQuote {
  symbol: string;
  name: string;
  type: string;
  exchange: string;
  lastPriceCents: number;
  prevCloseCents: number;
  openCents: number;
  highCents: number;
  lowCents: number;
  changeCents: number;
  changePct: number;
  volume: number;
  ts: number;
}

export async function fetchLiveQuotes(symbols?: string[]): Promise<Map<string, LiveQuote> | null> {
  try {
    const qs = symbols?.length ? `?symbols=${encodeURIComponent(symbols.join(","))}` : "";
    const res = await fetch(`${BASE}/quotes${qs}`, {
      signal: AbortSignal.timeout(1500),
      cache: "no-store",
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { quotes: LiveQuote[] };
    return new Map(data.quotes.map((q) => [q.symbol, q]));
  } catch {
    return null;
  }
}

export async function fetchLiveQuote(symbol: string): Promise<LiveQuote | null> {
  const quotes = await fetchLiveQuotes([symbol]);
  return quotes?.get(symbol) ?? null;
}
