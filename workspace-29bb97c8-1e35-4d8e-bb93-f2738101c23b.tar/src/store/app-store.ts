"use client";

import { create } from "zustand";

/** SPA views — the single route `/` renders one of these (see page.tsx). */
export type View = "landing" | "auth" | "onboarding" | "dashboard";

export type AuthMode = "login" | "signup";

/**
 * Auth sub-state-machine:
 * - credentials: login/signup form
 * - mfa: TOTP challenge after `{ status: "mfa_required", tempToken }`
 * - otp: one-time-code flow (request → verify handled inside <OtpFlow/>)
 */
export type AuthStep = "credentials" | "mfa" | "otp";

interface AppState {
  view: View;
  authMode: AuthMode;
  authStep: AuthStep;
  /** Temporary token for the MFA login challenge (10 min TTL, server-side). */
  tempToken: string | null;
  setView: (view: View) => void;
  openAuth: (mode: AuthMode) => void;
  setAuthMode: (mode: AuthMode) => void;
  setAuthStep: (step: AuthStep) => void;
  setTempToken: (token: string | null) => void;
  resetToLanding: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  view: "landing",
  authMode: "login",
  authStep: "credentials",
  tempToken: null,
  setView: (view) => set({ view }),
  openAuth: (mode) =>
    set({ view: "auth", authMode: mode, authStep: "credentials", tempToken: null }),
  setAuthMode: (authMode) => set({ authMode, authStep: "credentials" }),
  setAuthStep: (authStep) => set({ authStep }),
  setTempToken: (tempToken) => set({ tempToken }),
  resetToLanding: () =>
    set({
      view: "landing",
      authMode: "login",
      authStep: "credentials",
      tempToken: null,
    }),
}));
