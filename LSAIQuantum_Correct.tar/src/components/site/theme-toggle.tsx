"use client";

import { useSyncExternalStore } from "react";
import { useTheme } from "next-themes";
import { Moon, Sun } from "lucide-react";
import { cn } from "@/lib/utils";

const emptySubscribe = () => () => {};

/**
 * Pill-style on/off switch that toggles the whole site between the light
 * (white) and dark (black) themes. Persists the choice via next-themes.
 */
export function ThemeToggle({ className }: { className?: string }) {
  const { resolvedTheme, setTheme } = useTheme();

  // Hydration-safe "mounted" flag: false during SSR/first paint, true after.
  const mounted = useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false,
  );

  const isDark = mounted && resolvedTheme === "dark";

  return (
    <button
      type="button"
      role="switch"
      aria-checked={isDark}
      aria-label={isDark ? "Switch to light theme" : "Switch to dark theme"}
      title={isDark ? "Light theme" : "Dark theme"}
      onClick={() => setTheme(isDark ? "light" : "dark")}
      className={cn(
        "relative inline-flex h-7 w-14 flex-none items-center rounded-full border transition-colors duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
        isDark
          ? "border-primary/50 bg-primary/25"
          : "border-border bg-secondary",
        className,
      )}
    >
      {/* Track icons: sun on the light side, moon on the dark side */}
      <Sun
        className={cn(
          "absolute left-1.5 h-3.5 w-3.5 transition-all duration-300",
          isDark ? "text-muted-foreground" : "text-gold scale-0 opacity-0",
        )}
      />
      <Moon
        className={cn(
          "absolute right-1.5 h-3.5 w-3.5 transition-all duration-300",
          isDark ? "text-primary scale-0 opacity-0" : "text-muted-foreground",
        )}
      />

      {/* Sliding knob */}
      <span
        className={cn(
          "relative z-10 flex h-6 w-6 items-center justify-center rounded-full border shadow-md transition-transform duration-300 ease-out",
          isDark
            ? "translate-x-7 border-primary/60 bg-card"
            : "translate-x-0 border-border bg-card",
        )}
      >
        {mounted ? (
          isDark ? (
            <Moon className="h-3.5 w-3.5 text-primary" />
          ) : (
            <Sun className="h-3.5 w-3.5 text-gold-foreground" />
          )
        ) : (
          <Sun className="h-3.5 w-3.5 text-muted-foreground" />
        )}
      </span>
    </button>
  );
}
