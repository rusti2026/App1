'use client'

import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useAppStore } from '@/store/app-store'

export function HeroBanner() {
  const setSelectedCategory = useAppStore((s) => s.setSelectedCategory)
  const navigateTo = useAppStore((s) => s.navigateTo)

  const handleExplore = () => {
    setSelectedCategory('')
    navigateTo('home')
    setTimeout(() => {
      document.getElementById('properties-section')?.scrollIntoView({ behavior: 'smooth' })
    }, 100)
  }

  return (
    <section className='relative overflow-hidden bg-gradient-to-br from-emerald-50 via-white to-teal-50 dark:from-emerald-950/20 dark:via-background dark:to-teal-950/20'>
      <div className='container mx-auto px-4 py-8 md:py-16'>
        <div className='grid md:grid-cols-2 gap-8 items-center'>
          <div className='space-y-6'>
            <div className='inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800'>
              Verified properties • No brokerage
            </div>
            <h1 className='text-3xl md:text-5xl lg:text-6xl font-bold tracking-tight leading-tight'>
              Find Your Perfect
              <span className='block bg-gradient-to-r from-emerald-500 to-teal-600 bg-clip-text text-transparent'>
                Rental Space
              </span>
            </h1>
            <p className='text-lg text-muted-foreground max-w-md'>
              Houses, commercial shops, plots & shed factories — all verified and available for rent across India.
            </p>
            <div className='flex flex-wrap gap-3'>
              <Button size='lg' onClick={handleExplore} className='bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-lg'>
                Explore Properties
                <ArrowRight className='ml-2 h-4 w-4' />
              </Button>
              <Button size='lg' variant='outline' onClick={() => { setSelectedCategory('houses'); navigateTo('home') }}>
                Browse Houses
              </Button>
            </div>
          </div>
          <div className='relative hidden md:block'>
            <div className='relative rounded-2xl overflow-hidden shadow-2xl'>
              <img src='/images/banners/hero.png' alt='Featured properties' className='w-full h-auto object-cover' />
              <div className='absolute inset-0 bg-gradient-to-t from-black/20 to-transparent' />
            </div>
            <div className='absolute -bottom-4 -left-4 bg-background rounded-xl shadow-lg border p-3 flex items-center gap-2 animate-bounce' style={{ animationDuration: '3s' }}>
              <div className='h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 text-lg'>✓</div>
              <div>
                <p className='text-sm font-semibold'>20+ Properties</p>
                <p className='text-xs text-muted-foreground'>Verified & ready to rent</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
