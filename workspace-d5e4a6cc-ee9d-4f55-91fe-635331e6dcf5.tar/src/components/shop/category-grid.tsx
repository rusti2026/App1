'use client'

import { Card, CardContent } from '@/components/ui/card'
import { useAppStore } from '@/store/app-store'

interface Category {
  id: string
  name: string
  slug: string
  description: string
  image: string | null
  propertyCount: number
}

export function CategoryGrid({ categories }: { categories: Category[] }) {
  const { setSelectedCategory, navigateTo } = useAppStore()

  const handleClick = (slug: string) => {
    setSelectedCategory(slug)
    navigateTo('home')
    setTimeout(() => {
      document.getElementById('properties-section')?.scrollIntoView({ behavior: 'smooth' })
    }, 100)
  }

  return (
    <section className='container mx-auto px-4 py-10'>
      <div className='mb-6'>
        <h2 className='text-2xl font-bold tracking-tight'>Browse by Property Type</h2>
        <p className='text-muted-foreground text-sm mt-1'>Find the right space for your needs</p>
      </div>
      <div className='grid grid-cols-2 md:grid-cols-4 gap-4'>
        {categories.map((cat) => (
          <Card key={cat.id} className='group cursor-pointer hover:shadow-lg transition-all duration-300 overflow-hidden border-0 shadow-sm hover:-translate-y-1' onClick={() => handleClick(cat.slug)}>
            <CardContent className='p-0'>
              <div className='relative aspect-[4/3] overflow-hidden'>
                {cat.image ? (
                  <img src={cat.image} alt={cat.name} className='w-full h-full object-cover group-hover:scale-105 transition-transform duration-500' />
                ) : (
                  <div className='w-full h-full bg-gradient-to-br from-gray-200 to-gray-300' />
                )}
                <div className='absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent' />
                <div className='absolute bottom-0 left-0 right-0 p-3'>
                  <h3 className='text-white font-semibold text-sm leading-tight'>{cat.name}</h3>
                  <p className='text-white/70 text-xs mt-0.5'>{cat.propertyCount} listings</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}
