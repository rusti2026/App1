'use client'

import { useState, useEffect, useRef } from 'react'
import { Search, Heart, User, Menu, X, Package, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { useShortlistStore } from '@/store/shortlist-store'
import { useAppStore } from '@/store/app-store'

export function Header() {
  const [searchOpen, setSearchOpen] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const searchRef = useRef<HTMLInputElement>(null)
  const itemCount = useShortlistStore((s) => s.getItemCount())
  const toggleShortlist = useShortlistStore((s) => s.toggleShortlist)
  const { view, navigateTo, setSearchQuery } = useAppStore()

  useEffect(() => {
    if (searchOpen && searchRef.current) searchRef.current.focus()
  }, [searchOpen])

  const handleSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const query = formData.get('search') as string
    if (query.trim()) {
      setSearchQuery(query.trim())
      navigateTo('search-results')
      setSearchOpen(false)
    }
  }

  const showBack = view === 'property-detail' || view === 'apply' || view === 'booking-confirmation'

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-3">
          {showBack && (
            <Button variant="ghost" size="icon" onClick={() => useAppStore.getState().goBack()} className="shrink-0">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <button
            onClick={() => navigateTo('home')}
            className="flex items-center gap-2 font-bold text-xl tracking-tight hover:opacity-80 transition-opacity"
          >
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
              <span className="text-white font-bold text-sm">Z</span>
            </div>
            <span className="hidden sm:inline">
              Z <span className="font-normal text-muted-foreground">Space</span>
            </span>
          </button>
        </div>

        <div className="hidden md:flex flex-1 max-w-xl mx-8">
          <form onSubmit={handleSearch} className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input ref={searchRef} name="search" placeholder="Search properties, locations, cities..." className="pl-10 pr-4 h-10 bg-muted/50" />
          </form>
        </div>

        <div className="flex items-center gap-1 sm:gap-2">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setSearchOpen(!searchOpen)}>
            {searchOpen ? <X className="h-5 w-5" /> : <Search className="h-5 w-5" />}
          </Button>
          <Button variant="ghost" size="icon" onClick={() => navigateTo('my-bookings')} className="hidden sm:flex">
            <Package className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" onClick={toggleShortlist} className="relative">
            <Heart className="h-5 w-5" />
            {itemCount > 0 && (
              <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-[10px] font-bold bg-emerald-500 text-white border-0">
                {itemCount > 99 ? '99+' : itemCount}
              </Badge>
            )}
          </Button>
          <Button variant="ghost" size="icon" className="sm:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {searchOpen && (
        <div className="md:hidden border-t px-4 py-2">
          <form onSubmit={handleSearch} className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input ref={searchRef} name="search" placeholder="Search properties..." className="pl-10 pr-4 h-10" />
          </form>
        </div>
      )}

      {mobileMenuOpen && (
        <div className="sm:hidden border-t bg-background">
          <div className="px-4 py-3 space-y-1">
            <Button variant="ghost" className="w-full justify-start gap-3" onClick={() => { navigateTo('my-bookings'); setMobileMenuOpen(false) }}>
              <Package className="h-4 w-4" /> My Bookings
            </Button>
          </div>
        </div>
      )}
    </header>
  )
}
