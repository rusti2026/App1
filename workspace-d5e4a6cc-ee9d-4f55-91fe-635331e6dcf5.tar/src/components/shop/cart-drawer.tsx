'use client'

import { X, Trash2, Heart, MapPin, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { PropertyImage } from './product-image'
import { useShortlistStore } from '@/store/shortlist-store'
import { useAppStore } from '@/store/app-store'

export function ShortlistDrawer() {
  const { shortlist, isOpen, closeShortlist, isLoading, removeItem } = useShortlistStore()
  const navigateTo = useAppStore((s) => s.navigateTo)
  const isEmpty = !shortlist || shortlist.items.length === 0

  return (
    <Sheet open={isOpen} onOpenChange={(open) => !open && closeShortlist()}>
      <SheetContent className='w-full sm:max-w-md flex flex-col p-0'>
        <SheetHeader className='px-6 py-4 border-b shrink-0'>
          <SheetTitle className='flex items-center gap-2'>
            <Heart className='h-5 w-5' />
            Shortlisted Properties
            {!isEmpty && <span className='text-sm font-normal text-muted-foreground'>({shortlist!.items.length})</span>}
          </SheetTitle>
        </SheetHeader>
        {isEmpty ? (
          <div className='flex-1 flex flex-col items-center justify-center gap-4 px-6'>
            <div className='h-20 w-20 rounded-full bg-muted flex items-center justify-center'><Heart className='h-10 w-10 text-muted-foreground' /></div>
            <div className='text-center'>
              <p className='font-medium'>No properties shortlisted</p>
              <p className='text-sm text-muted-foreground mt-1'>Browse and save properties you like</p>
            </div>
            <Button variant='outline' onClick={() => { closeShortlist(); navigateTo('home') }}>Browse Properties</Button>
          </div>
        ) : (
          <>
            <ScrollArea className='flex-1'>
              <div className='px-6 py-4 space-y-4'>
                {shortlist!.items.map((item) => (
                  <div key={item.id} className='flex gap-4'>
                    <PropertyImage image={item.property.image} images={item.property.images} name={item.property.name} size='sm' className='shrink-0 rounded-lg' />
                    <div className='flex-1 min-w-0'>
                      <h4 className='text-sm font-medium leading-tight line-clamp-2'>{item.property.name}</h4>
                      <p className='text-xs text-muted-foreground mt-0.5 flex items-center gap-1'><MapPin className='h-3 w-3' />{item.property.location}, {item.property.city}</p>
                      <p className='text-sm font-bold mt-1'>₹{item.property.rentPrice.toLocaleString('en-IN')}/mo</p>
                      <div className='flex justify-end mt-1'>
                        <Button variant='ghost' size='icon' className='h-7 w-7 text-muted-foreground hover:text-destructive' onClick={() => removeItem(item.propertyId)} disabled={isLoading}>
                          <Trash2 className='h-3.5 w-3.5' />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
            <div className='border-t px-6 py-4 space-y-3 shrink-0'>
              <div className='flex justify-between text-sm'><span className='text-muted-foreground'>Total Rent</span><span>₹{shortlist!.totalRent.toLocaleString('en-IN')}/mo</span></div>
              <div className='flex justify-between text-sm'><span className='text-muted-foreground'>Total Deposit</span><span>₹{shortlist!.totalDeposit.toLocaleString('en-IN')}</span></div>
              <div className='flex justify-between text-sm'><span className='text-muted-foreground'>Service Fee</span><span>₹{shortlist!.serviceFee.toLocaleString('en-IN')}</span></div>
              <Separator />
              <Button className='w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white' size='lg' onClick={() => { closeShortlist(); navigateTo('apply') }}>
                Apply for Booking <ArrowRight className='ml-2 h-4 w-4' />
              </Button>
              <Button variant='ghost' className='w-full' onClick={() => { closeShortlist(); navigateTo('home') }}>Continue Browsing</Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  )
}
