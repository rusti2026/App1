'use client'

import { useState, useEffect, useCallback } from 'react'
import { SlidersHorizontal } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { PropertyCard } from './product-card'
import { useAppStore } from '@/store/app-store'

interface Property {
  id: string; name: string; slug: string; description: string; rentPrice: number; deposit: number | null
  area: string | null; location: string; city: string; bedrooms: number | null; bathrooms: number | null
  furnishing: string | null; availableFrom: string | null; minLease: string | null
  image: string | null; images: string | null; rating: number; reviewCount: number; featured: boolean
  amenities: string | null; category: { id: string; name: string; slug: string }
}

interface Category { id: string; name: string; slug: string; propertyCount: number }

export function PropertyGrid({ categories, featuredOnly }: { categories: Category[]; featuredOnly?: boolean }) {
  const [properties, setProperties] = useState<Property[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(true)
  const [sort, setSort] = useState('rating')
  const selectedCategory = useAppStore((s) => s.selectedCategory)
  const setSelectedCategory = useAppStore((s) => s.setSelectedCategory)
  const searchQuery = useAppStore((s) => s.searchQuery)
  const view = useAppStore((s) => s.view)
  const limit = 12
  const totalPages = Math.ceil(total / limit)

  const fetchProperties = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      params.set('page', page.toString())
      params.set('limit', limit.toString())
      params.set('sort', sort)
      if (featuredOnly) params.set('featured', 'true')
      if (selectedCategory) params.set('category', selectedCategory)
      if (searchQuery && view === 'search-results') params.set('search', searchQuery)
      const res = await fetch('/api/properties?' + params.toString())
      if (res.ok) { const data = await res.json(); setProperties(data.properties); setTotal(data.total) }
    } catch (error) { console.error('Failed:', error) } finally { setLoading(false) }
  }, [page, sort, selectedCategory, searchQuery, view, featuredOnly])

  useEffect(() => { setPage(1) }, [selectedCategory, searchQuery, sort])
  useEffect(() => { fetchProperties() }, [fetchProperties])
  useEffect(() => { if (view === 'search-results') setPage(1) }, [view])

  const title = view === 'search-results' ? `Results for "${searchQuery}"` : featuredOnly ? 'Featured Properties' : selectedCategory ? categories.find((c) => c.slug === selectedCategory)?.name || 'Properties' : 'All Properties'
  const subtitle = view === 'search-results' ? `${total} result${total !== 1 ? 's' : ''} found` : featuredOnly ? 'Hand-picked listings for you' : `${total} propert${total !== 1 ? 'ies' : 'y'} available`

  return (
    <section className='container mx-auto px-4 py-10'>
      <div className='flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6'>
        <div>
          <h2 className='text-2xl font-bold tracking-tight'>{title}</h2>
          <p className='text-muted-foreground text-sm mt-1'>{subtitle}</p>
        </div>
        <div className='flex items-center gap-3'>
          {!featuredOnly && (
            <Select value={selectedCategory || 'all'} onValueChange={(v) => setSelectedCategory(v === 'all' ? '' : v)}>
              <SelectTrigger className='w-[170px]'><SelectValue placeholder='All Types' /></SelectTrigger>
              <SelectContent>
                <SelectItem value='all'>All Types</SelectItem>
                {categories.map((cat) => <SelectItem key={cat.id} value={cat.slug}>{cat.name}</SelectItem>)}
              </SelectContent>
            </Select>
          )}
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className='w-[160px]'><SlidersHorizontal className='h-4 w-4 mr-2' /><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value='rating'>Top Rated</SelectItem>
              <SelectItem value='price-asc'>Rent: Low to High</SelectItem>
              <SelectItem value='price-desc'>Rent: High to Low</SelectItem>
              <SelectItem value='newest'>Newest</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {loading ? (
        <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4'>
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className='space-y-3'><Skeleton className='w-full h-64 rounded-lg' /><Skeleton className='h-4 w-20' /><Skeleton className='h-4 w-full' /><Skeleton className='h-4 w-24' /><Skeleton className='h-5 w-16' /></div>
          ))}
        </div>
      ) : properties.length === 0 ? (
        <div className='text-center py-16'><p className='text-muted-foreground text-lg'>No properties found</p><p className='text-muted-foreground text-sm mt-1'>Try adjusting your search or filters</p></div>
      ) : (
        <>
          <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4'>
            {properties.map((p) => <PropertyCard key={p.id} property={p} />)}
          </div>
          {totalPages > 1 && (
            <div className='flex justify-center mt-10'>
              <div className='flex items-center gap-2'>
                <Button variant='outline' size='sm' onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}>Previous</Button>
                {Array.from({ length: totalPages }, (_, i) => i + 1).filter((p) => p === 1 || p === totalPages || Math.abs(p - page) <= 1).map((p, idx, arr) => {
                  const showEllipsis = idx > 0 && p - arr[idx - 1] > 1
                  return (
                    <span key={p} className='flex items-center gap-2'>
                      {showEllipsis && <span className='text-muted-foreground px-1'>...</span>}
                      <Button variant={p === page ? 'default' : 'outline'} size='sm' onClick={() => setPage(p)} className='w-9'>{p}</Button>
                    </span>
                  )
                })}
                <Button variant='outline' size='sm' onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages}>Next</Button>
              </div>
            </div>
          )}
        </>
      )}
    </section>
  )
}
