'use client'

import { useMemo } from 'react'
import {
  Home, Building, Store, MapPin, Factory, Warehouse, Truck, Snowflake, Briefcase,
  type LucideIcon,
} from 'lucide-react'

const iconMap: Record<string, LucideIcon> = {
  home: Home,
  building: Building,
  store: Store,
  'map-pin': MapPin,
  factory: Factory,
  warehouse: Warehouse,
  truck: Truck,
  snowflake: Snowflake,
  briefcase: Briefcase,
}

interface PropertyImageProps {
  image?: string | null
  images?: string | null
  name?: string
  className?: string
  size?: 'sm' | 'md' | 'lg' | 'xl'
}

const sizeClasses = {
  sm: 'w-16 h-16',
  md: 'w-full h-48',
  lg: 'w-full h-64',
  xl: 'w-full h-80',
}

const iconSizeClasses = {
  sm: 'w-7 h-7',
  md: 'w-12 h-12',
  lg: 'w-16 h-16',
  xl: 'w-20 h-20',
}

export function PropertyImage({ image, images, name, className = '', size = 'md' }: PropertyImageProps) {
  const { gradient, icon } = useMemo(() => {
    if (images) {
      try {
        const parsed = JSON.parse(images)
        return { gradient: parsed.gradient || 'from-gray-400 to-gray-600', icon: parsed.icon || '' }
      } catch { /* ignore */ }
    }
    if (image) {
      return { gradient: image, icon: '' }
    }
    return { gradient: 'from-gray-400 to-gray-600', icon: '' }
  }, [image, images])

  const IconComponent = icon ? iconMap[icon] : Home

  return (
    <div
      className={`relative bg-gradient-to-br ${gradient} flex items-center justify-center rounded-lg overflow-hidden ${sizeClasses[size]} ${className}`}
    >
      <IconComponent className={`${iconSizeClasses[size]} text-white/80`} strokeWidth={1.5} />
    </div>
  )
}
