'use client'

import { useState } from 'react'
import { CreditCard, Lock, Loader2, FileText, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Separator } from '@/components/ui/separator'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { PropertyImage } from './product-image'
import { useShortlistStore } from '@/store/shortlist-store'
import { useAppStore } from '@/store/app-store'
import { toast } from 'sonner'

interface Form {
  email: string; firstName: string; lastName: string; phone: string; address: string; city: string; state: string; zipCode: string; country: string; idType: string; idNumber: string; paymentMethod: string
}
const initForm: Form = { email: '', firstName: '', lastName: '', phone: '', address: '', city: '', state: '', zipCode: '', country: 'IN', idType: 'aadhaar', idNumber: '', paymentMethod: 'upi' }

export function BookingForm() {
  const { shortlist, isLoading } = useShortlistStore()
  const [form, setForm] = useState<Form>(initForm)
  const [errors, setErrors] = useState<Partial<Form>>({})
  const [submitting, setSubmitting] = useState(false)
  const [leaseDuration, setLeaseDuration] = useState('12')

  const updateField = (f: keyof Form, v: string) => { setForm((p) => ({ ...p, [f]: v })); if (errors[f]) setErrors((p) => ({ ...p, [f]: undefined })) }

  const validate = () => {
    const e: Partial<Form> = {}
    if (!form.email.includes('@')) e.email = 'Valid email required'
    if (!form.firstName.trim()) e.firstName = 'Required'
    if (!form.lastName.trim()) e.lastName = 'Required'
    if (!form.phone.trim()) e.phone = 'Required'
    if (!form.idNumber.trim()) e.idNumber = 'Required'
    setErrors(e); return Object.keys(e).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validate() || !shortlist) return
    setSubmitting(true)
    try {
      const sessionId = localStorage.getItem('zspace-session-id') || ''
      const res = await fetch('/api/bookings?sessionId=' + encodeURIComponent(sessionId), {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, items: shortlist.items.map(i => ({ propertyId: i.propertyId, leaseDuration })) }),
      })
      if (res.ok) {
        const booking = await res.json()
        useShortlistStore.getState().clearShortlist()
        useAppStore.getState().showBookingConfirmation(booking.id, booking.bookingNumber)
        toast.success('Booking application submitted!')
      } else {
        const d = await res.json(); toast.error(d.error || 'Failed to submit')
      }
    } catch { toast.error('Something went wrong') } finally { setSubmitting(false) }
  }

  if (!shortlist || shortlist.items.length === 0) {
    return <div className='container mx-auto px-4 py-16 text-center'><FileText className='h-16 w-16 mx-auto text-muted-foreground mb-4' /><h2 className='text-xl font-bold mb-2'>No properties shortlisted</h2><p className='text-muted-foreground mb-6'>Shortlist some properties before applying</p><Button onClick={() => useAppStore.getState().navigateTo('home')}>Browse Properties</Button></div>
  }

  return (
    <div className='container mx-auto px-4 py-6 md:py-8'>
      <h1 className='text-2xl font-bold mb-6'>Apply for Booking</h1>
      <form onSubmit={handleSubmit}>
        <div className='grid lg:grid-cols-3 gap-8'>
          <div className='lg:col-span-2 space-y-6'>
            <Card>
              <CardHeader className='pb-4'><CardTitle className='text-lg flex items-center gap-2'><span className='h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-bold'>1</span>Personal Information</CardTitle></CardHeader>
              <CardContent className='space-y-4'>
                <div className='grid sm:grid-cols-2 gap-4'>
                  <div className='space-y-2'><Label>First Name *</Label><Input value={form.firstName} onChange={(e) => updateField('firstName', e.target.value)} placeholder='Rajesh' />{errors.firstName && <p className='text-xs text-destructive'>{errors.firstName}</p>}</div>
                  <div className='space-y-2'><Label>Last Name *</Label><Input value={form.lastName} onChange={(e) => updateField('lastName', e.target.value)} placeholder='Kumar' />{errors.lastName && <p className='text-xs text-destructive'>{errors.lastName}</p>}</div>
                </div>
                <div className='grid sm:grid-cols-2 gap-4'>
                  <div className='space-y-2'><Label>Email *</Label><Input type='email' value={form.email} onChange={(e) => updateField('email', e.target.value)} placeholder='rajesh@example.com' />{errors.email && <p className='text-xs text-destructive'>{errors.email}</p>}</div>
                  <div className='space-y-2'><Label>Phone *</Label><Input type='tel' value={form.phone} onChange={(e) => updateField('phone', e.target.value)} placeholder='+91 98765 43210' />{errors.phone && <p className='text-xs text-destructive'>{errors.phone}</p>}</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className='pb-4'><CardTitle className='text-lg flex items-center gap-2'><span className='h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-bold'>2</span>ID Verification</CardTitle></CardHeader>
              <CardContent className='space-y-4'>
                <div className='grid sm:grid-cols-2 gap-4'>
                  <div className='space-y-2'><Label>ID Type</Label><Select value={form.idType} onValueChange={(v) => updateField('idType', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value='aadhaar'>Aadhaar Card</SelectItem><SelectItem value='pan'>PAN Card</SelectItem><SelectItem value='passport'>Passport</SelectItem><SelectItem value='driving'>Driving License</SelectItem></SelectContent></Select></div>
                  <div className='space-y-2'><Label>ID Number *</Label><Input value={form.idNumber} onChange={(e) => updateField('idNumber', e.target.value)} placeholder='XXXX XXXX XXXX' />{errors.idNumber && <p className='text-xs text-destructive'>{errors.idNumber}</p>}</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className='pb-4'><CardTitle className='text-lg flex items-center gap-2'><span className='h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-bold'>3</span>Lease & Payment</CardTitle></CardHeader>
              <CardContent className='space-y-4'>
                <div className='space-y-2'><Label>Lease Duration</Label><Select value={leaseDuration} onValueChange={setLeaseDuration}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value='6'>6 Months</SelectItem><SelectItem value='11'>11 Months</SelectItem><SelectItem value='12'>12 Months</SelectItem><SelectItem value='24'>24 Months</SelectItem><SelectItem value='36'>36 Months</SelectItem></SelectContent></Select></div>
                <RadioGroup value={form.paymentMethod} onValueChange={(v) => updateField('paymentMethod', v)} className='space-y-3'>
                  <div className='flex items-center space-x-3 border rounded-lg p-4 cursor-pointer has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-primary/5'><RadioGroupItem value='upi' id='upi' /><Label htmlFor='upi' className='flex-1 cursor-pointer font-medium'>UPI</Label></div>
                  <div className='flex items-center space-x-3 border rounded-lg p-4 cursor-pointer has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-primary/5'><RadioGroupItem value='card' id='card' /><Label htmlFor='card' className='flex-1 cursor-pointer font-medium'>Credit / Debit Card</Label></div>
                  <div className='flex items-center space-x-3 border rounded-lg p-4 cursor-pointer has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-primary/5'><RadioGroupItem value='netbanking' id='netbanking' /><Label htmlFor='netbanking' className='flex-1 cursor-pointer font-medium'>Net Banking</Label></div>
                </RadioGroup>
                <div className='flex items-center gap-2 text-xs text-muted-foreground'><Lock className='h-3.5 w-3.5' />Your information is encrypted and secure</div>
              </CardContent>
            </Card>
          </div>
          <div>
            <Card className='sticky top-20'>
              <CardHeader><CardTitle className='text-lg'>Booking Summary</CardTitle></CardHeader>
              <CardContent className='space-y-4'>
                <div className='max-h-64 overflow-y-auto space-y-3 pr-1'>
                  {shortlist.items.map((item) => (
                    <div key={item.id} className='flex gap-3'>
                      <div className='shrink-0'><PropertyImage image={item.property.image} images={item.property.images} name={item.property.name} size='sm' className='rounded-md' /></div>
                      <div className='flex-1 min-w-0'><p className='text-sm leading-tight line-clamp-2'>{item.property.name}</p><p className='text-xs text-muted-foreground'>{item.property.location}</p><p className='text-sm font-medium mt-1'>₹{item.property.rentPrice.toLocaleString('en-IN')}/mo</p></div>
                    </div>
                  ))}
                </div>
                <Separator />
                <div className='space-y-2'>
                  <div className='flex justify-between text-sm'><span className='text-muted-foreground'>Monthly Rent</span><span>₹{shortlist.totalRent.toLocaleString('en-IN')}</span></div>
                  <div className='flex justify-between text-sm'><span className='text-muted-foreground'>Security Deposit</span><span>₹{shortlist.totalDeposit.toLocaleString('en-IN')}</span></div>
                  <div className='flex justify-between text-sm'><span className='text-muted-foreground'>Service Fee (5%)</span><span>₹{shortlist.serviceFee.toLocaleString('en-IN')}</span></div>
                </div>
                <Separator />
                <div className='flex justify-between font-bold text-lg'><span>Pay Now</span><span>₹{(shortlist.totalDeposit + shortlist.serviceFee).toLocaleString('en-IN')}</span></div>
                <Button type='submit' className='w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white' size='lg' disabled={submitting}>
                  {submitting ? <><Loader2 className='mr-2 h-4 w-4 animate-spin' />Processing...</> : <><Lock className='mr-2 h-4 w-4' />Submit Application — ₹{(shortlist.totalDeposit + shortlist.serviceFee).toLocaleString('en-IN')}</>}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </form>
    </div>
  )
}
