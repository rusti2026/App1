'use client'

import { useAppStore } from '@/store/app-store'

export function Footer() {
  const navigateTo = useAppStore((s) => s.navigateTo)

  return (
    <footer className='border-t bg-muted/30 mt-auto'>
      <div className='container mx-auto px-4 py-10'>
        <div className='grid grid-cols-2 md:grid-cols-4 gap-8'>
          <div className='col-span-2 md:col-span-1'>
            <div className='flex items-center gap-2 font-bold text-lg mb-3'>
              <div className='h-7 w-7 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center'>
                <span className='text-white font-bold text-xs'>Z</span>
              </div>
              Z Space
            </div>
            <p className='text-sm text-muted-foreground leading-relaxed'>
              Find your perfect rental property — houses, shops, plots & industrial spaces.
            </p>
          </div>
          <div>
            <h3 className='font-semibold text-sm mb-3'>Property Types</h3>
            <ul className='space-y-2 text-sm text-muted-foreground'>
              <li><button onClick={() => { useAppStore.getState().setSelectedCategory('houses'); navigateTo('home') }} className='hover:text-foreground transition-colors'>Houses</button></li>
              <li><button onClick={() => { useAppStore.getState().setSelectedCategory('commercial-shops'); navigateTo('home') }} className='hover:text-foreground transition-colors'>Commercial Shops</button></li>
              <li><button onClick={() => { useAppStore.getState().setSelectedCategory('plots'); navigateTo('home') }} className='hover:text-foreground transition-colors'>Plots</button></li>
              <li><button onClick={() => { useAppStore.getState().setSelectedCategory('shed-factories'); navigateTo('home') }} className='hover:text-foreground transition-colors'>Shed Factories</button></li>
            </ul>
          </div>
          <div>
            <h3 className='font-semibold text-sm mb-3'>Support</h3>
            <ul className='space-y-2 text-sm text-muted-foreground'>
              <li className='hover:text-foreground transition-colors cursor-pointer'>Contact Us</li>
              <li className='hover:text-foreground transition-colors cursor-pointer'>Property Verification</li>
              <li className='hover:text-foreground transition-colors cursor-pointer'>Lease Agreement</li>
              <li className='hover:text-foreground transition-colors cursor-pointer'>FAQ</li>
            </ul>
          </div>
          <div>
            <h3 className='font-semibold text-sm mb-3'>Company</h3>
            <ul className='space-y-2 text-sm text-muted-foreground'>
              <li className='hover:text-foreground transition-colors cursor-pointer'>About Us</li>
              <li className='hover:text-foreground transition-colors cursor-pointer'>Privacy Policy</li>
              <li className='hover:text-foreground transition-colors cursor-pointer'>Terms of Service</li>
            </ul>
          </div>
        </div>
        <div className='mt-8 pt-6 border-t flex flex-col sm:flex-row justify-between items-center gap-3 text-sm text-muted-foreground'>
          <p>&copy; 2025 Z Space. All rights reserved.</p>
          <div className='flex items-center gap-4'>
            <span className='hover:text-foreground transition-colors cursor-pointer'>Visa</span>
            <span className='hover:text-foreground transition-colors cursor-pointer'>UPI</span>
            <span className='hover:text-foreground transition-colors cursor-pointer'>Net Banking</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
