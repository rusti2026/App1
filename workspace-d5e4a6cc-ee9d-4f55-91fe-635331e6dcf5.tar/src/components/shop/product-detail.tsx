'use client'

import { useState, useEffect } from 'react'
import { MapPin, Maximize, Bed, Bath, Calendar, Clock, Star, Heart, ChevronRight, Shield, Phone, CheckCircle2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { PropertyImage } from './product-image'
import { PropertyCard } from './product-card'
import { useShortlistStore } from '@/store/shortlist-store'
import { useAppStore } from '@/store/app-store'
import { toast } from 'sonner'

interface Property {
  id: string; name: string; slug: string; description: string; rentPrice: number; deposit: number | null
  area: string | null; location: string; city: string; state: string | null; bedrooms: number | null; bathrooms: number | null
  furnishing: string | null; availableFrom: string | null; minLease: string | null
  image: string | null; images: string | null; rating: number; reviewCount: number; featured: boolean
  amenities: string | null; category: { id: string; name: string; slug: string }
}

export function PropertyDetail() {
  const propertyId = useAppStore((s) => s.propertyDetail?.propertyId)
  const setSelectedCategory = useAppStore((s) => s.setSelectedCategory)
  const addItem = useShortlistStore((s) => s.addItem)
  const [property, setProperty] = useState<Property | null>(null)
  const [related, setRelated] = useState<Property[]>([])
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!propertyId) return
    let cancelled = false
    fetch('/api/properties/' + propertyId)
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (cancelled) return
        if (data) {
          setProperty(data)
          setSelectedCategory(data.category.slug)
          fetch('/api/properties?category=' + data.category.slug + '&limit=4')
            .then((r) => (r.ok ? r.json() : { properties: [] }))
            .then((d) => { if (!cancelled) setRelated(d.properties.filter((p: Property) => p.id !== propertyId).slice(0, 4)) })
        } else { setError('Property not found') }
      })
      .catch(() => { if (!cancelled) setError('Failed to load property') })
    return () => { cancelled = true }
  }, [propertyId, setSelectedCategory])

  const loading = property === null && error === null

  if (loading) return <div className='container mx-auto px-4 py-8'><div className='grid md:grid-cols-2 gap-10'><div className='h-80 md:h-[500px] bg-muted animate-pulse rounded-xl' /><div className='space-y-4'>{Array.from({length:6}).map((_,i)=><div key={i} className='h-8 bg-muted animate-pulse rounded' />)}</div></div></div>
  if (!property) return <div className='container mx-auto px-4 py-16 text-center'><p className='text-xl text-muted-foreground'>Property not found</p></div>

  const amenityList = property.amenities ? property.amenities.split(',').map(a => a.trim()) : []

  const handleShortlist = () => {
    addItem(property.id)
    toast.success(`${property.name} added to shortlist`)
  }

  return (
    <div className='container mx-auto px-4 py-6 md:py-8'>
      <nav className='flex items-center gap-1.5 text-sm text-muted-foreground mb-6'>
        <button onClick={() => useAppStore.getState().navigateTo('home')} className='hover:text-foreground transition-colors'>Home</button>
        <ChevronRight className='h-3.5 w-3.5' /><button onClick={() => { setSelectedCategory(property.category.slug); useAppStore.getState().navigateTo('home') }} className='hover:text-foreground transition-colors'>{property.category.name}</button>
        <ChevronRight className='h-3.5 w-3.5' /><span className='text-foreground truncate max-w-[200px]'>{property.name}</span>
      </nav>

      <div className='grid md:grid-cols-2 gap-8 md:gap-12'>
        <div><PropertyImage image={property.image} images={property.images} name={property.name} size='xl' className='rounded-xl' /></div>
        <div className='space-y-5'>
          <div>
            <p className='text-sm text-muted-foreground uppercase tracking-wide mb-1'>{property.category.name}</p>
            <h1 className='text-2xl md:text-3xl font-bold tracking-tight'>{property.name}</h1>
          </div>
          <div className='flex items-center gap-2 text-muted-foreground'>
            <MapPin className='h-4 w-4 shrink-0 text-emerald-600' />
            <span>{property.location}, {property.city}{property.state ? `, ${property.state}` : ''}</span>
          </div>
          <div className='flex items-center gap-2'>
            <div className='flex items-center gap-0.5'>
              {Array.from({ length: 5 }).map((_, i) => <Star key={i} className={`h-4 w-4 ${i < Math.floor(property.rating) ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />)}
            </div>
            <span className='text-sm font-medium'>{property.rating}</span>
            <span className='text-sm text-muted-foreground'>({property.reviewCount} reviews)</span>
          </div>
          <div className='flex items-baseline gap-3'>
            <span className='text-3xl font-bold'>₹{property.rentPrice.toLocaleString('en-IN')}</span>
            <span className='text-muted-foreground'>/month</span>
          </div>
          {property.deposit && (
            <p className='text-sm text-muted-foreground'>Security Deposit: <span className='font-medium text-foreground'>₹{property.deposit.toLocaleString('en-IN')}</span></p>
          )}
          <Separator />

          {/* Key details grid */}
          <div className='grid grid-cols-2 sm:grid-cols-3 gap-3'>
            {property.area && <div className='flex items-center gap-2 text-sm'><Maximize className='h-4 w-4 text-muted-foreground' /><span>Area: <strong>{property.area}</strong></span></div>}
            {property.bedrooms && <div className='flex items-center gap-2 text-sm'><Bed className='h-4 w-4 text-muted-foreground' /><span>Bedrooms: <strong>{property.bedrooms}</strong></span></div>}
            {property.bathrooms !== null && property.bathrooms > 0 && <div className='flex items-center gap-2 text-sm'><Bath className='h-4 w-4 text-muted-foreground' /><span>Bathrooms: <strong>{property.bathrooms}</strong></span></div>}
            {property.furnishing && <div className='flex items-center gap-2 text-sm'><Shield className='h-4 w-4 text-muted-foreground' /><span>{property.furnishing}</span></div>}
            {property.availableFrom && <div className='flex items-center gap-2 text-sm'><Calendar className='h-4 w-4 text-muted-foreground' /><span>Available: <strong>{property.availableFrom}</strong></span></div>}
            {property.minLease && <div className='flex items-center gap-2 text-sm'><Clock className='h-4 w-4 text-muted-foreground' /><span>Min Lease: <strong>{property.minLease}</strong></span></div>}
          </div>

          <p className='text-muted-foreground leading-relaxed'>{property.description}</p>

          {/* Amenities */}
          {amenityList.length > 0 && (
            <div>
              <h3 className='font-semibold text-sm mb-2'>Amenities</h3>
              <div className='flex flex-wrap gap-2'>
                {amenityList.map((a, i) => <Badge key={i} variant='secondary' className='bg-emerald-50 text-emerald-700 border-0'>{a}</Badge>)}
              </div>
            </div>
          )}

          <div className='flex gap-3 pt-2'>
            <Button size='lg' className='flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 text-white' onClick={handleShortlist}>
              <Heart className='h-5 w-5 mr-2' /> Shortlist
            </Button>
            <Button size='lg' variant='outline' className='flex-1 border-emerald-300 text-emerald-600 hover:bg-emerald-50' onClick={() => { addItem(property.id).then(() => useAppStore.getState().navigateTo('apply')) }}>
              Apply Now
            </Button>
          </div>
          <div className='flex items-center gap-2 text-xs text-muted-foreground'>
            <Shield className='h-3.5 w-3.5' /> Verified property • No hidden charges
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <div className='mt-16'>
          <h2 className='text-2xl font-bold tracking-tight mb-6'>Similar Properties</h2>
          <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4'>
            {related.map((p) => <PropertyCard key={p.id} property={p} />)}
          </div>
        </div>
      )}
    </div>
  )
}
