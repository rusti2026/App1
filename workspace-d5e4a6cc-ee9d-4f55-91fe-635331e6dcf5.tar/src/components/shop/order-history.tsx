'use client'

import { useEffect, useState } from 'react'
import { Package, ChevronDown, ChevronUp, ArrowLeft, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useAppStore } from '@/store/app-store'

interface Booking {
  id: string; bookingNumber: string; status: string; totalRent: number; totalDeposit: number; serviceFee: number; createdAt: string
  items: { id: string; propertyName: string; propertyLocation: string | null; rentPrice: number; deposit: number; leaseDuration: string | null }[]
}

const statusConfig: Record<string, { label: string; className: string }> = {
  pending: { label: 'Pending', className: 'bg-amber-100 text-amber-700 border-0' },
  confirmed: { label: 'Confirmed', className: 'bg-blue-100 text-blue-700 border-0' },
  active: { label: 'Active', className: 'bg-emerald-100 text-emerald-700 border-0' },
  completed: { label: 'Completed', className: 'bg-gray-100 text-gray-700 border-0' },
  cancelled: { label: 'Cancelled', className: 'bg-red-100 text-red-700 border-0' },
}

export function MyBookings() {
  const navigateTo = useAppStore((s) => s.navigateTo)
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState<string | null>(null)

  useEffect(() => {
    const sessionId = localStorage.getItem('zspace-session-id') || ''
    fetch('/api/bookings?sessionId=' + encodeURIComponent(sessionId)).then((r) => r.json()).then((d) => setBookings(d.bookings || [])).catch(console.error).finally(() => setLoading(false))
  }, [])

  if (loading) return <div className='container mx-auto px-4 py-12 text-center'><Loader2 className='h-8 w-8 animate-spin mx-auto text-muted-foreground' /><p className='text-muted-foreground mt-4'>Loading your bookings...</p></div>

  return (
    <div className='container mx-auto px-4 py-6 md:py-8'>
      <div className='flex items-center gap-3 mb-8'>
        <Button variant='ghost' size='icon' onClick={() => navigateTo('home')}><ArrowLeft className='h-5 w-5' /></Button>
        <div><h1 className='text-2xl font-bold'>My Bookings</h1><p className='text-sm text-muted-foreground'>{bookings.length} booking{bookings.length !== 1 ? 's' : ''}</p></div>
      </div>
      {bookings.length === 0 ? (
        <div className='text-center py-20'>
          <div className='h-20 w-20 rounded-full bg-muted flex items-center justify-center mx-auto mb-4'><Package className='h-10 w-10 text-muted-foreground' /></div>
          <h2 className='text-xl font-semibold mb-2'>No bookings yet</h2>
          <p className='text-muted-foreground mb-6'>When you apply for a property, it will appear here</p>
          <Button onClick={() => navigateTo('home')} className='bg-gradient-to-r from-emerald-500 to-teal-600 text-white'>Browse Properties</Button>
        </div>
      ) : (
        <div className='space-y-4'>
          {bookings.map((b) => {
            const isExp = expanded === b.id
            const status = statusConfig[b.status] || statusConfig.pending
            return (
              <Card key={b.id} className='overflow-hidden'>
                <CardContent className='p-0'>
                  <button className='w-full p-4 md:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-left hover:bg-muted/50 transition-colors' onClick={() => setExpanded(isExp ? null : b.id)}>
                    <div className='flex items-center gap-4'>
                      <div className='h-12 w-12 rounded-full bg-muted flex items-center justify-center shrink-0'><Package className='h-6 w-6 text-muted-foreground' /></div>
                      <div><p className='font-semibold'>{b.bookingNumber}</p><p className='text-sm text-muted-foreground'>{new Date(b.createdAt).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' })}</p></div>
                    </div>
                    <div className='flex items-center gap-4'>
                      <Badge className={status.className}>{status.label}</Badge>
                      <span className='font-bold text-lg'>₹{b.totalDeposit.toLocaleString('en-IN')}</span>
                      {isExp ? <ChevronUp className='h-4 w-4 text-muted-foreground' /> : <ChevronDown className='h-4 w-4 text-muted-foreground' />}
                    </div>
                  </button>
                  {isExp && (
                    <div className='border-t px-4 md:px-6 py-4 bg-muted/20'>
                      <h3 className='font-medium text-sm mb-3'>Properties</h3>
                      <div className='space-y-3'>
                        {b.items.map((item) => (
                          <div key={item.id} className='flex justify-between items-center py-2'>
                            <div><span className='text-sm'>{item.propertyName}</span>{item.propertyLocation && <p className='text-xs text-muted-foreground'>{item.propertyLocation}</p>}</div>
                            <span className='text-sm font-medium'>₹{item.rentPrice.toLocaleString('en-IN')}/mo</span>
                          </div>
                        ))}
                      </div>
                      <div className='mt-4 pt-4 border-t space-y-1 text-sm'>
                        <div className='flex justify-between'><span className='text-muted-foreground'>Monthly Rent</span><span>₹{b.totalRent.toLocaleString('en-IN')}</span></div>
                        <div className='flex justify-between'><span className='text-muted-foreground'>Security Deposit</span><span>₹{b.totalDeposit.toLocaleString('en-IN')}</span></div>
                        <div className='flex justify-between'><span className='text-muted-foreground'>Service Fee</span><span>₹{b.serviceFee.toLocaleString('en-IN')}</span></div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
