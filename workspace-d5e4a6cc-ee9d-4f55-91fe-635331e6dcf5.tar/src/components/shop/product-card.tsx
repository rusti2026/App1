'use client'

import { MapPin, Maximize, Bed, Bath, Heart, IndianRupee } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { PropertyImage } from './product-image'
import { useShortlistStore } from '@/store/shortlist-store'
import { useAppStore } from '@/store/app-store'
import { toast } from 'sonner'

interface Property {
  id: string
  name: string
  slug: string
  description: string
  rentPrice: number
  deposit: number | null
  area: string | null
  location: string
  city: string
  bedrooms: number | null
  bathrooms: number | null
  furnishing: string | null
  availableFrom: string | null
  minLease: string | null
  image: string | null
  images: string | null
  rating: number
  reviewCount: number
  featured: boolean
  amenities: string | null
  category: { id: string; name: string; slug: string }
}

function formatPrice(price: number) {
  if (price >= 100000) return `₹${(price / 100000).toFixed(1)}L`
  if (price >= 1000) return `₹${(price / 1000).toFixed(0)}K`
  return `₹${price}`
}

export function PropertyCard({ property }: { property: Property }) {
  const addItem = useShortlistStore((s) => s.addItem)
  const viewProperty = useAppStore((s) => s.viewProperty)

  const handleShortlist = (e: React.MouseEvent) => {
    e.stopPropagation()
    addItem(property.id)
    toast.success(`${property.name} added to shortlist`)
  }

  return (
    <Card className='group cursor-pointer overflow-hidden border-0 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1' onClick={() => viewProperty(property.id)}>
      <CardContent className='p-0'>
        <div className='relative'>
          <PropertyImage image={property.image} images={property.images} name={property.name} size='lg' className='rounded-none' />
          {property.featured && (
            <Badge className='absolute top-3 left-3 bg-emerald-500 text-white hover:bg-emerald-600 border-0'>Featured</Badge>
          )}
          <div className='absolute inset-x-0 bottom-0 p-3 translate-y-full group-hover:translate-y-0 transition-transform duration-300'>
            <Button size='sm' className='w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-lg' onClick={handleShortlist}>
              <Heart className='h-4 w-4 mr-2' /> Shortlist
            </Button>
          </div>
        </div>
        <div className='p-4 space-y-2'>
          <p className='text-xs text-muted-foreground uppercase tracking-wide'>{property.category.name}</p>
          <h3 className='font-semibold text-sm leading-tight line-clamp-2 group-hover:text-emerald-600 transition-colors'>{property.name}</h3>
          <div className='flex items-center gap-1.5 text-sm text-muted-foreground'>
            <MapPin className='h-3.5 w-3.5 shrink-0' />
            <span className='truncate'>{property.location}, {property.city}</span>
          </div>
          <div className='flex items-center gap-3 text-xs text-muted-foreground'>
            {property.area && (
              <span className='flex items-center gap-1'><Maximize className='h-3 w-3' />{property.area}</span>
            )}
            {property.bedrooms && (
              <span className='flex items-center gap-1'><Bed className='h-3 w-3' />{property.bedrooms} Bed</span>
            )}
            {property.bathrooms && property.bathrooms > 0 && (
              <span className='flex items-center gap-1'><Bath className='h-3 w-3' />{property.bathrooms} Bath</span>
            )}
          </div>
          <div className='flex items-baseline gap-2'>
            <span className='text-lg font-bold'>₹{property.rentPrice.toLocaleString('en-IN')}</span>
            <span className='text-xs text-muted-foreground'>/month</span>
          </div>
          {property.deposit && (
            <p className='text-xs text-muted-foreground'>Deposit: ₹{property.deposit.toLocaleString('en-IN')}</p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
