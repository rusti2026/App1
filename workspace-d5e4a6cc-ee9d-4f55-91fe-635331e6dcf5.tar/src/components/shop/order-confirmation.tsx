'use client'

import { useEffect, useState } from 'react'
import { CheckCircle2, Package, ArrowRight, Copy, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useAppStore } from '@/store/app-store'
import { toast } from 'sonner'

interface BookingData {
  id: string; bookingNumber: string; status: string; totalRent: number; totalDeposit: number; serviceFee: number; createdAt: string
  items: { id: string; propertyName: string; rentPrice: number; deposit: number; leaseDuration: string | null }[]
}

export function BookingConfirmation() {
  const { bookingConfirmation, navigateTo } = useAppStore()
  const [booking, setBooking] = useState<BookingData | null>(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    if (!bookingConfirmation) return
    fetch('/api/bookings?sessionId=' + encodeURIComponent(localStorage.getItem('zspace-session-id') || ''))
      .then((r) => r.json())
      .then((data) => { const found = data.bookings?.find((o: BookingData) => o.id === bookingConfirmation!.bookingId); if (found) setBooking(found) })
  }, [bookingConfirmation])

  const handleCopy = () => {
    if (bookingConfirmation) { navigator.clipboard.writeText(bookingConfirmation.bookingNumber); setCopied(true); toast.success('Copied!'); setTimeout(() => setCopied(false), 2000) }
  }

  if (!bookingConfirmation) return null

  return (
    <div className='container mx-auto px-4 py-12 md:py-20 max-w-2xl'>
      <div className='text-center space-y-4 mb-10'>
        <div className='h-20 w-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto'><CheckCircle2 className='h-10 w-10 text-emerald-600' /></div>
        <h1 className='text-3xl font-bold'>Application Submitted!</h1>
        <p className='text-muted-foreground text-lg'>Your booking application has been received. We will contact you within 24 hours.</p>
        <div className='inline-flex items-center gap-2 bg-muted rounded-lg px-4 py-2'>
          <span className='text-sm text-muted-foreground'>Booking ID:</span>
          <span className='font-bold text-lg'>{bookingConfirmation.bookingNumber}</span>
          <Button variant='ghost' size='icon' className='h-7 w-7' onClick={handleCopy}>{copied ? <Check className='h-3.5 w-3.5 text-emerald-600' /> : <Copy className='h-3.5 w-3.5' />}</Button>
        </div>
      </div>
      {booking && (
        <Card className='mb-8'>
          <CardContent className='p-6'>
            <h2 className='font-semibold mb-4'>Booking Details</h2>
            <div className='space-y-3'>
              {booking.items.map((item) => (
                <div key={item.id} className='flex justify-between items-center py-2 border-b last:border-0'>
                  <span className='text-sm'>{item.propertyName}</span>
                  <span className='text-sm font-medium'>₹{item.rentPrice.toLocaleString('en-IN')}/mo</span>
                </div>
              ))}
            </div>
            <div className='mt-4 pt-4 border-t space-y-2'>
              <div className='flex justify-between text-sm'><span className='text-muted-foreground'>Monthly Rent</span><span>₹{booking.totalRent.toLocaleString('en-IN')}</span></div>
              <div className='flex justify-between text-sm'><span className='text-muted-foreground'>Security Deposit</span><span>₹{booking.totalDeposit.toLocaleString('en-IN')}</span></div>
              <div className='flex justify-between text-sm'><span className='text-muted-foreground'>Service Fee</span><span>₹{booking.serviceFee.toLocaleString('en-IN')}</span></div>
            </div>
          </CardContent>
        </Card>
      )}
      <div className='flex flex-col sm:flex-row gap-3 justify-center'>
        <Button onClick={() => navigateTo('my-bookings')} variant='outline'><Package className='h-4 w-4 mr-2' />My Bookings</Button>
        <Button onClick={() => navigateTo('home')} className='bg-gradient-to-r from-emerald-500 to-teal-600 text-white'>Continue Browsing <ArrowRight className='h-4 w-4 ml-2' /></Button>
      </div>
    </div>
  )
}
