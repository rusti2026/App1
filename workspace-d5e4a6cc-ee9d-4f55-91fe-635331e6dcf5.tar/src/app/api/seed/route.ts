import { db } from '@/lib/db';
import { categories, properties } from '@/lib/seed-data';
import { NextResponse } from 'next/server';

export async function POST() {
  try {
    // Truncate all data in correct order (respecting foreign keys)
    await db.bookingItem.deleteMany();
    await db.booking.deleteMany();
    await db.shortlistItem.deleteMany();
    await db.shortlist.deleteMany();
    await db.property.deleteMany();
    await db.category.deleteMany();

    // Create categories
    const createdCategories = await db.category.createMany({
      data: categories.map((cat) => ({
        name: cat.name,
        slug: cat.slug,
        description: cat.description,
        image: cat.image,
        icon: cat.icon,
      })),
    });

    // Get category IDs for linking properties
    const categoryRecords = await db.category.findMany();
    const categoryMap = new Map(categoryRecords.map((c) => [c.slug, c.id]));

    // Create properties
    const createdProperties = await db.property.createMany({
      data: properties.map((prop) => ({
        name: prop.name,
        slug: prop.slug,
        description: prop.description,
        rentPrice: prop.rentPrice,
        deposit: prop.deposit,
        area: prop.area,
        location: prop.location,
        city: prop.city,
        state: prop.state,
        bedrooms: prop.bedrooms,
        bathrooms: prop.bathrooms,
        furnishing: prop.furnishing,
        availableFrom: prop.availableFrom,
        minLease: prop.minLease,
        image: prop.gradient,
        images: JSON.stringify({ gradient: prop.gradient, icon: prop.icon }),
        categoryId: categoryMap.get(prop.categorySlug)!,
        rating: prop.rating,
        reviewCount: prop.reviewCount,
        featured: prop.featured,
        tags: prop.tags,
        amenities: prop.amenities,
      })),
    });

    return NextResponse.json({
      success: true,
      count: {
        categories: createdCategories.count,
        properties: createdProperties.count,
      },
    });
  } catch (error) {
    console.error('Seed error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to seed database' },
      { status: 500 }
    );
  }
}
