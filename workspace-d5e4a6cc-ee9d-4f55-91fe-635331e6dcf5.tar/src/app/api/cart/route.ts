import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { Prisma } from '@prisma/client'

interface CartWithItems {
  id: string
  sessionId: string
  createdAt: Date
  updatedAt: Date
  items: Array<{
    id: string
    cartId: string
    productId: string
    quantity: number
    product: {
      id: string
      name: string
      price: number
      comparePrice: number | null
      image: string | null
      images: string | null
      stock: number
    }
  }>
  subtotal: number
  tax: number
  shipping: number
  total: number
}

async function getOrCreateCart(sessionId: string) {
  let cart = await db.cart.findUnique({
    where: { sessionId },
    include: {
      items: {
        include: {
          product: {
            select: {
              id: true,
              name: true,
              price: true,
              image: true,
              stock: true,
            },
          },
        },
      },
    },
  })

  if (!cart) {
    cart = await db.cart.create({
      data: { sessionId },
      include: {
        items: {
          include: {
            product: {
              select: {
                id: true,
                name: true,
                price: true,
                comparePrice: true,
                image: true,
                images: true,
                stock: true,
              },
            },
          },
        },
      },
    })
  }

  return formatCart(cart)
}

function formatCart(cart: {
  id: string
  sessionId: string
  createdAt: Date
  updatedAt: Date
  items: Array<{
    id: string
    cartId: string
    productId: string
    quantity: number
    product: {
      id: string
      name: string
      price: number
      comparePrice: number | null
      image: string | null
      images: string | null
      stock: number
    }
  }>
}): CartWithItems {
  const subtotal = cart.items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  )
  const tax = subtotal * 0.08
  const shipping = subtotal > 50 ? 0 : 9.99
  const total = subtotal + tax + shipping

  return {
    ...cart,
    subtotal: Math.round(subtotal * 100) / 100,
    tax: Math.round(tax * 100) / 100,
    shipping: Math.round(shipping * 100) / 100,
    total: Math.round(total * 100) / 100,
  }
}

export async function GET(request: NextRequest) {
  try {
    const sessionId = request.nextUrl.searchParams.get('sessionId') || request.headers.get('X-Session-ID')
    if (!sessionId) {
      return NextResponse.json(
        { error: 'sessionId is required' },
        { status: 400 }
      )
    }

    const cart = await getOrCreateCart(sessionId)
    return NextResponse.json(cart)
  } catch (error) {
    console.error('Cart GET error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch cart' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const sessionId = request.nextUrl.searchParams.get('sessionId')
    if (!sessionId) {
      return NextResponse.json(
        { error: 'sessionId query param is required' },
        { status: 400 }
      )
    }

    const body = await request.json()
    const { action, productId, quantity } = body as {
      action: 'add' | 'update' | 'remove'
      productId: string
      quantity?: number
    }

    if (!productId || !action) {
      return NextResponse.json(
        { error: 'productId and action are required' },
        { status: 400 }
      )
    }

    // Verify product exists
    const product = await db.product.findUnique({ where: { id: productId } })
    if (!product) {
      return NextResponse.json(
        { error: 'Product not found' },
        { status: 404 }
      )
    }

    // Get or create cart
    const cart = await db.cart.upsert({
      where: { sessionId },
      create: { sessionId },
      update: {},
    })

    if (action === 'add') {
      const existing = await db.cartItem.findUnique({
        where: {
          cartId_productId: { cartId: cart.id, productId },
        },
      })

      if (existing) {
        await db.cartItem.update({
          where: { id: existing.id },
          data: { quantity: existing.quantity + (quantity || 1) },
        })
      } else {
        await db.cartItem.create({
          data: { cartId: cart.id, productId, quantity: quantity || 1 },
        })
      }
    } else if (action === 'update') {
      if (quantity === undefined || quantity === null) {
        return NextResponse.json(
          { error: 'quantity is required for update action' },
          { status: 400 }
        )
      }

      if (quantity <= 0) {
        await db.cartItem.deleteMany({
          where: { cartId: cart.id, productId },
        })
      } else {
        await db.cartItem.upsert({
          where: {
            cartId_productId: { cartId: cart.id, productId },
          },
          create: { cartId: cart.id, productId, quantity },
          update: { quantity },
        })
      }
    } else if (action === 'remove') {
      await db.cartItem.deleteMany({
        where: { cartId: cart.id, productId },
      })
    } else {
      return NextResponse.json(
        { error: 'Invalid action. Must be add, update, or remove' },
        { status: 400 }
      )
    }

    // Return updated cart
    const updatedCart = await db.cart.findUnique({
      where: { sessionId },
      include: {
        items: {
          include: {
            product: {
              select: {
                id: true,
                name: true,
                price: true,
                comparePrice: true,
                image: true,
                images: true,
                stock: true,
              },
            },
          },
        },
      },
    })

    return NextResponse.json(formatCart(updatedCart!))
  } catch (error) {
    console.error('Cart POST error:', error)
    return NextResponse.json(
      { error: 'Failed to update cart' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const sessionId = request.nextUrl.searchParams.get('sessionId')
    if (!sessionId) {
      return NextResponse.json(
        { error: 'sessionId query param is required' },
        { status: 400 }
      )
    }

    const cart = await db.cart.findUnique({ where: { sessionId } })
    if (cart) {
      await db.cartItem.deleteMany({ where: { cartId: cart.id } })
    }

    const clearedCart = await getOrCreateCart(sessionId)
    return NextResponse.json(clearedCart)
  } catch (error) {
    console.error('Cart DELETE error:', error)
    return NextResponse.json(
      { error: 'Failed to clear cart' },
      { status: 500 }
    )
  }
}
