import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

interface ShortlistItemWithProperty {
  id: string
  shortlistId: string
  propertyId: string
  quantity: number
  property: {
    id: string
    name: string
    rentPrice: number
    deposit: number
    image: string | null
    images: string | null
    location: string
    city: string
  }
}

const propertySelect = {
  id: true,
  name: true,
  rentPrice: true,
  deposit: true,
  image: true,
  images: true,
  location: true,
  city: true,
} as const

const itemsInclude = {
  include: {
    property: {
      select: propertySelect,
    },
  },
} as const

function formatShortlist(items: ShortlistItemWithProperty[]) {
  const totalRent = items.reduce((s, i) => s + i.property.rentPrice, 0)
  const totalDeposit = items.reduce((s, i) => s + (i.property.deposit || 0), 0)
  const serviceFee = Math.round(totalRent * 0.05 * 100) / 100
  return { items, totalRent, totalDeposit, serviceFee }
}

export async function GET(request: NextRequest) {
  try {
    const sessionId = request.nextUrl.searchParams.get('sessionId')
    if (!sessionId) return NextResponse.json({ error: 'sessionId is required' }, { status: 400 })

    let shortlist = await db.shortlist.findUnique({
      where: { sessionId },
      include: { items: itemsInclude },
    })

    if (!shortlist) {
      shortlist = await db.shortlist.create({
        data: { sessionId },
        include: { items: itemsInclude },
      })
    }

    return NextResponse.json({ id: shortlist.id, ...formatShortlist(shortlist.items as ShortlistItemWithProperty[]) })
  } catch (error) {
    console.error('Shortlist GET error:', error)
    return NextResponse.json({ error: 'Failed to fetch shortlist' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const sessionId = request.nextUrl.searchParams.get('sessionId')
    if (!sessionId) return NextResponse.json({ error: 'sessionId is required' }, { status: 400 })

    const { action, propertyId } = await request.json()
    if (!propertyId) return NextResponse.json({ error: 'propertyId is required' }, { status: 400 })

    const property = await db.property.findUnique({ where: { id: propertyId } })
    if (!property) return NextResponse.json({ error: 'Property not found' }, { status: 404 })

    const shortlist = await db.shortlist.upsert({
      where: { sessionId },
      create: { sessionId },
      update: {},
    })

    if (action === 'add') {
      const existing = await db.shortlistItem.findUnique({
        where: { shortlistId_propertyId: { shortlistId: shortlist.id, propertyId } },
      })
      if (!existing) {
        await db.shortlistItem.create({ data: { shortlistId: shortlist.id, propertyId, quantity: 1 } })
      }
    } else if (action === 'remove') {
      await db.shortlistItem.deleteMany({ where: { shortlistId: shortlist.id, propertyId } })
    } else {
      return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
    }

    const updated = await db.shortlist.findUnique({
      where: { sessionId },
      include: { items: itemsInclude },
    })

    return NextResponse.json({ id: updated!.id, ...formatShortlist(updated!.items as ShortlistItemWithProperty[]) })
  } catch (error) {
    console.error('Shortlist POST error:', error)
    return NextResponse.json({ error: 'Failed to update shortlist' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const sessionId = request.nextUrl.searchParams.get('sessionId')
    if (!sessionId) return NextResponse.json({ error: 'sessionId is required' }, { status: 400 })

    const shortlist = await db.shortlist.findUnique({ where: { sessionId } })
    if (shortlist) await db.shortlistItem.deleteMany({ where: { shortlistId: shortlist.id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Shortlist DELETE error:', error)
    return NextResponse.json({ error: 'Failed to clear shortlist' }, { status: 500 })
  }
}
