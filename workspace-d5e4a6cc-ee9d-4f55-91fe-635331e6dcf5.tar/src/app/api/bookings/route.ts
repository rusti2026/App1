import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

function generateBookingNumber(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `ZB-${result}`;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const sessionId = searchParams.get('sessionId');

    if (!sessionId) {
      return NextResponse.json(
        { error: 'sessionId is required' },
        { status: 400 }
      );
    }

    const bookings = await db.booking.findMany({
      where: { sessionId },
      include: {
        items: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ bookings });
  } catch (error) {
    console.error('Bookings GET error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch bookings' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      sessionId,
      email,
      firstName,
      lastName,
      phone,
      address,
      city,
      state,
      zipCode,
      country,
      idType,
      idNumber,
      paymentMethod,
      items,
    } = body;

    if (!sessionId) {
      return NextResponse.json(
        { error: 'sessionId is required' },
        { status: 400 }
      );
    }

    // Determine which items to book
    let bookingItems: { propertyId: string; leaseDuration?: string }[] = [];

    if (items && items.length > 0) {
      bookingItems = items;
    } else {
      // Use items from the shortlist
      const shortlist = await db.shortlist.findUnique({
        where: { sessionId },
        include: {
          items: true,
        },
      });

      if (!shortlist || shortlist.items.length === 0) {
        return NextResponse.json(
          { error: 'No items to book. Shortlist is empty.' },
          { status: 400 }
        );
      }

      bookingItems = shortlist.items.map((item) => ({
        propertyId: item.propertyId,
      }));
    }

    // Fetch all properties for the booking items
    const propertyIds = bookingItems.map((item) => item.propertyId);
    const propertiesList = await db.property.findMany({
      where: { id: { in: propertyIds } },
    });

    const propertyMap = new Map(propertiesList.map((p) => [p.id, p]));

    // Calculate totals
    let totalRent = 0;
    let totalDeposit = 0;

    const bookingItemData = bookingItems.map((item) => {
      const property = propertyMap.get(item.propertyId);
      if (!property) {
        throw new Error(`Property not found: ${item.propertyId}`);
      }
      totalRent += property.rentPrice;
      totalDeposit += property.deposit || 0;

      return {
        propertyId: property.id,
        propertyName: property.name,
        propertyImage: property.image,
        propertyLocation: `${property.location}, ${property.city}`,
        rentPrice: property.rentPrice,
        deposit: property.deposit || 0,
        leaseDuration: item.leaseDuration || null,
      };
    });

    const serviceFee = totalRent * 0.05;

    // Generate unique booking number
    let bookingNumber = generateBookingNumber();
    let existingBooking = await db.booking.findUnique({
      where: { bookingNumber },
    });
    while (existingBooking) {
      bookingNumber = generateBookingNumber();
      existingBooking = await db.booking.findUnique({
        where: { bookingNumber },
      });
    }

    // Create the booking
    const booking = await db.booking.create({
      data: {
        bookingNumber,
        sessionId,
        status: 'confirmed',
        totalDeposit,
        totalRent,
        serviceFee,
        email: email || null,
        firstName: firstName || null,
        lastName: lastName || null,
        phone: phone || null,
        address: address || null,
        city: city || null,
        state: state || null,
        zipCode: zipCode || null,
        country: country || null,
        idType: idType || null,
        idNumber: idNumber || null,
        paymentMethod: paymentMethod || null,
        paymentStatus: 'completed',
        items: {
          create: bookingItemData,
        },
      },
      include: {
        items: true,
      },
    });

    // Clear the shortlist after successful booking
    const shortlist = await db.shortlist.findUnique({
      where: { sessionId },
    });
    if (shortlist) {
      await db.shortlistItem.deleteMany({
        where: { shortlistId: shortlist.id },
      });
    }

    return NextResponse.json({ booking });
  } catch (error) {
    console.error('Booking POST error:', error);
    return NextResponse.json(
      { error: 'Failed to create booking' },
      { status: 500 }
    );
  }
}
