import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const city = searchParams.get('city') || '';
    const featured = searchParams.get('featured');
    const sort = searchParams.get('sort') || '';
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '12', 10);

    // Build where clause
    const where: Record<string, unknown> = {};

    if (search) {
      where.OR = [
        { name: { contains: search } },
        { description: { contains: search } },
        { location: { contains: search } },
        { city: { contains: search } },
      ];
    }

    if (category) {
      where.category = { slug: category };
    }

    if (city) {
      where.city = { contains: city };
    }

    if (featured === 'true') {
      where.featured = true;
    }

    // Build orderBy
    let orderBy: Record<string, string> = { createdAt: 'desc' };
    switch (sort) {
      case 'price-asc':
        orderBy = { rentPrice: 'asc' };
        break;
      case 'price-desc':
        orderBy = { rentPrice: 'desc' };
        break;
      case 'rating':
        orderBy = { rating: 'desc' };
        break;
      case 'newest':
        orderBy = { createdAt: 'desc' };
        break;
    }

    const total = await db.property.count({ where });
    const totalPages = Math.ceil(total / limit);
    const skip = (page - 1) * limit;

    const propertiesList = await db.property.findMany({
      where,
      orderBy,
      skip,
      take: limit,
      include: {
        category: true,
      },
    });

    return NextResponse.json({
      properties: propertiesList,
      total,
      page,
      limit,
      totalPages,
    });
  } catch (error) {
    console.error('Properties list error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch properties' },
      { status: 500 }
    );
  }
}
