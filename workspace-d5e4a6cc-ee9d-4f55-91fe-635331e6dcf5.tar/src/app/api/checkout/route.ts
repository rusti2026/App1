import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

function generateOrderNumber(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let result = ''
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return `ZS-${result}`
}

export async function POST(request: NextRequest) {
  try {
    const sessionId = request.nextUrl.searchParams.get('sessionId')
    const body = await request.json()
    const {
      email,
      firstName,
      lastName,
      address,
      city,
      state,
      zipCode,
      country,
      phone,
      paymentMethod,
    } = body

    if (!sessionId) {
      return NextResponse.json(
        { error: 'sessionId is required' },
        { status: 400 }
      )
    }

    // Get cart with items
    const cart = await db.cart.findUnique({
      where: { sessionId },
      include: {
        items: {
          include: { product: true },
        },
      },
    })

    if (!cart || cart.items.length === 0) {
      return NextResponse.json(
        { error: 'Cart is empty or not found' },
        { status: 400 }
      )
    }

    // Calculate totals
    const subtotal = cart.items.reduce(
      (sum, item) => sum + item.product.price * item.quantity,
      0
    )
    const tax = Math.round(subtotal * 0.08 * 100) / 100
    const shipping = subtotal > 50 ? 0 : 9.99
    const total = Math.round((subtotal + tax + shipping) * 100) / 100

    // Generate unique order number
    let orderNumber = generateOrderNumber()
    let existing = await db.order.findUnique({ where: { orderNumber } })
    while (existing) {
      orderNumber = generateOrderNumber()
      existing = await db.order.findUnique({ where: { orderNumber } })
    }

    // Create order with items in a transaction
    const order = await db.$transaction(async (tx) => {
      const createdOrder = await tx.order.create({
        data: {
          orderNumber,
          sessionId,
          status: 'processing',
          subtotal,
          tax,
          shipping,
          total,
          email,
          firstName,
          lastName,
          address,
          city,
          state,
          zipCode,
          country,
          phone,
          paymentMethod,
          paymentStatus: 'completed',
          items: {
            create: cart.items.map((item) => ({
              productId: item.productId,
              productName: item.product.name,
              productImage: item.product.image,
              price: item.product.price,
              quantity: item.quantity,
            })),
          },
        },
        include: { items: true },
      })

      // Clear the cart
      await tx.cartItem.deleteMany({ where: { cartId: cart.id } })

      return createdOrder
    })

    return NextResponse.json(order, { status: 201 })
  } catch (error) {
    console.error('Checkout error:', error)
    return NextResponse.json(
      { error: 'Failed to process checkout' },
      { status: 500 }
    )
  }
}
