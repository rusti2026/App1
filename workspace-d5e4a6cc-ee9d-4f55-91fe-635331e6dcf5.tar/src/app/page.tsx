'use client'

import { useEffect, useState, useCallback } from 'react'
import { Loader2 } from 'lucide-react'
import { Header } from '@/components/shop/header'
import { Footer } from '@/components/shop/footer'
import { HeroBanner } from '@/components/shop/hero-banner'
import { CategoryGrid } from '@/components/shop/category-grid'
import { PropertyGrid } from '@/components/shop/product-grid'
import { PropertyDetail } from '@/components/shop/product-detail'
import { ShortlistDrawer } from '@/components/shop/cart-drawer'
import { BookingForm } from '@/components/shop/checkout-form'
import { BookingConfirmation } from '@/components/shop/order-confirmation'
import { MyBookings } from '@/components/shop/order-history'
import { useShortlistStore } from '@/store/shortlist-store'
import { useAppStore, type AppView } from '@/store/app-store'

interface Category {
  id: string; name: string; slug: string; description: string; image: string | null; propertyCount: number
}

export default function HomePage() {
  const [categories, setCategories] = useState<Category[]>([])
  const [initLoading, setInitLoading] = useState(true)
  const view = useAppStore((s) => s.view)
  const fetchShortlist = useShortlistStore((s) => s.fetchShortlist)
  const setInitialized = useAppStore((s) => s.setInitialized)

  const initialize = useCallback(async () => {
    try {
      await fetch('/api/seed', { method: 'POST' })
      const catRes = await fetch('/api/categories')
      if (catRes.ok) { const catData = await catRes.json(); setCategories(catData.categories) }
      fetchShortlist()
      setInitialized(true)
    } catch (error) { console.error('Init failed:', error) } finally { setInitLoading(false) }
  }, [fetchShortlist, setInitialized])

  useEffect(() => { initialize() }, [initialize])
  useEffect(() => { if (view !== 'home') window.scrollTo({ top: 0, behavior: 'smooth' }) }, [view])

  if (initLoading) {
    return (
      <div className='min-h-screen flex flex-col items-center justify-center gap-4'>
        <div className='h-12 w-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center animate-pulse'>
          <span className='text-white font-bold text-xl'>Z</span>
        </div>
        <div className='flex items-center gap-3'>
          <Loader2 className='h-5 w-5 animate-spin text-muted-foreground' />
          <span className='text-muted-foreground'>Loading Z Space...</span>
        </div>
      </div>
    )
  }

  const renderView = () => {
    switch (view) {
      case 'property-detail': return <PropertyDetail key={useAppStore.getState().propertyDetail?.propertyId} />
      case 'apply': return <BookingForm />
      case 'booking-confirmation': return <BookingConfirmation />
      case 'my-bookings': return <MyBookings />
      case 'search-results': return <PropertyGrid categories={categories} />
      case 'home':
      default: return (
        <>
          <HeroBanner />
          <CategoryGrid categories={categories} />
          <PropertyGrid categories={categories} featuredOnly />
          <div id='properties-section'><PropertyGrid categories={categories} /></div>
        </>
      )
    }
  }

  return (
    <div className='min-h-screen flex flex-col'>
      <Header />
      <main className='flex-1'>{renderView()}</main>
      <Footer />
      <ShortlistDrawer />
    </div>
  )
}
