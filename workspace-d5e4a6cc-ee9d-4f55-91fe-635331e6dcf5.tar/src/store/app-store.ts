import { create } from 'zustand'

export type AppView =
  | 'home'
  | 'property-detail'
  | 'apply'
  | 'booking-confirmation'
  | 'my-bookings'
  | 'search-results'

interface PropertyDetailState {
  propertyId: string
}

interface BookingConfirmationState {
  bookingId: string
  bookingNumber: string
}

interface AppState {
  view: AppView
  previousView: AppView
  propertyDetail: PropertyDetailState | null
  bookingConfirmation: BookingConfirmationState | null
  searchQuery: string
  selectedCategory: string
  selectedCity: string
  isInitialized: boolean

  navigateTo: (view: AppView) => void
  goBack: () => void
  viewProperty: (propertyId: string) => void
  showBookingConfirmation: (bookingId: string, bookingNumber: string) => void
  setSearchQuery: (query: string) => void
  setSelectedCategory: (category: string) => void
  setSelectedCity: (city: string) => void
  setInitialized: (initialized: boolean) => void
}

export const useAppStore = create<AppState>((set) => ({
  view: 'home',
  previousView: 'home',
  propertyDetail: null,
  bookingConfirmation: null,
  searchQuery: '',
  selectedCategory: '',
  selectedCity: '',
  isInitialized: false,

  navigateTo: (view) =>
    set((state) => ({
      previousView: state.view,
      view,
    })),

  goBack: () =>
    set((state) => ({
      view: state.previousView,
      previousView: 'home',
    })),

  viewProperty: (propertyId) =>
    set((state) => ({
      previousView: state.view,
      view: 'property-detail',
      propertyDetail: { propertyId },
    })),

  showBookingConfirmation: (bookingId, bookingNumber) =>
    set((state) => ({
      previousView: state.view,
      view: 'booking-confirmation',
      bookingConfirmation: { bookingId, bookingNumber },
    })),

  setSearchQuery: (query) => set({ searchQuery: query }),
  setSelectedCategory: (category) => set({ selectedCategory: category }),
  setSelectedCity: (city) => set({ selectedCity: city }),
  setInitialized: (initialized) => set({ isInitialized: initialized }),
}))
