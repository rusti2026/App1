import { create } from 'zustand'

export interface ShortlistItemData {
  id: string
  propertyId: string
  quantity: number
  property: {
    id: string
    name: string
    rentPrice: number
    deposit: number
    image: string | null
    images: string | null
    location: string
    city: string
  }
}

export interface ShortlistData {
  id: string
  items: ShortlistItemData[]
  totalRent: number
  totalDeposit: number
  serviceFee: number
}

interface ShortlistStore {
  shortlist: ShortlistData | null
  isOpen: boolean
  isLoading: boolean
  sessionId: string
  setSessionId: (id: string) => void
  openShortlist: () => void
  closeShortlist: () => void
  toggleShortlist: () => void
  fetchShortlist: () => Promise<void>
  addItem: (propertyId: string) => Promise<void>
  removeItem: (propertyId: string) => Promise<void>
  clearShortlist: () => Promise<void>
  getItemCount: () => number
}

function getSessionId(): string {
  if (typeof window === 'undefined') return ''
  let id = localStorage.getItem('zspace-session-id')
  if (!id) {
    id = crypto.randomUUID()
    localStorage.setItem('zspace-session-id', id)
  }
  return id
}

export const useShortlistStore = create<ShortlistStore>((set, get) => ({
  shortlist: null,
  isOpen: false,
  isLoading: false,
  sessionId: '',

  setSessionId: (id: string) => set({ sessionId: id }),
  openShortlist: () => set({ isOpen: true }),
  closeShortlist: () => set({ isOpen: false }),
  toggleShortlist: () => set((state) => ({ isOpen: !state.isOpen })),

  fetchShortlist: async () => {
    const sessionId = getSessionId()
    set({ sessionId, isLoading: true })
    try {
      const res = await fetch('/api/shortlist?sessionId=' + encodeURIComponent(sessionId))
      if (res.ok) {
        const data = await res.json()
        set({ shortlist: data })
      }
    } catch (error) {
      console.error('Failed to fetch shortlist:', error)
    } finally {
      set({ isLoading: false })
    }
  },

  addItem: async (propertyId: string) => {
    const sessionId = getSessionId()
    set({ sessionId, isLoading: true })
    try {
      const res = await fetch('/api/shortlist?sessionId=' + encodeURIComponent(sessionId), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'add', propertyId }),
      })
      if (res.ok) {
        const data = await res.json()
        set({ shortlist: data, isOpen: true })
      }
    } catch (error) {
      console.error('Failed to add item:', error)
    } finally {
      set({ isLoading: false })
    }
  },

  removeItem: async (propertyId: string) => {
    const sessionId = getSessionId()
    set({ isLoading: true })
    try {
      const res = await fetch('/api/shortlist?sessionId=' + encodeURIComponent(sessionId), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'remove', propertyId }),
      })
      if (res.ok) {
        const data = await res.json()
        set({ shortlist: data })
      }
    } catch (error) {
      console.error('Failed to remove item:', error)
    } finally {
      set({ isLoading: false })
    }
  },

  clearShortlist: async () => {
    const sessionId = getSessionId()
    try {
      await fetch('/api/shortlist?sessionId=' + encodeURIComponent(sessionId), { method: 'DELETE' })
      set({ shortlist: null })
    } catch (error) {
      console.error('Failed to clear shortlist:', error)
    }
  },

  getItemCount: () => {
    const { shortlist } = get()
    if (!shortlist) return 0
    return shortlist.items.length
  },
}))
