import { create } from 'zustand'

export interface CartItemData {
  id: string
  productId: string
  quantity: number
  product: {
    id: string
    name: string
    price: number
    comparePrice: number | null
    image: string | null
    images: string | null
    stock: number
  }
}

export interface CartData {
  id: string
  items: CartItemData[]
  subtotal: number
  tax: number
  shipping: number
  total: number
}

interface CartStore {
  cart: CartData | null
  isOpen: boolean
  isLoading: boolean
  sessionId: string
  setSessionId: (id: string) => void
  openCart: () => void
  closeCart: () => void
  toggleCart: () => void
  fetchCart: () => Promise<void>
  addItem: (productId: string, quantity?: number) => Promise<void>
  updateItem: (productId: string, quantity: number) => Promise<void>
  removeItem: (productId: string) => Promise<void>
  clearCart: () => Promise<void>
  getItemCount: () => number
}

function getSessionId(): string {
  if (typeof window === 'undefined') return ''
  let id = localStorage.getItem('zshop-session-id')
  if (!id) {
    id = crypto.randomUUID()
    localStorage.setItem('zshop-session-id', id)
  }
  return id
}

export const useCartStore = create<CartStore>((set, get) => ({
  cart: null,
  isOpen: false,
  isLoading: false,
  sessionId: '',

  setSessionId: (id: string) => set({ sessionId: id }),

  openCart: () => set({ isOpen: true }),
  closeCart: () => set({ isOpen: false }),
  toggleCart: () => set((state) => ({ isOpen: !state.isOpen })),

  fetchCart: async () => {
    const sessionId = getSessionId()
    set({ sessionId, isLoading: true })
    try {
      const res = await fetch('/api/cart?sessionId=' + encodeURIComponent(sessionId))
      if (res.ok) {
        const data = await res.json()
        set({ cart: data })
      }
    } catch (error) {
      console.error('Failed to fetch cart:', error)
    } finally {
      set({ isLoading: false })
    }
  },

  addItem: async (productId: string, quantity = 1) => {
    const sessionId = getSessionId()
    set({ sessionId, isLoading: true })
    try {
      const res = await fetch('/api/cart?sessionId=' + encodeURIComponent(sessionId), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'add', productId, quantity }),
      })
      if (res.ok) {
        const data = await res.json()
        set({ cart: data, isOpen: true })
      }
    } catch (error) {
      console.error('Failed to add item:', error)
    } finally {
      set({ isLoading: false })
    }
  },

  updateItem: async (productId: string, quantity: number) => {
    const sessionId = getSessionId()
    set({ isLoading: true })
    try {
      const res = await fetch('/api/cart?sessionId=' + encodeURIComponent(sessionId), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update', productId, quantity }),
      })
      if (res.ok) {
        const data = await res.json()
        set({ cart: data })
      }
    } catch (error) {
      console.error('Failed to update item:', error)
    } finally {
      set({ isLoading: false })
    }
  },

  removeItem: async (productId: string) => {
    const sessionId = getSessionId()
    set({ isLoading: true })
    try {
      const res = await fetch('/api/cart?sessionId=' + encodeURIComponent(sessionId), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'remove', productId }),
      })
      if (res.ok) {
        const data = await res.json()
        set({ cart: data })
      }
    } catch (error) {
      console.error('Failed to remove item:', error)
    } finally {
      set({ isLoading: false })
    }
  },

  clearCart: async () => {
    const sessionId = getSessionId()
    try {
      await fetch('/api/cart?sessionId=' + encodeURIComponent(sessionId), { method: 'DELETE' })
      set({ cart: null })
    } catch (error) {
      console.error('Failed to clear cart:', error)
    }
  },

  getItemCount: () => {
    const { cart } = get()
    if (!cart) return 0
    return cart.items.reduce((sum, item) => sum + item.quantity, 0)
  },
}))
