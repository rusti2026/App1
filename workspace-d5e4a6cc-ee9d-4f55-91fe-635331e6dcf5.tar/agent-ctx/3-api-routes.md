# Task 3: API Routes for Property Rental App

## Summary
Deleted all old e-commerce API routes and created 6 new property rental API routes.

## Deleted Files
- `src/app/api/cart/route.ts`
- `src/app/api/checkout/route.ts`
- `src/app/api/products/route.ts`
- `src/app/api/products/[id]/route.ts`
- `src/app/api/orders/route.ts`
- `src/app/api/seed/route.ts` (old)
- `src/app/api/categories/route.ts` (old)

## Created Files

### 1. `src/app/api/seed/route.ts` (POST)
- Truncates all tables in FK-safe order: BookingItem → Booking → ShortlistItem → Shortlist → Property → Category
- Creates categories from seed data, then properties linked via categorySlug → categoryId mapping
- Stores `gradient` in `image` field, `JSON.stringify({gradient, icon})` in `images` field
- Returns `{ success: true, count: { categories, properties } }`

### 2. `src/app/api/properties/route.ts` (GET)
- Query params: search, category (slug), city, featured, sort (price-asc/price-desc/rating/newest), page, limit (default 12)
- Returns `{ properties, total, page, limit, totalPages }`
- Includes category relation on each property

### 3. `src/app/api/properties/[id]/route.ts` (GET)
- Returns single property with category relation
- Returns 404 if not found

### 4. `src/app/api/categories/route.ts` (GET)
- Returns all categories with property count via `_count`
- Ordered by name ascending

### 5. `src/app/api/shortlist/route.ts` (GET, POST, DELETE)
- Session-based via `sessionId` query param
- GET: Returns shortlist with items + property details (name, rentPrice, deposit, image, location, city), creates empty if not found
- POST: { action: "add"|"remove", propertyId } — add (no duplicates, quantity=1) or remove
- DELETE: Clears all shortlist items

### 6. `src/app/api/bookings/route.ts` (GET, POST)
- GET: Returns all bookings for sessionId, sorted newest first, with items
- POST: Creates booking from shortlist items or provided items array
  - Calculates totalRent, totalDeposit, serviceFee (5% of totalRent)
  - Generates booking number ZB-XXXXXXXX
  - Sets status="confirmed", paymentStatus="completed"
  - Clears shortlist after successful booking
  - Returns booking with items

## Verification
- ESLint passed with no errors
- All routes use proper try/catch error handling
- All routes return appropriate NextResponse status codes
